'use client'

import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Loader2, Play, Copy, Check, ExternalLink, Github, Zap, Shield, Sparkles } from 'lucide-react'

const RELAY_URL = 'https://aitokenlink.cn/v1/chat/completions'
const RELAY_REGISTER_URL = 'https://aitokenlink.cn/'
const GITHUB_URL = 'https://github.com/lj25001288-commits/-AICodeAgent'

const DEMO_CODE = `def get_user(user_id):
    import pymysql
    conn = pymysql.connect("localhost")
    cursor = conn.cursor()
    sql = "SELECT * FROM users WHERE id = " + str(user_id)
    try:
        cursor.execute(sql)
        return cursor.fetchone()
    except Exception:
        return None

def create_user(name, email):
    conn = pymysql.connect("localhost")
    cursor = conn.cursor()
    sql = f"INSERT INTO users VALUES ('{name}', '{email}')"
    cursor.execute(sql)
    conn.commit()
    return True`

const SYSTEM_PROMPT = `你是资深代码审计专家。审计用户提交的代码，找出：
1. 安全漏洞（SQL注入、命令注入、硬编码密钥等）
2. 逻辑bug（异常吞咽、N+1查询、资源泄漏等）
3. 性能问题（同步阻塞、循环里建连接等）
4. 代码质量（过度防御、命名混用、unused imports等）

输出格式（Markdown）：
## 审计结果
### 🔴 Critical（严重）
### 🟡 High（高危）
### 🟢 Medium/Low（中等/低）

每个问题包含：位置、描述、修复建议。`

interface Finding {
  severity: 'critical' | 'high' | 'medium' | 'low'
  location: string
  description: string
  suggestion: string
}

export default function PlaygroundPage() {
  const [code, setCode] = useState(DEMO_CODE)
  const [apiKey, setApiKey] = useState('')
  const [showApiKeyInput, setShowApiKeyInput] = useState(false)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)
  const [stats, setStats] = useState<{ tokens?: number; latency?: number }>({})

  const runAudit = useCallback(async () => {
    if (!code.trim()) {
      setError('请输入要审计的代码')
      return
    }
    setLoading(true)
    setError('')
    setResult('')
    setStats({})

    const t0 = performance.now()

    try {
      const response = await fetch(RELAY_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey || 'sk-demo-visitor-key'}`,
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: `请审计以下代码：\n\n\`\`\`\n${code}\n\`\`\`` },
          ],
          temperature: 0.2,
          max_tokens: 4096,
        }),
      })

      if (!response.ok) {
        const errText = await response.text()
        if (response.status === 401 || response.status === 403) {
          throw new Error('API key 无效或已过期。请注册获取免费 key。')
        }
        throw new Error(`请求失败 (${response.status}): ${errText.slice(0, 200)}`)
      }

      const data = await response.json()
      const content = data.choices?.[0]?.message?.content || '(空响应)'
      const tokens = data.usage?.total_tokens
      const latency = Math.round(performance.now() - t0)

      setResult(content)
      setStats({ tokens, latency })
    } catch (err) {
      setError(err instanceof Error ? err.message : '审计失败，请重试')
    } finally {
      setLoading(false)
    }
  }, [code, apiKey])

  const copyResult = useCallback(() => {
    navigator.clipboard.writeText(result)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [result])

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-emerald-600" />
            <span className="font-bold text-lg">AI Code Auditor</span>
            <Badge variant="secondary" className="ml-2">Playground</Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowApiKeyInput(!showApiKeyInput)}
            >
              <Zap className="h-4 w-4 mr-1" />
              {apiKey ? 'Key 已设置' : '设置 API Key'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(GITHUB_URL, '_blank')}
            >
              <Github className="h-4 w-4 mr-1" />
              GitHub
            </Button>
          </div>
        </div>
      </header>

      {/* API Key Input */}
      {showApiKeyInput && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border-b">
          <div className="container mx-auto px-4 py-3">
            <Alert>
              <Sparkles className="h-4 w-4" />
              <AlertTitle>配置你的 API Key</AlertTitle>
              <AlertDescription className="mt-2">
                <div className="flex gap-2 items-center">
                  <input
                    type="password"
                    placeholder="sk-xxxxxxxxxxxx"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded border bg-white dark:bg-slate-900 text-sm"
                  />
                  <Button size="sm" onClick={() => setShowApiKeyInput(false)}>
                    确定
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(RELAY_REGISTER_URL, '_blank')}
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    免费注册
                  </Button>
                </div>
                <p className="text-xs mt-2 text-muted-foreground">
                  没有key也能试（用Demo模式）。注册后填入key可跑完整审计。
                </p>
              </AlertDescription>
            </Alert>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-[calc(100vh-180px)]">
          {/* Code Input */}
          <Card className="flex flex-col p-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="font-semibold flex items-center gap-2">
                <span className="text-sm text-muted-foreground">输入代码</span>
              </h2>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCode(DEMO_CODE)}
                >
                  示例代码
                </Button>
                <Button
                  size="sm"
                  onClick={runAudit}
                  disabled={loading || !code.trim()}
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <Play className="h-4 w-4 mr-1" />
                  )}
                  {loading ? '审计中...' : '一键审计'}
                </Button>
              </div>
            </div>
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="粘贴你的代码 here..."
              className="flex-1 font-mono text-sm resize-none"
              spellCheck={false}
            />
            <div className="mt-2 text-xs text-muted-foreground flex items-center justify-between">
              <span>{code.split('\n').length} 行 · {code.length} 字符</span>
              {stats.tokens && (
                <span>上次审计: {stats.tokens} tokens · {stats.latency}ms</span>
              )}
            </div>
          </Card>

          {/* Result Output */}
          <Card className="flex flex-col p-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="font-semibold flex items-center gap-2">
                <span className="text-sm text-muted-foreground">审计结果</span>
                {result && (
                  <Badge variant="outline" className="text-xs">
                    {stats.tokens} tokens
                  </Badge>
                )}
              </h2>
              {result && (
                <Button variant="ghost" size="sm" onClick={copyResult}>
                  {copied ? (
                    <Check className="h-4 w-4 mr-1 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4 mr-1" />
                  )}
                  复制
                </Button>
              )}
            </div>

            {error && (
              <Alert variant="destructive" className="mb-2">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {loading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2 text-emerald-600" />
                  <p className="text-sm text-muted-foreground">
                    正在调用 AI 审计代码...
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    多模型协作中，预计 30-60 秒
                  </p>
                </div>
              </div>
            ) : result ? (
              <div className="flex-1 overflow-y-auto prose prose-sm dark:prose-invert max-w-none">
                <MarkdownRenderer content={result} />
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-center">
                <div className="text-muted-foreground">
                  <Shield className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p className="text-sm">点击「一键审计」开始</p>
                  <p className="text-xs mt-1">支持 Python / JS / TS / Go / Rust 等 10 种语言</p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/80 dark:bg-slate-900/80 backdrop-blur mt-auto">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>Powered by GPT-4o + Claude + DeepSeek</span>
          </div>
          <div className="flex items-center gap-3">
            <a
              href={RELAY_REGISTER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-emerald-600 flex items-center gap-1"
            >
              <ExternalLink className="h-3 w-3" />
              免费注册 API Key
            </a>
            <span>·</span>
            <a
              href={GITHUB_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-emerald-600 flex items-center gap-1"
            >
              <Github className="h-3 w-3" />
              GitHub
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}

// 简易 Markdown 渲染器（不依赖外部库）
function MarkdownRenderer({ content }: { content: string }) {
  const lines = content.split('\n')
  const elements: React.ReactNode[] = []
  let inCodeBlock = false
  let codeContent = ''

  lines.forEach((line, i) => {
    if (line.startsWith('```')) {
      if (inCodeBlock) {
        elements.push(
          <pre key={`code-${i}`} className="bg-slate-100 dark:bg-slate-800 p-3 rounded text-xs overflow-x-auto my-2">
            <code>{codeContent}</code>
          </pre>
        )
        codeContent = ''
        inCodeBlock = false
      } else {
        inCodeBlock = true
      }
      return
    }

    if (inCodeBlock) {
      codeContent += line + '\n'
      return
    }

    if (line.startsWith('## ')) {
      elements.push(<h2 key={i} className="text-lg font-bold mt-4 mb-2">{line.slice(3)}</h2>)
    } else if (line.startsWith('### ')) {
      const text = line.slice(4)
      const severity = text.match(/🔴|🟡|🟢/)?.[0]
      elements.push(
        <h3 key={i} className="text-base font-semibold mt-3 mb-1 flex items-center gap-2">
          {severity && <span className="text-lg">{severity}</span>}
          <span>{text.replace(/🔴|🟡|🟢/g, '').trim()}</span>
        </h3>
      )
    } else if (line.startsWith('- ') || line.startsWith('* ')) {
      elements.push(
        <li key={i} className="ml-4 text-sm list-disc">{line.slice(2)}</li>
      )
    } else if (line.match(/^\d+\./)) {
      elements.push(
        <li key={i} className="ml-4 text-sm list-decimal">{line.replace(/^\d+\.\s*/, '')}</li>
      )
    } else if (line.trim()) {
      elements.push(<p key={i} className="text-sm leading-relaxed mb-1">{line}</p>)
    }
  })

  return <div className="space-y-1">{elements}</div>
}
