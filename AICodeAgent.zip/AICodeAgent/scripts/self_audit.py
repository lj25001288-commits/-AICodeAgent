"""AI Code Auditor 自审脚本 — 用项目自带的静态分析层审自己"""
import sys, os, json, time
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent / 'download' / 'ai-code-auditor'))

from auditor.tree_sitter_analyzer import analyze_with_tree_sitter
from auditor.ai_fingerprint import FingerprintDetector
from auditor.static_analyzer import analyze_file as py_ast_analyze

PROJECT_ROOT = Path(__file__).parent.parent / 'download' / 'ai-code-auditor'

def collect_python_files(root):
    files = []
    for p in root.rglob('*.py'):
        if any(seg in p.parts for seg in {'__pycache__', '.venv', '.git', 'node_modules', 'dist', 'build'}):
            continue
        files.append(p)
    return sorted(files)

def main():
    files = collect_python_files(PROJECT_ROOT)
    print(f"扫描 {len(files)} 个 Python 文件...")

    total_ts_smells = 0
    total_py_smells = 0
    avg_ts_smell = 0
    avg_ts_quality = 0
    avg_py_smell = 0
    avg_py_quality = 0
    high_count = 0

    for f in files:
        source = f.read_text(encoding='utf-8')
        rel = str(f.relative_to(PROJECT_ROOT))
        ts = analyze_with_tree_sitter(source, rel, 'python')
        py = py_ast_analyze(source, rel)
        fp = FingerprintDetector().detect(source, rel)

        total_ts_smells += len(ts.smells)
        total_py_smells += len(py.smells)
        avg_ts_smell += ts.overall_smell_score
        avg_ts_quality += ts.quality_score
        avg_py_smell += py.overall_smell_score
        avg_py_quality += py.quality_score
        high_count += sum(1 for s in ts.smells if s.severity == 'high')
        high_count += sum(1 for s in py.smells if s.severity == 'high')

        fp_top = max(fp.scores.items(), key=lambda x: x[1])
        print(f"  {rel:<35} TS smell={len(ts.smells):>2} 质量={ts.quality_score:>5.1f} AI味={ts.overall_smell_score:>4.1f} | {fp_top[0]} {fp_top[1]:.0%}")

    n = max(len(files), 1)
    print()
    print("=" * 60)
    print(f"  自审完成: {len(files)} 文件, {high_count} HIGH")
    print(f"  tree-sitter: AI味={avg_ts_smell/n:.1f}/100 (越低越好), 质量={avg_ts_quality/n:.1f}/100 (越高越好)")
    print(f"  Python ast:  AI味={avg_py_smell/n:.1f}/100 (越低越好), 质量={avg_py_quality/n:.1f}/100 (越高越好)")
    print("=" * 60)

if __name__ == '__main__':
    main()
