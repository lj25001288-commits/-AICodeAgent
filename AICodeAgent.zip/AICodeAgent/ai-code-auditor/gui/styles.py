"""QSS 样式表 — 简约专业风格，无 AI 味"""

# 配色方案：黑白灰 + 翡翠绿强调色
COLORS = {
    "bg": "#fafafa",
    "surface": "#ffffff",
    "border": "#e0e0e0",
    "text": "#1a1a1a",
    "text_secondary": "#666666",
    "accent": "#10b981",       # 翡翠绿
    "accent_hover": "#059669",
    "danger": "#ef4444",
    "warning": "#f59e0b",
}

QSS = f"""
QMainWindow, QWidget {{
    background-color: {COLORS['bg']};
    color: {COLORS['text']};
    font-family: "Segoe UI", "Microsoft YaHei", "PingFang SC", "Helvetica Neue", sans-serif;
    font-size: 14px;
}}

/* 工具栏 */
QToolBar {{
    background-color: {COLORS['surface']};
    border-bottom: 1px solid {COLORS['border']};
    padding: 6px 12px;
    spacing: 8px;
}}

QToolBar QToolButton {{
    background: transparent;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    color: {COLORS['text']};
    font-size: 13px;
}}

QToolBar QToolButton:hover {{
    background-color: {COLORS['bg']};
}}

QToolBar QToolButton:pressed {{
    background-color: {COLORS['border']};
}}

/* 按钮 */
QPushButton {{
    background-color: {COLORS['accent']};
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
}}

QPushButton:hover {{
    background-color: {COLORS['accent_hover']};
}}

QPushButton:pressed {{
    background-color: #047857;
}}

QPushButton:disabled {{
    background-color: #d1d5db;
    color: #9ca3af;
}}

QPushButton[variant="secondary"] {{
    background-color: {COLORS['surface']};
    color: {COLORS['text']};
    border: 1px solid {COLORS['border']};
}}

QPushButton[variant="secondary"]:hover {{
    background-color: {COLORS['bg']};
    border-color: #bdbdbd;
}}

/* 文本编辑器 */
QPlainTextEdit, QTextEdit {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 8px;
    font-family: "JetBrains Mono", "Cascadia Code", "Consolas", "Courier New", monospace;
    font-size: 13px;
    line-height: 1.6;
    selection-background-color: #d1fae5;
    selection-color: {COLORS['text']};
}}

QPlainTextEdit:focus, QTextEdit:focus {{
    border-color: {COLORS['accent']};
}}

/* 下拉框 */
QComboBox {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 6px 12px;
    min-width: 120px;
}}

QComboBox:hover {{
    border-color: #bdbdbd;
}}

QComboBox::drop-down {{
    border: none;
    width: 24px;
}}

QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {COLORS['text_secondary']};
    margin-right: 8px;
}}

QComboBox QAbstractItemView {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 4px;
    selection-background-color: #d1fae5;
    selection-color: {COLORS['text']};
    outline: none;
}}

/* 输入框 */
QLineEdit {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 14px;
}}

QLineEdit:focus {{
    border-color: {COLORS['accent']};
}}

/* 标签 */
QLabel {{
    color: {COLORS['text']};
    background: transparent;
}}

QLabel[role="title"] {{
    font-size: 18px;
    font-weight: 600;
}}

QLabel[role="subtitle"] {{
    font-size: 13px;
    color: {COLORS['text_secondary']};
}}

QLabel[role="caption"] {{
    font-size: 12px;
    color: {COLORS['text_secondary']};
}}

/* 分组框 */
QGroupBox {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 8px;
    margin-top: 12px;
    padding-top: 16px;
    font-size: 14px;
    font-weight: 500;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 4px;
}}

/* 状态栏 */
QStatusBar {{
    background-color: {COLORS['surface']};
    border-top: 1px solid {COLORS['border']};
    color: {COLORS['text_secondary']};
    font-size: 12px;
}}

/* 进度条 */
QProgressBar {{
    background-color: {COLORS['bg']};
    border: 1px solid {COLORS['border']};
    border-radius: 4px;
    text-align: center;
    height: 20px;
    font-size: 12px;
}}

QProgressBar::chunk {{
    background-color: {COLORS['accent']};
    border-radius: 3px;
}}

/* 滚动条 */
QScrollBar:vertical {{
    background: transparent;
    width: 8px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background: #c4c4c4;
    border-radius: 4px;
    min-height: 30px;
}}

QScrollBar::handle:vertical:hover {{
    background: #a0a0a0;
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background: transparent;
    height: 8px;
    margin: 0;
}}

QScrollBar::handle:horizontal {{
    background: #c4c4c4;
    border-radius: 4px;
    min-width: 30px;
}}

QScrollBar::handle:horizontal:hover {{
    background: #a0a0a0;
}}

/* 对话框 */
QDialog {{
    background-color: {COLORS['bg']};
}}

/* 复选框 */
QCheckBox {{
    spacing: 8px;
    font-size: 14px;
}}

QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border: 2px solid {COLORS['border']};
    border-radius: 4px;
    background: {COLORS['surface']};
}}

QCheckBox::indicator:checked {{
    background: {COLORS['accent']};
    border-color: {COLORS['accent']};
}}

/* Tab */
QTabWidget::pane {{
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    background: {COLORS['surface']};
}}

QTabBar::tab {{
    background: {COLORS['bg']};
    border: 1px solid {COLORS['border']};
    border-bottom: none;
    padding: 8px 16px;
    margin-right: 2px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    font-size: 13px;
}}

QTabBar::tab:selected {{
    background: {COLORS['surface']};
    border-bottom: 2px solid {COLORS['accent']};
}}

/* 菜单 */
QMenu {{
    background-color: {COLORS['surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 4px;
}}

QMenu::item {{
    padding: 6px 24px;
    border-radius: 4px;
}}

QMenu::item:selected {{
    background-color: {COLORS['bg']};
}}
"""
