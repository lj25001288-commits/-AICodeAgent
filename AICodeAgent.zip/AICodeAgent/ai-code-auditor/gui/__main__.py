"""GUI 入口 — python -m gui 或打包后双击 exe"""
from gui.main_window import main

if __name__ == "__main__":
    main()
