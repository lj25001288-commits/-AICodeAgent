"""AI Code Auditor GUI"""
# 延迟 import，避免打包时 PySide6 未安装就报错

def main():
    from .main_window import main as _main
    _main()

__all__ = ["main"]
