"""
AI Code Auditor — 桌面 GUI 主窗口

简约专业风格，无 AI 味。
"""
import sys
import os
import asyncio
import json
import yaml
import webbrowser
from pathlib import Path
from datetime import datetime

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QSplitter,
    QPlainTextEdit, QTextEdit, QPushButton, QComboBox, QLabel,
    QStatusBar, QProgressBar, QFileDialog, QMessageBox, QCheckBox,
    QGroupBox, QLineEdit, QDialog, QFormLayout, QDialogButtonBox,
    QTabWidget, QApplication, QStyle, QToolBar, QSizePolicy
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QSize
from PySide6.QtGui import (
    QFont, QTextCursor, QColor, QTextCharFormat, QSyntaxHighlighter,
    QAction, QIcon, QPainter, QDesktopServices
)
from PySide6.QtCore import QUrl

from .styles import QSS, COLORS

# 中转站地址
RELAY_URL = "https://aitokenlink.cn/"
RELAY_API_BASE = "https://aitokenlink.cn/v1"
GITHUB_URL = "https://github.com/lj25001288-commits/-AICodeAgent"

# 默认配置
DEFAULT_CONFIG = {
    "base_url": RELAY_API_BASE,
    "api_key": "",
    "timeout": 180.0,
    "max_concurrency": 4,
    "mode": "standard",
    "models": {
        "decomposer":      ["gpt-4o", "glm-4-plus"],
        "logic_auditor":   ["claude-3-5-sonnet-20241022", "gpt-4o"],
        "code_specialist": ["deepseek-coder", "gpt-4o-mini"],
        "agent":           ["gpt-4o"],
        "arbiter":         ["qwen-max", "gpt-4o"],
        "simple":          ["gpt-4o-mini"],
    },
    "enable_debate": True,
    "enable_agent": True,
    "enable_sandbox": False,
    "enable_fingerprint": True,
}

DEMO_CODE = '''def get_user(user_id):
    import pymysql
    conn = pymysql.connect("localhost")
    cursor = conn.cursor()
    sql = "SELECT * FROM users WHERE id = " + str(user_id)
    try:
        cursor.execute(sql)
        return cursor.fetchone()
    except Exception:
        return None

def create_user(name, email):
    conn = pymysql.connect("localhost")
    cursor = conn.cursor()
    sql = f"INSERT INTO users VALUES ('{name}', '{email}')"
    cursor.execute(sql)
    conn.commit()
    return True
'''


# ============================================================
# 配置管理
# ============================================================

def get_config_path() -> Path:
    """配置文件路径：用户目录/.ai-code-auditor/config.yaml"""
    home = Path.home()
    config_dir = home / ".ai-code-auditor"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir / "config.yaml"


def load_config() -> dict:
    """加载配置，不存在则返回默认配置"""
    path = get_config_path()
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
                # 合并默认配置
                merged = dict(DEFAULT_CONFIG)
                merged.update(cfg)
                if "models" not in cfg:
                    merged["models"] = DEFAULT_CONFIG["models"]
                return merged
        except Exception:
            pass
    return dict(DEFAULT_CONFIG)


def save_config(cfg: dict) -> None:
    """保存配置"""
    path = get_config_path()
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(cfg, f, allow_unicode=True, default_flow_style=False)


# ============================================================
# 审计线程（避免阻塞 UI）
# ============================================================

class AuditWorker(QThread):
    """后台审计线程"""
    progress = Signal(str)
    finished = Signal(str, dict)  # (report, stats)
    error = Signal(str)

    def __init__(self, code: str, filename: str, config: dict):
        super().__init__()
        self.code = code
        self.filename = filename
        self.config = config

    def run(self):
        try:
            # 动态 import（避免 GUI 启动时加载）
            import sys
            auditor_path = str(Path(__file__).parent.parent)
            if auditor_path not in sys.path:
                sys.path.insert(0, auditor_path)

            from auditor.client import MultiModelClient
            from auditor.pipeline import AuditPipeline
            from auditor.tools import ToolRegistry

            self.progress.emit("正在初始化审计引擎...")

            async def _run():
                async with MultiModelClient(
                    base_url=self.config["base_url"],
                    api_key=self.config["api_key"],
                    timeout=self.config.get("timeout", 180.0),
                    max_concurrency=self.config.get("max_concurrency", 3),
                ) as cli:
                    tools = ToolRegistry(cwd=".")
                    pipeline = AuditPipeline(cli, self.config, tool_registry=tools)
                    self.progress.emit("正在执行审计，请耐心等待...")
                    result = await pipeline.run_source(self.code, self.filename)
                    stats = {
                        "total_tokens": cli.stats.total_tokens.total_tokens,
                        "total_calls": cli.stats.total_calls,
                        "latency_ms": result.total_ms,
                        "quality_score": result.static_report.quality_score if result.static_report else 0,
                        "smell_score": result.static_report.overall_smell_score if result.static_report else 0,
                        "patches": len(result.patches),
                    }
                    return result.report, stats

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                report, stats = loop.run_until_complete(_run())
            finally:
                loop.close()

            self.finished.emit(report, stats)
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}")


# ============================================================
# 设置对话框
# ============================================================

class SettingsDialog(QDialog):
    """设置对话框"""

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.config = dict(config)
        self.setWindowTitle("设置")
        self.setMinimumWidth(500)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)

        # API 配置组
        api_group = QGroupBox("API 配置")
        api_layout = QFormLayout(api_group)
        api_layout.setSpacing(12)

        self.base_url_input = QLineEdit(self.config.get("base_url", RELAY_API_BASE))
        self.api_key_input = QLineEdit(self.config.get("api_key", ""))
        self.api_key_input.setEchoMode(QLineEdit.Password)
        self.api_key_input.setPlaceholderText("sk-xxxxxxxxxxxx")

        api_layout.addRow("中转站地址:", self.base_url_input)
        api_layout.addRow("API Key:", self.api_key_input)

        # 一键注册按钮
        register_btn = QPushButton("一键注册 API Key")
        register_btn.setProperty("variant", "secondary")
        register_btn.clicked.connect(self._open_register)
        api_layout.addRow("", register_btn)

        layout.addWidget(api_group)

        # 审计模式
        mode_group = QGroupBox("审计模式")
        mode_layout = QVBoxLayout(mode_group)
        mode_layout.setSpacing(8)

        mode_hint = QLabel(
            "Simple: 单模型快速审计，约 90 秒\n"
            "Standard: 多模型协作，约 2-3 分钟\n"
            "Full: Agent + 红蓝对抗 + 沙箱验证，约 10 分钟"
        )
        mode_hint.setProperty("role", "caption")
        mode_layout.addWidget(mode_hint)

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["simple", "standard", "full"])
        self.mode_combo.setCurrentText(self.config.get("mode", "standard"))
        mode_layout.addWidget(self.mode_combo)

        layout.addWidget(mode_group)

        # 功能开关
        feat_group = QGroupBox("功能开关（仅 Full 模式生效）")
        feat_layout = QVBoxLayout(feat_group)
        feat_layout.setSpacing(8)

        self.debate_check = QCheckBox("红蓝对抗辩论")
        self.debate_check.setChecked(self.config.get("enable_debate", True))
        self.agent_check = QCheckBox("Agent Loop（工具调用）")
        self.agent_check.setChecked(self.config.get("enable_agent", True))
        self.fingerprint_check = QCheckBox("AI 指纹识别")
        self.fingerprint_check.setChecked(self.config.get("enable_fingerprint", True))

        feat_layout.addWidget(self.debate_check)
        feat_layout.addWidget(self.agent_check)
        feat_layout.addWidget(self.fingerprint_check)
        layout.addWidget(feat_group)

        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        cancel_btn = QPushButton("取消")
        cancel_btn.setProperty("variant", "secondary")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)

        save_btn = QPushButton("保存")
        save_btn.clicked.connect(self._save)
        btn_layout.addWidget(save_btn)

        layout.addLayout(btn_layout)

    def _open_register(self):
        """打开中转站注册页"""
        webbrowser.open(RELAY_URL)

    def _save(self):
        """保存配置"""
        self.config["base_url"] = self.base_url_input.text().strip()
        self.config["api_key"] = self.api_key_input.text().strip()
        self.config["mode"] = self.mode_combo.currentText()
        self.config["enable_debate"] = self.debate_check.isChecked()
        self.config["enable_agent"] = self.agent_check.isChecked()
        self.config["enable_fingerprint"] = self.fingerprint_check.isChecked()
        save_config(self.config)
        self.accept()

    def get_config(self) -> dict:
        return self.config


# ============================================================
# 主窗口
# ============================================================

class MainWindow(QMainWindow):
    """主窗口"""

    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.worker = None
        self._build_ui()
        self._check_api_key()

    def _build_ui(self):
        self.setWindowTitle("AI Code Auditor")
        self.setMinimumSize(1000, 700)
        self.resize(1200, 800)

        # 中央 widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部工具栏
        self._build_toolbar(main_layout)

        # 分栏：左代码编辑 + 右结果
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(2)
        splitter.setStyleSheet(f"QSplitter::handle {{ background: {COLORS['border']}; }}")

        # 左侧：代码编辑
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(12, 12, 6, 12)
        left_layout.setSpacing(8)

        left_header = QHBoxLayout()
        left_title = QLabel("代码")
        left_title.setProperty("role", "title")
        left_header.addWidget(left_title)
        left_header.addStretch()

        self.demo_btn = QPushButton("示例代码")
        self.demo_btn.setProperty("variant", "secondary")
        self.demo_btn.clicked.connect(self._load_demo)
        left_header.addWidget(self.demo_btn)

        self.open_btn = QPushButton("打开文件")
        self.open_btn.setProperty("variant", "secondary")
        self.open_btn.clicked.connect(self._open_file)
        left_header.addWidget(self.open_btn)

        left_layout.addLayout(left_header)

        self.code_editor = QPlainTextEdit()
        self.code_editor.setPlaceholderText("粘贴或输入要审计的代码...")
        self.code_editor.setPlainText(DEMO_CODE)
        font = QFont("JetBrains Mono", 11)
        if not font.exactMatch():
            font = QFont("Consolas", 11)
        self.code_editor.setFont(font)
        left_layout.addWidget(self.code_editor)

        # 代码统计
        self.code_stats = QLabel("0 行 · 0 字符")
        self.code_stats.setProperty("role", "caption")
        left_layout.addWidget(self.code_stats)
        self.code_editor.textChanged.connect(self._update_code_stats)

        splitter.addWidget(left_widget)

        # 右侧：审计结果
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(6, 12, 12, 12)
        right_layout.setSpacing(8)

        right_header = QHBoxLayout()
        right_title = QLabel("审计结果")
        right_title.setProperty("role", "title")
        right_header.addWidget(right_title)
        right_header.addStretch()

        self.copy_btn = QPushButton("复制结果")
        self.copy_btn.setProperty("variant", "secondary")
        self.copy_btn.clicked.connect(self._copy_result)
        self.copy_btn.setVisible(False)
        right_header.addWidget(self.copy_btn)

        right_layout.addLayout(right_header)

        self.result_viewer = QTextEdit()
        self.result_viewer.setReadOnly(True)
        self.result_viewer.setPlaceholderText("点击「开始审计」查看结果...")
        self.result_viewer.setFont(QFont("Microsoft YaHei", 11))
        right_layout.addWidget(self.result_viewer)

        # 统计信息
        self.audit_stats = QLabel("")
        self.audit_stats.setProperty("role", "caption")
        right_layout.addWidget(self.audit_stats)

        splitter.addWidget(right_widget)
        splitter.setSizes([500, 700])

        main_layout.addWidget(splitter, 1)

        # 状态栏
        self._build_statusbar()

    def _build_toolbar(self, parent_layout):
        toolbar = QToolBar()
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(18, 18))

        # 审计模式
        mode_label = QLabel("模式:  ")
        mode_label.setProperty("role", "caption")
        toolbar.addWidget(mode_label)

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["simple", "standard", "full"])
        self.mode_combo.setCurrentText(self.config.get("mode", "standard"))
        self.mode_combo.currentTextChanged.connect(self._on_mode_change)
        toolbar.addWidget(self.mode_combo)

        toolbar.addSeparator()

        # 开始审计按钮
        self.audit_btn = QPushButton("  开始审计  ")
        self.audit_btn.clicked.connect(self._start_audit)
        toolbar.addWidget(self.audit_btn)

        toolbar.addSeparator()

        # 设置按钮
        settings_btn = QPushButton("设置")
        settings_btn.setProperty("variant", "secondary")
        settings_btn.clicked.connect(self._open_settings)
        toolbar.addWidget(settings_btn)

        toolbar.addStretch()

        # API 状态
        self.api_status = QLabel("未配置 API Key")
        self.api_status.setProperty("role", "caption")
        self.api_status.setStyleSheet(f"color: {COLORS['danger']}; padding-right: 16px;")
        toolbar.addWidget(self.api_status)

        parent_layout.addWidget(toolbar)

    def _build_statusbar(self):
        status = QStatusBar()
        self.setStatusBar(status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setRangeWidth(200)
        status.addWidget(self.progress_bar)

        self.status_label = QLabel("就绪")
        status.addWidget(self.status_label)

    def _check_api_key(self):
        """检查 API Key 是否配置"""
        if self.config.get("api_key"):
            self.api_status.setText("API Key 已配置")
            self.api_status.setStyleSheet(f"color: {COLORS['accent']}; padding-right: 16px;")
        else:
            self.api_status.setText("未配置 API Key — 点击设置")
            self.api_status.setStyleSheet(f"color: {COLORS['danger']}; padding-right: 16px;")

    def _update_code_stats(self):
        text = self.code_editor.toPlainText()
        lines = text.count("\n") + 1
        self.code_stats.setText(f"{lines} 行 · {len(text)} 字符")

    def _load_demo(self):
        self.code_editor.setPlainText(DEMO_CODE)

    def _open_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择代码文件", "",
            "代码文件 (*.py *.js *.ts *.go *.rs *.java *.rb *.c *.cpp *.h);;所有文件 (*)"
        )
        if path:
            try:
                text = Path(path).read_text(encoding="utf-8")
                self.code_editor.setPlainText(text)
                self.status_label.setText(f"已加载: {path}")
            except Exception as e:
                QMessageBox.warning(self, "错误", f"读取文件失败: {e}")

    def _on_mode_change(self, mode):
        self.config["mode"] = mode

    def _open_settings(self):
        dialog = SettingsDialog(self.config, self)
        if dialog.exec() == QDialog.Accepted:
            self.config = dialog.get_config()
            self.mode_combo.setCurrentText(self.config.get("mode", "standard"))
            self._check_api_key()
            self.status_label.setText("配置已保存")

    def _start_audit(self):
        code = self.code_editor.toPlainText().strip()
        if not code:
            QMessageBox.warning(self, "提示", "请先输入要审计的代码")
            return

        if not self.config.get("api_key"):
            ret = QMessageBox.question(
                self, "未配置 API Key",
                "审计需要 API Key 才能调用大模型。\n是否现在配置？",
                QMessageBox.Yes | QMessageBox.No
            )
            if ret == QMessageBox.Yes:
                self._open_settings()
            return

        # 禁用按钮
        self.audit_btn.setEnabled(False)
        self.audit_btn.setText("审计中...")
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # 不确定进度
        self.status_label.setText("正在审计...")
        self.result_viewer.clear()
        self.copy_btn.setVisible(False)
        self.audit_stats.setText("")

        # 启动审计线程
        self.worker = AuditWorker(code, "user_code.py", self.config)
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_progress(self, msg):
        self.status_label.setText(msg)

    def _on_finished(self, report, stats):
        self.audit_btn.setEnabled(True)
        self.audit_btn.setText("  开始审计  ")
        self.progress_bar.setVisible(False)
        self.copy_btn.setVisible(True)

        # 渲染报告
        self._render_markdown(report)

        # 显示统计
        tokens = stats.get("total_tokens", 0)
        latency = stats.get("latency_ms", 0)
        quality = stats.get("quality_score", 0)
        smell = stats.get("smell_score", 0)
        patches = stats.get("patches", 0)
        self.audit_stats.setText(
            f"耗时 {latency/1000:.1f}s · "
            f"Token {tokens:,} · "
            f"AI 味 {smell:.1f}/100 · "
            f"质量 {quality:.1f}/100 · "
            f"Patch {patches} 个"
        )
        self.status_label.setText("审计完成")

    def _on_error(self, msg):
        self.audit_btn.setEnabled(True)
        self.audit_btn.setText("  开始审计  ")
        self.progress_bar.setVisible(False)
        self.result_viewer.setPlainText(f"审计失败:\n\n{msg}")
        self.status_label.setText("审计失败")
        QMessageBox.critical(self, "审计失败", msg)

    def _render_markdown(self, text):
        """简易 Markdown 渲染"""
        self.result_viewer.clear()
        cursor = self.result_viewer.textCursor()

        # 标题格式
        h1_fmt = QTextCharFormat()
        h1_fmt.setFontWeight(QFont.Bold)
        h1_fmt.setFontPointSize(18)

        h2_fmt = QTextCharFormat()
        h2_fmt.setFontWeight(QFont.Bold)
        h2_fmt.setFontPointSize(16)

        h3_fmt = QTextCharFormat()
        h3_fmt.setFontWeight(QFont.Bold)
        h3_fmt.setFontPointSize(14)

        bold_fmt = QTextCharFormat()
        bold_fmt.setFontWeight(QFont.Bold)

        code_fmt = QTextCharFormat()
        code_fmt.setFontFamily("Consolas")
        code_fmt.setBackground(QColor("#f5f5f5"))

        normal_fmt = QTextCharFormat()
        normal_fmt.setFontPointSize(11)

        in_code = False
        for line in text.split("\n"):
            if line.strip().startswith("```"):
                in_code = not in_code
                continue

            if in_code:
                cursor.insertText(line + "\n", code_fmt)
                continue

            if line.startswith("### "):
                cursor.insertText(line[4:] + "\n", h3_fmt)
            elif line.startswith("## "):
                cursor.insertText(line[3:] + "\n", h2_fmt)
            elif line.startswith("# "):
                cursor.insertText(line[2:] + "\n", h1_fmt)
            elif line.startswith("| "):
                cursor.insertText(line + "\n", normal_fmt)
            elif line.startswith("- ") or line.startswith("* "):
                cursor.insertText("  " + line + "\n", normal_fmt)
            elif line.strip():
                cursor.insertText(line + "\n", normal_fmt)
            else:
                cursor.insertText("\n", normal_fmt)

    def _copy_result(self):
        text = self.result_viewer.toPlainText()
        QApplication.clipboard().setText(text)
        self.status_label.setText("结果已复制到剪贴板")


# ============================================================
# 入口
# ============================================================

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Code Auditor")
    app.setStyleSheet(QSS)

    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
