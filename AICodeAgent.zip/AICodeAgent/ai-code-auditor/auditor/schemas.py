"""
Pydantic Schemas for Structured LLM Output
============================================

用 Pydantic 定义所有 LLM 输出的结构化 schema，
配合 instructor 库强制 LLM 输出符合 schema 的数据。
告别 _safe_json_loads 正则兜底。
"""
from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field

# ============================================================
# Severity 枚举
# ============================================================

class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingStatus(str, Enum):
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"


class DebateVerdict(str, Enum):
    AGREE = "AGREE"
    DISAGREE = "DISAGREE"
    PARTIAL = "PARTIAL"


class FindingAction(str, Enum):
    KEEP = "KEEP"
    WITHDRAW = "WITHDRAW"
    DOWNGRADE = "DOWNGRADE"
    UPGRADE = "UPGRADE"


# ============================================================
# Round 1: Decomposer 输出
# ============================================================

class AuditChecklistItem(BaseModel):
    id: str = Field(..., description="检查项 ID，例如 C1, C2")
    item: str = Field(..., description="具体检查项描述")
    category: Literal[
        "logic", "security", "performance",
        "api_misuse", "best_practice", "readability"
    ]
    priority: Literal["high", "medium", "low"]
    target_location: str = Field(..., description="对应的函数名/行号特征")
    static_signal_referenced: str | None = Field(
        None, description="引用的静态分析信号 ID（如有）"
    )


class DecomposerOutput(BaseModel):
    """Round 1: 拆解阶段输出"""
    intent: str = Field(..., description="代码真实意图，1-2 句话")
    ai_smells_detected: list[str] = Field(
        default_factory=list,
        description="从代码中直接观察到的 AI 生成特征",
    )
    audit_checklist: list[AuditChecklistItem] = Field(
        default_factory=list,
        description="审计检查清单",
    )


# ============================================================
# Round 1: Auditor 输出
# ============================================================

class Finding(BaseModel):
    """单条审计发现"""
    checklist_id: str | None = Field(None, description="对应的检查项 ID")
    status: FindingStatus | None = Field(None, description="检查项 PASS/WARN/FAIL")
    severity: Severity
    location: str = Field(..., description="函数名 + 行号特征")
    description: str = Field(..., description="问题说明，2-4 句话", min_length=10)
    suggestion: str = Field(..., description="具体修复建议，含代码片段")
    fix_diff: str | None = Field(None, description="unified diff 格式修复片段（可选）")
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="置信度 0-1",
    )


class AdditionalFinding(BaseModel):
    """检查清单之外的新发现"""
    severity: Severity
    location: str
    description: str = Field(..., min_length=10)
    suggestion: str
    confidence: float = Field(..., ge=0.0, le=1.0)


class LogicAuditorOutput(BaseModel):
    """Round 1: 逻辑审计员输出"""
    findings: list[Finding] = Field(default_factory=list)
    additional_findings: list[AdditionalFinding] = Field(default_factory=list)


class CodeSpecialistFinding(BaseModel):
    dimension: Literal["performance", "best_practice", "readability"]
    severity: Severity
    location: str
    description: str = Field(..., min_length=10)
    suggestion: str
    refactored_snippet: str | None = None
    confidence: float = Field(..., ge=0.0, le=1.0)


class CodeSpecialistOutput(BaseModel):
    """Round 1: 代码专项审计员输出"""
    findings: list[CodeSpecialistFinding] = Field(default_factory=list)


# ============================================================
# Round 2: 交叉反驳输出
# ============================================================

class CrossReviewItem(BaseModel):
    """对对方 finding 的评价"""
    other_finding_location: str = Field(..., description="对方 finding 的 location")
    verdict: DebateVerdict
    reasoning: str = Field(..., description="判断理由，必须引用具体代码行")
    additional_evidence: str | None = None


class FindingRevision(BaseModel):
    """对自己 finding 的修订决定"""
    original_location: str
    action: FindingAction
    reason: str = Field(..., description="为什么保留/撤回/调整")


class DebaterOutput(BaseModel):
    """Round 2: 辩论阶段输出"""
    cross_review: list[CrossReviewItem] = Field(default_factory=list)
    my_revised_findings: list[FindingRevision] = Field(default_factory=list)
    new_findings_from_cross_review: list[AdditionalFinding] = Field(
        default_factory=list,
        description="反驳过程中新发现的问题",
    )


# ============================================================
# Round 3: 仲裁输出（结构化）
# ============================================================

class ConfirmedFinding(BaseModel):
    """仲裁确认的最终 finding"""
    severity: Severity
    location: str
    description: str
    suggestion: str
    fix_diff: str | None = None
    confidence: float = Field(..., ge=0.0, le=1.0)
    consensus_label: Literal[
        "multi_confirmed",   # 多重确认：多个模型都报告
        "consensus",          # 共识：一方提出，对方 AGREE
        "disputed",           # 争议项：对方 DISAGREE
        "single_party",       # 单方：只有一方报告
    ]
    source_models: list[str] = Field(
        default_factory=list,
        description="报告此 finding 的模型列表",
    )


class ArbiterStructuredOutput(BaseModel):
    """Round 3: 仲裁员结构化输出（Markdown 报告会单独生成）"""
    overall_score: int = Field(..., ge=0, le=100, description="代码质量评分 0-100")
    severity_count: dict[str, int] = Field(
        default_factory=dict,
        description="各严重级别问题数",
    )
    confirmed_findings: list[ConfirmedFinding] = Field(default_factory=list)
    improvement_suggestions: list[str] = Field(
        default_factory=list,
        description="整体改进建议 3-5 条",
    )


# ============================================================
# Tool-calling Agent
# ============================================================

class ToolName(str, Enum):
    GREP_CODE = "grep_code"
    READ_FILE = "read_file"
    RUN_TESTS = "run_tests"
    READ_GIT_LOG = "read_git_log"
    SEARCH_DOCS = "search_docs"
    LIST_DIRECTORY = "list_directory"
    SEARCH_SIMILAR_CASES = "search_similar_cases"


class ToolCall(BaseModel):
    """Agent 决定调用的工具"""
    tool: ToolName
    args: dict = Field(default_factory=dict, description="工具参数")
    reasoning: str = Field(..., description="为什么调用这个工具")


class AgentStep(BaseModel):
    """Agent 单步决策"""
    thought: str = Field(..., description="当前思考，1-3 句话")
    tool_call: ToolCall | None = Field(
        None, description="决定调用的工具，无则表示 Agent 准备给出最终结论"
    )
    is_final: bool = Field(
        False, description="是否给出最终结论，True 时下一步应进入总结阶段",
    )


# ============================================================
# 红蓝对抗辩论
# ============================================================

class RedTeamFinding(BaseModel):
    """红队攻击 finding"""
    severity: Severity
    location: str
    description: str = Field(..., min_length=10)
    evidence: str = Field(..., description="代码证据")
    proposed_fix: str | None = None
    confidence: float = Field(..., ge=0.0, le=1.0)


class BlueTeamRebuttal(BaseModel):
    """蓝队反驳"""
    red_finding_location: str
    rebuttal_verdict: Literal[
        "INVALID",        # 这不是 bug
        "EXAGGERATED",    # 是问题但严重度夸大
        "DUPLICATE",      # 已被前几轮发现过
        "VALID_CONCEDE",  # 承认是 bug
    ]
    reasoning: str = Field(..., min_length=10)
    evidence: str = Field(..., description="反驳代码证据")


class JudgeRuling(BaseModel):
    """法官判定"""
    red_finding_location: str
    final_verdict: Literal[
        "confirmed",      # 确认是真 bug
        "rejected",       # 法官驳回
        "needs_review",   # 仍需人工审
    ]
    final_severity: Severity
    final_confidence: float = Field(..., ge=0.0, le=1.0)
    reasoning: str = Field(..., min_length=10)


class RedTeamOutput(BaseModel):
    findings: list[RedTeamFinding] = Field(default_factory=list)


class BlueTeamOutput(BaseModel):
    rebuttals: list[BlueTeamRebuttal] = Field(default_factory=list)


class JudgeOutput(BaseModel):
    rulings: list[JudgeRuling] = Field(default_factory=list)


# ============================================================
# Sandbox 验证
# ============================================================

class PatchValidationResult(BaseModel):
    """Patch 沙箱验证结果"""
    patch_applied: bool = Field(..., description="patch 是否成功应用到临时副本")
    tests_passed: bool = Field(..., description="测试是否通过")
    test_output: str = Field(..., description="测试输出原文")
    syntax_valid: bool = Field(..., description="应用 patch 后语法是否有效")
    verdict: Literal[
        "verified",       # 验证通过
        "syntax_error",   # 应用后语法错误
        "tests_failed",   # 测试失败
        "apply_failed",   # patch 无法应用
    ]
    feedback_for_llm: str | None = Field(
        None, description="失败时反馈给 LLM 重新生成 patch 的信息",
    )


# ============================================================
# 评估集
# ============================================================

class GoldBug(BaseModel):
    """评估集单条样本"""
    id: str = Field(..., description="样本 ID，例如 PY-001")
    language: str
    code: str = Field(..., description="待审计代码")
    expected_findings: list[dict] = Field(
        ..., description="金标 bug 列表，每条含 location + category + severity",
    )
    description: str = Field(..., description="样本说明")


class EvaluationResult(BaseModel):
    """单样本评估结果"""
    sample_id: str
    true_positives: int = Field(0, description="正确报告的 bug 数")
    false_positives: int = Field(0, description="误报数")
    false_negatives: int = Field(0, description="漏报数")
    precision: float = 0.0
    recall: float = 0.0
    f1: float = 0.0
    latency_ms: int = 0
    tokens_consumed: int = 0
    findings_reported: list[dict] = Field(default_factory=list)


class EvaluationSummary(BaseModel):
    """评估集汇总结果"""
    total_samples: int
    avg_precision: float
    avg_recall: float
    avg_f1: float
    avg_latency_ms: float
    avg_tokens: float
    by_severity: dict[str, dict[str, float]] = Field(
        default_factory=dict,
        description="按严重度分组的 P/R/F1",
    )
    by_language: dict[str, dict[str, float]] = Field(
        default_factory=dict,
        description="按语言分组的 P/R/F1",
    )


# ============================================================
# 兼容：旧版 dict-style 输出
# ============================================================

def finding_to_dict(f: Finding | dict) -> dict:
    """把 Pydantic Finding 或 dict 统一成 dict"""
    if isinstance(f, dict):
        return f
    return f.model_dump()


def safe_severity(s: str | Severity) -> Severity:
    """容错地把字符串转 Severity"""
    if isinstance(s, Severity):
        return s
    try:
        return Severity(s.lower())
    except (ValueError, AttributeError):
        return Severity.INFO
