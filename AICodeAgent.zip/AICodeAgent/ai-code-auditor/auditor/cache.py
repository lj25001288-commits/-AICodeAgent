"""
Function-level Hash Cache
=========================

用函数源码 hash 做 key，相同函数不重复审计。
工程化标志——也是省钱关键。
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass
class CacheEntry:
    """单条缓存"""
    function_hash: str
    function_name: str
    file: str
    findings_summary: str       # 简要结论
    severity_count: dict[str, int]  # {critical: n, high: n, ...}
    created_at: float
    raw_report: str = ""        # 原始 LLM 报告


class AuditCache:
    """
    简单的 JSON 文件持久化缓存。

    缓存粒度：函数级。一个文件里改了 A 函数，B 函数的审计结果仍命中。
    """

    def __init__(self, cache_path: str | None = None, ttl: float = 86400 * 7) -> None:
        """
        cache_path: 缓存文件路径，None 表示禁用缓存。
        ttl: 缓存有效期（秒），默认 7 天。
        """
        self.cache_path = Path(cache_path) if cache_path else None
        self.ttl = ttl
        self._cache: dict[str, CacheEntry] = {}
        self._hits = 0
        self._misses = 0
        self._load()

    def _load(self) -> None:
        if not self.cache_path or not self.cache_path.exists():
            return
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
            for k, v in data.items():
                self._cache[k] = CacheEntry(**v)
        except (json.JSONDecodeError, TypeError):
            # 缓存损坏，忽略
            pass

    def _save(self) -> None:
        if not self.cache_path:
            return
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        data = {k: asdict(v) for k, v in self._cache.items()}
        self.cache_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @staticmethod
    def hash_function(
        file: str, function_name: str, function_source: str, models_signature: str,
    ) -> str:
        """
        函数 hash = SHA256(file + function_name + source + models_signature)
        models_signature 加入 hash 是为了换模型组合后强制重审。
        """
        h = hashlib.sha256()
        h.update(file.encode())
        h.update(b"\x00")
        h.update(function_name.encode())
        h.update(b"\x00")
        h.update(function_source.encode())
        h.update(b"\x00")
        h.update(models_signature.encode())
        return h.hexdigest()[:16]

    def get(self, key: str) -> CacheEntry | None:
        if not self.cache_path:
            self._misses += 1
            return None
        entry = self._cache.get(key)
        if entry is None:
            self._misses += 1
            return None
        if time.time() - entry.created_at > self.ttl:
            self._misses += 1
            return None
        self._hits += 1
        return entry

    def put(self, entry: CacheEntry) -> None:
        if not self.cache_path:
            return
        self._cache[entry.function_hash] = entry
        self._save()

    def stats(self) -> str:
        total = self._hits + self._misses
        hit_rate = (self._hits / total * 100) if total else 0.0
        return (
            f"  缓存: 命中 {self._hits} / 未命中 {self._misses} "
            f"(命中率 {hit_rate:.0f}%)"
        )

    def clear(self) -> None:
        self._cache.clear()
        if self.cache_path and self.cache_path.exists():
            self.cache_path.unlink()
