"""
AI Code Fingerprint Detector
============================

基于代码风格统计特征，判断一段代码大概率来自哪个 AI / 是否人类写的。

这是项目的"独门卖点"——目前没有任何公开工具做这件事。

检测的特征维度：
1. 异常处理风格     — try/except 密度、裸 except 比例
2. 命名风格         — snake/camel 混用程度、单字母变量比例
3. 注释/docstring   — 密度、长度、emoji 使用、bullet 风格
4. 防御性检查       — 连续 if-return 模式
5. 类型注解密度     — type hint 覆盖率
6. 代码结构         — 函数平均长度、参数个数、嵌套深度
7. import 整洁度    — unused import、import 分组规范性
8. AI 特征字符串    — "I'll", "Let me", "Sure!", "```python" 残留

输出：4 个候选来源的概率分布
  - Cursor (Anthropic Claude / GPT-4 系)
  - Copilot (GPT-4o / Codex 系)
  - ChatGPT/Claude 直接粘贴
  - Human
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field


@dataclass
class StyleFeature:
    """单一风格特征"""
    name: str
    value: float
    description: str = ""


@dataclass
class FingerprintReport:
    """AI 指纹报告"""
    scores: dict[str, float] = field(default_factory=dict)  # {来源: 概率}
    features: list[StyleFeature] = field(default_factory=list)
    verdict: str = ""        # 人类可读结论
    confidence: float = 0.0  # 置信度 0-1
    signals: list[str] = field(default_factory=list)  # 关键证据

    def summary(self) -> str:
        sorted_scores = sorted(
            self.scores.items(), key=lambda x: -x[1]
        )
        lines = ["  AI 指纹识别:"]
        for src, prob in sorted_scores:
            bar = "█" * int(prob * 20) + "░" * (20 - int(prob * 20))
            lines.append(f"    {src:<14} {bar} {prob:.1%}")
        lines.append(f"    结论: {self.verdict} (置信度 {self.confidence:.0%})")
        return "\n".join(lines)


# AI 特征字符串残留（直接粘贴的代码经常带这些）
AI_MARKERS = [
    # ChatGPT 对话残留
    (r"^Here'?s? (?:the |an |a )?(?:updated |modified |improved )?(?:code|implementation|version)", "chatgpt"),
    (r"^Sure!?[,!]?\s*(?:Here|Let me|I'll)", "chatgpt"),
    (r"^I'll\s+(?:help|fix|implement|create)", "chatgpt"),
    (r"^Let me\s+(?:help|fix|implement|create)", "chatgpt"),
    # Cursor 残留
    (r"^\`\`\`python\s*$", "cursor_or_chatgpt"),
    (r"^\`\`\`(?:typescript|javascript|go|rust)\s*$", "cursor_or_chatgpt"),
    # Claude 残留
    (r"^I (?:see|understand) (?:that|you|your)", "claude"),
    # Copilot 注释风格
    (r"^\s*//\s*TODO:.*(?:implement|fix|complete)", "copilot"),
]


class FingerprintDetector:
    """AI 指纹识别主类"""

    def detect(self, source: str, filename: str = "<code>") -> FingerprintReport:
        report = FingerprintReport()

        # 非可解析代码直接走字符串特征
        try:
            tree = ast.parse(source)
            features = self._extract_features(tree, source)
        except SyntaxError:
            features = self._extract_features_fallback(source)

        report.features = features

        # 各来源打分
        scores = self._score_sources(features, source)
        report.scores = scores
        report.verdict, report.confidence = self._verdict(scores)
        report.signals = self._collect_signals(features, source)
        return report

    # -------- 特征提取 --------

    def _extract_features(self, tree: ast.AST, source: str) -> list[StyleFeature]:
        """提取 10 维特征向量（拆分为子方法以降低复杂度）"""
        lines = source.splitlines()
        funcs = [
            n for n in ast.walk(tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        n_funcs = max(len(funcs), 1)

        feats: list[StyleFeature] = []
        feats.extend(self._extract_exception_features(tree, n_funcs))
        feats.append(self._extract_silent_except_ratio(tree))
        feats.append(self._extract_guard_clauses_avg(funcs, n_funcs))
        feats.append(self._extract_docstring_coverage(funcs, n_funcs))
        feats.append(self._extract_annotation_density(funcs))
        feats.append(self._extract_avg_func_length(funcs, n_funcs))
        feats.append(self._extract_unused_imports(tree))
        feats.append(self._extract_comment_density(lines))
        feats.append(self._extract_emoji_count(source))
        feats.append(self._extract_naming_mixing(tree))
        return feats

    def _extract_exception_features(
        self, tree: ast.AST, n_funcs: int,
    ) -> list[StyleFeature]:
        """try/except 密度 + 裸 except 比例"""
        try_count = sum(1 for n in ast.walk(tree) if isinstance(n, ast.Try))
        bare_count = sum(
            1 for n in ast.walk(tree)
            if isinstance(n, ast.ExceptHandler)
            and (n.type is None or (isinstance(n.type, ast.Name) and n.type.id in ("Exception", "BaseException")))
        )
        return [
            StyleFeature("try_except_density", try_count / n_funcs, "每个函数平均 try/except 数"),
            StyleFeature("bare_except_ratio", bare_count / max(try_count, 1), "裸 except / 总 except 比例"),
        ]

    def _extract_silent_except_ratio(self, tree: ast.AST) -> StyleFeature:
        """异常被静默吞掉的 except 比例"""
        try_count = 0
        pass_count = 0
        for n in ast.walk(tree):
            if isinstance(n, ast.Try):
                try_count += 1
                for h in n.handlers:
                    if self._is_silent_handler(h):
                        pass_count += 1
        return StyleFeature(
            "silent_except_ratio", pass_count / max(try_count, 1),
            "异常被静默吞掉的 except 比例",
        )

    @staticmethod
    def _is_silent_handler(h: ast.ExceptHandler) -> bool:
        """判断 except handler 是否静默吞异常（pass 或 return None）"""
        if len(h.body) != 1:
            return False
        stmt = h.body[0]
        if isinstance(stmt, ast.Pass):
            return True
        return isinstance(stmt, ast.Return) and stmt.value is None

    @staticmethod
    def _extract_guard_clauses_avg(funcs: list, n_funcs: int) -> StyleFeature:
        """连续 if-return 检查（过度防御）"""
        guard_count = 0
        for f in funcs:
            for stmt in f.body:
                if (
                    isinstance(stmt, ast.If)
                    and len(stmt.body) == 1
                    and isinstance(stmt.body[0], (ast.Return, ast.Raise))
                ):
                    guard_count += 1
                else:
                    break
        return StyleFeature(
            "guard_clauses_avg", guard_count / n_funcs,
            "每个函数平均 guard clause 数",
        )

    @staticmethod
    def _extract_docstring_coverage(funcs: list, n_funcs: int) -> StyleFeature:
        """docstring 覆盖率"""
        docstring_funcs = sum(1 for f in funcs if ast.get_docstring(f))
        return StyleFeature(
            "docstring_coverage", docstring_funcs / n_funcs,
            "docstring 覆盖率",
        )

    @staticmethod
    def _extract_annotation_density(funcs: list) -> StyleFeature:
        """类型注解密度"""
        annotated_args = 0
        total_args = 0
        for f in funcs:
            for arg in f.args.args + f.args.kwonlyargs:
                total_args += 1
                if arg.annotation is not None:
                    annotated_args += 1
            if f.returns is not None:
                total_args += 1
                annotated_args += 1
            else:
                total_args += 1
        return StyleFeature(
            "annotation_density", annotated_args / max(total_args, 1),
            "类型注解覆盖率",
        )

    @staticmethod
    def _extract_avg_func_length(funcs: list, n_funcs: int) -> StyleFeature:
        """函数平均长度"""
        avg_len = sum(
            (n.end_lineno or n.lineno) - n.lineno + 1
            for n in funcs
        ) / n_funcs
        return StyleFeature("avg_func_length", avg_len, "函数平均长度")

    @staticmethod
    def _extract_unused_imports(tree: ast.AST) -> StyleFeature:
        """unused imports 数量"""
        used = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.Name):
                used.add(n.id)
            elif isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name):
                used.add(n.value.id)
        imports = []
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                for a in n.names:
                    imports.append(a.asname or a.name.split(".")[0])
            elif isinstance(n, ast.ImportFrom):
                for a in n.names:
                    if a.name != "*":
                        imports.append(a.asname or a.name)
        unused = sum(1 for i in imports if i not in used)
        return StyleFeature("unused_import_count", unused, "unused import 数量")

    @staticmethod
    def _extract_comment_density(lines: list[str]) -> StyleFeature:
        """注释行占比"""
        n_lines = max(len(lines), 1)
        comment_lines = sum(
            1 for line in lines
            if line.strip().startswith("#") and not line.strip().startswith("#!")
        )
        return StyleFeature(
            "comment_density", comment_lines / n_lines, "注释行占比",
        )

    @staticmethod
    def _extract_emoji_count(source: str) -> StyleFeature:
        """emoji 残留（Claude/ChatGPT 经常在注释里加 emoji）"""
        emoji_count = len(re.findall(
            r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F600-\U0001F64F]",
            source,
        ))
        return StyleFeature("emoji_in_comments", emoji_count, "代码中 emoji 数量")

    @staticmethod
    def _extract_naming_mixing(tree: ast.AST) -> StyleFeature:
        """命名风格混用度"""
        naming = {"snake": 0, "camel": 0, "pascal": 0, "single": 0}
        for n in ast.walk(tree):
            if isinstance(n, (ast.Name, ast.arg)):
                name = getattr(n, "arg", None) or n.id
                style = FingerprintDetector._classify_naming_style(name)
                naming[style] += 1
        total_names = sum(naming.values()) or 1
        # 混用度：snake/camel 都不为 0 时打高分
        if naming["snake"] > 0 and naming["camel"] > 0:
            mixing = min(naming["snake"], naming["camel"]) / total_names
        else:
            mixing = 0.0
        return StyleFeature(
            "naming_mixing", mixing,
            f"命名混用度 (snake={naming['snake']} camel={naming['camel']})",
        )

    @staticmethod
    def _classify_naming_style(name: str) -> str:
        """分类单个标识符的命名风格（dispatch table 替代 elif 链）"""
        patterns = [
            ("snake",  r"_*[a-z][a-z0-9_]*"),
            ("camel",  r"_*[a-z][a-zA-Z0-9]*"),  # 配合 "_" not in name 判断
            ("pascal", r"_*[A-Z][a-zA-Z0-9]*"),
        ]
        for style, pattern in patterns:
            if re.fullmatch(pattern, name):
                if style == "camel" and "_" in name:
                    continue  # camelCase 不应含下划线
                return style
        if len(name) == 1:
            return "single"
        return "snake"  # 兜底

    def _extract_features_fallback(self, source: str) -> list[StyleFeature]:
        """语法无法解析时的兜底特征提取"""
        lines = source.splitlines()
        n = max(len(lines), 1)
        try_count = sum(1 for l in lines if re.match(r"\s*try\s*:", l))
        except_count = sum(1 for l in lines if re.match(r"\s*except\b", l))
        return [
            StyleFeature("try_except_density", try_count / max(n, 1) * 100, "兜底估算"),
            StyleFeature("bare_except_ratio", 0.5 if except_count else 0.0, "兜底估算"),
            StyleFeature("silent_except_ratio", 0.0, "兜底估算"),
            StyleFeature("guard_clauses_avg", 0.0, "兜底估算"),
            StyleFeature("docstring_coverage", 0.0, "兜底估算"),
            StyleFeature("annotation_density", 0.0, "兜底估算"),
            StyleFeature("avg_func_length", n, "兜底估算"),
            StyleFeature("unused_import_count", 0, "兜底估算"),
            StyleFeature("comment_density", 0.1, "兜底估算"),
            StyleFeature("emoji_in_comments", 0, "兜底估算"),
            StyleFeature("naming_mixing", 0.0, "兜底估算"),
        ]

    # -------- 来源打分 --------

    def _score_sources(
        self, features: list[StyleFeature], source: str,
    ) -> dict[str, float]:
        f = {x.name: x.value for x in features}

        # ============== Cursor 得分 ==============
        # Cursor 特征：高频 docstring + 类型注解 + 偶尔 unused import + 较少 silent except
        cursor_score = 0.0
        cursor_score += f.get("docstring_coverage", 0) * 25         # 0-25
        cursor_score += f.get("annotation_density", 0) * 20         # 0-20
        cursor_score += min(f.get("unused_import_count", 0) * 4, 12)  # 0-12
        cursor_score += (1 - f.get("silent_except_ratio", 0)) * 8    # 0-8
        if f.get("avg_func_length", 0) > 15:
            cursor_score += 8
        if f.get("naming_mixing", 0) > 0.05:
            cursor_score += 7

        # ============== Copilot 得分 ==============
        # Copilot 特征：低 docstring 覆盖、类型注解较少、函数短、emoji 少
        copilot_score = 0.0
        copilot_score += (1 - f.get("docstring_coverage", 0)) * 18
        copilot_score += (1 - f.get("annotation_density", 0)) * 15
        if f.get("avg_func_length", 0) < 12:
            copilot_score += 15
        copilot_score += (1 - min(f.get("try_except_density", 0), 1)) * 10
        copilot_score += min(f.get("guard_clauses_avg", 0) * 8, 12)
        if f.get("comment_density", 0) < 0.05:
            copilot_score += 10

        # ============== ChatGPT 直接粘贴 得分 ==============
        # ChatGPT 粘贴特征：高 docstring + 高 silent except + 高 unused + 可能有 ``` 残留
        chatgpt_score = 0.0
        chatgpt_score += f.get("docstring_coverage", 0) * 15
        chatgpt_score += min(f.get("silent_except_ratio", 0) * 30, 25)
        chatgpt_score += min(f.get("unused_import_count", 0) * 5, 15)
        chatgpt_score += min(f.get("guard_clauses_avg", 0) * 10, 15)
        chatgpt_score += min(f.get("naming_mixing", 0) * 50, 10)
        # 字符串残留
        for pattern, _src in AI_MARKERS:
            if re.search(pattern, source, re.MULTILINE):
                chatgpt_score += 15
                break

        # ============== Human 得分 ==============
        # 人类特征：低 docstring（懒）、命名一致、极少 unused import、低 silent except
        human_score = 0.0
        human_score += (1 - f.get("docstring_coverage", 0)) * 15
        human_score += (1 - min(f.get("unused_import_count", 0) / 5, 1)) * 20
        human_score += (1 - f.get("silent_except_ratio", 0)) * 18
        human_score += (1 - min(f.get("naming_mixing", 0) * 10, 1)) * 15
        if f.get("annotation_density", 0) < 0.3:
            human_score += 8
        if f.get("emoji_in_comments", 0) == 0:
            human_score += 8

        # 归一化
        total = cursor_score + copilot_score + chatgpt_score + human_score
        if total <= 0:
            return {"Cursor": 0.25, "Copilot": 0.25, "ChatGPT": 0.25, "Human": 0.25}
        return {
            "Cursor": cursor_score / total,
            "Copilot": copilot_score / total,
            "ChatGPT": chatgpt_score / total,
            "Human": human_score / total,
        }

    def _verdict(self, scores: dict[str, float]) -> tuple[str, float]:
        top = max(scores.items(), key=lambda x: x[1])
        confidence = top[1]
        if confidence < 0.35:
            return "无法确定（多来源混合）", confidence
        return f"大概率来自 {top[0]}", confidence

    def _collect_signals(
        self, features: list[StyleFeature], source: str,
    ) -> list[str]:
        """收集人类可读的关键证据"""
        sigs: list[str] = []
        f = {x.name: x.value for x in features}

        if f.get("silent_except_ratio", 0) > 0.3:
            sigs.append(
                f"静默吞异常比例 {f['silent_except_ratio']:.0%}，AI 生成强烈信号"
            )
        if f.get("docstring_coverage", 0) > 0.7:
            sigs.append(
                f"docstring 覆盖率 {f['docstring_coverage']:.0%}，AI 倾向全注释"
            )
        if f.get("unused_import_count", 0) > 0:
            sigs.append(f"{int(f['unused_import_count'])} 个 unused import")
        if f.get("naming_mixing", 0) > 0.05:
            sigs.append(f"命名风格混用度 {f['naming_mixing']:.2f}")
        if f.get("guard_clauses_avg", 0) > 3:
            sigs.append(
                f"平均每函数 {f['guard_clauses_avg']:.1f} 个 guard，过度防御"
            )
        for pattern, src in AI_MARKERS:
            if re.search(pattern, source, re.MULTILINE):
                sigs.append(f"检测到 {src} 特征字符串残留")
                break
        return sigs or ["无明显 AI 特征信号"]
