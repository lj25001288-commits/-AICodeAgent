"""AI Code Auditor v3 — 商业级多模型 Agent 审计工具"""
from .adversarial_debate import AdversarialDebateEngine, DebateResult, DebateRoundResult
from .agent_loop import AgentLoop, AgentRunResult
from .ai_fingerprint import FingerprintDetector, FingerprintReport
from .cache import AuditCache, CacheEntry
from .client import CallStats, ModelResponse, MultiModelClient, Usage
from .evaluation import Evaluator, GOLD_SAMPLES, GoldBug, summary_to_markdown
from .patcher import PatchApplier, PatchExtractor, PatchResult
from .pipeline import AuditPipeline, AuditResult, AuditStage, DiffPipeline
from .sandbox import BatchValidationResult, SandboxValidator, validate_all_patches
from .schemas import (
    AgentStep,
    ArbiterStructuredOutput,
    BlueTeamOutput,
    ConfirmedFinding,
    DebateVerdict,
    DecomposerOutput,
    EvaluationResult,
    EvaluationSummary,
    Finding,
    FindingAction,
    FindingStatus,
    JudgeOutput,
    LogicAuditorOutput,
    PatchValidationResult,
    RedTeamOutput,
    Severity,
    ToolCall,
    ToolName,
)
from .static_analyzer import PythonAnalyzer, StaticReport, analyze_file
from .tools import ToolRegistry, ToolResult
from .tree_sitter_analyzer import (
    SUPPORTED_LANGUAGES,
    TreeSitterAnalyzer,
    TSStaticReport,
    analyze_with_tree_sitter,
)

__version__ = "3.0.0"
__all__ = [
    # client
    "MultiModelClient", "ModelResponse", "Usage", "CallStats",
    # pipeline
    "AuditPipeline", "AuditResult", "AuditStage", "DiffPipeline",
    # cache
    "AuditCache", "CacheEntry",
    # static analyzer
    "PythonAnalyzer", "StaticReport", "analyze_file",
    "TreeSitterAnalyzer", "TSStaticReport", "analyze_with_tree_sitter",
    "SUPPORTED_LANGUAGES",
    # fingerprint
    "FingerprintDetector", "FingerprintReport",
    # tools & agent
    "ToolRegistry", "ToolResult",
    "AgentLoop", "AgentRunResult",
    # debate
    "AdversarialDebateEngine", "DebateResult", "DebateRoundResult",
    # sandbox
    "SandboxValidator", "BatchValidationResult", "validate_all_patches",
    # patcher
    "PatchExtractor", "PatchApplier", "PatchResult",
    # evaluation
    "Evaluator", "GoldBug", "GOLD_SAMPLES", "summary_to_markdown",
    # schemas
    "Severity", "FindingStatus", "DebateVerdict", "FindingAction",
    "Finding", "DecomposerOutput", "LogicAuditorOutput",
    "ConfirmedFinding", "ArbiterStructuredOutput",
    "ToolName", "ToolCall", "AgentStep",
    "RedTeamOutput", "BlueTeamOutput", "JudgeOutput",
    "PatchValidationResult",
    "EvaluationResult", "EvaluationSummary",
]
