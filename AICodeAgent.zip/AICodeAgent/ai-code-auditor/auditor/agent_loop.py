"""
ReAct Agent Loop
================

让 Agent 拥有"多轮决策"能力：
  Thought → Action → Observation → Thought → ... → Final Answer

Agent 在每一步可以选择：
  - 调用一个工具（grep/read_file/run_tests/...）
  - 给出最终结论（is_final=True）

收敛条件：
  - is_final=True
  - 达到 max_steps（默认 8）
  - 连续 2 步无新信息（工具返回和上一步相同）
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from .client import MultiModelClient
from .schemas import AgentStep, ToolCall, ToolName
from .tools import ToolRegistry, ToolResult


# ============================================================
# Agent 历史
# ============================================================

@dataclass
class AgentHistoryEntry:
    """单步历史"""
    step: int
    thought: str
    tool_call: ToolCall | None
    tool_result: ToolResult | None
    is_final: bool
    latency_ms: int


@dataclass
class AgentRunResult:
    """Agent 跑完的整体结果"""
    final_summary: str          # Agent 最终输出（自然语言）
    history: list[AgentHistoryEntry] = field(default_factory=list)
    total_steps: int = 0
    total_ms: int = 0
    tool_calls: int = 0
    truncated: bool = False     # 是否因 max_steps 截断

    def banner(self) -> str:
        lines = [
            "",
            "=" * 60,
            f"  Agent Loop 完成: {self.total_steps} 步, "
            f"{self.tool_calls} 次工具调用, {self.total_ms / 1000:.2f}s",
        ]
        for h in self.history:
            tool_str = ""
            if h.tool_call:
                tool_str = f" [{h.tool_call.tool.value}({h.tool_call.args})]"
            status = "FINAL" if h.is_final else f"step {h.step}"
            lines.append(f"    {status:<8} {h.thought[:60]}{tool_str}")
        if self.truncated:
            lines.append("    ⚠️  因达到 max_steps 截断")
        lines.append("=" * 60)
        return "\n".join(lines)


# ============================================================
# ReAct Agent
# ============================================================

REACT_SYSTEM_TEMPLATE = """你是一个能调用工具的代码审计 Agent。

你的目标：通过多轮工具调用，验证或反驳一组审计发现。
你的工作模式是 ReAct 循环：
  Thought  → 思考下一步要做什么
  Action   → 调用工具（可选）
  Observation → 看工具返回结果
  Thought  → 根据结果继续思考
  ... 重复直到能给出最终结论

可用工具：
{tool_descriptions}

每一步你只需要输出一个 JSON 对象：
{{
  "thought": "你的思考，1-3 句话",
  "tool_call": {{
    "tool": "工具名",
    "args": {{...}},
    "reasoning": "为什么调这个工具"
  }},
  "is_final": false
}}

如果你想给出最终结论（不再调工具）：
{{
  "thought": "我已收集足够信息",
  "tool_call": null,
  "is_final": true
}}

重要规则：
1. 工具调用必须基于"我需要更多信息才能下结论"——不要为了调用而调用
2. 每次调用工具前必须明确 reasoning
3. 工具结果如果和你预期一致，不要重复调用相同工具
4. 最多 8 步——超过会被截断
5. 输出严格 JSON，不要 markdown 代码块
"""


class AgentLoop:
    """ReAct Agent 主循环"""

    def __init__(
        self,
        client: MultiModelClient,
        tool_registry: ToolRegistry,
        model: str = "gpt-4o",
        max_steps: int = 8,
        verbose: bool = False,
    ) -> None:
        self.cli = client
        self.tools = tool_registry
        self.model = model
        self.max_steps = max_steps
        self.verbose = verbose

    async def run(
        self,
        task: str,
        context: str = "",
    ) -> AgentRunResult:
        """
        跑一轮 Agent。
        task: 任务描述，例如 "验证这 3 个 finding 是否真的存在"
        context: 上下文信息，例如审计的代码 + 初步 findings
        """
        t0 = time.perf_counter()
        history: list[AgentHistoryEntry] = []
        messages = self._init_messages(task, context)

        for step in range(1, self.max_steps + 1):
            # 单步执行
            should_stop = await self._run_single_step(
                step, messages, history,
            )
            if should_stop:
                break

        # 构造最终输出
        final_summary = await self._compose_final_summary(
            task, context, history, messages,
        )

        total_ms = int((time.perf_counter() - t0) * 1000)
        tool_calls = sum(1 for h in history if h.tool_call)
        truncated = (len(history) >= self.max_steps
                     and not history[-1].is_final)

        return AgentRunResult(
            final_summary=final_summary,
            history=history,
            total_steps=len(history),
            total_ms=total_ms,
            tool_calls=tool_calls,
            truncated=truncated,
        )

    def _init_messages(self, task: str, context: str) -> list[dict[str, str]]:
        """初始化对话历史"""
        system_prompt = REACT_SYSTEM_TEMPLATE.format(
            tool_descriptions=self.tools.tool_descriptions(),
        )
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"# 任务\n{task}\n\n# 上下文\n{context}\n\n开始审计。"},
        ]

    async def _run_single_step(
        self,
        step: int,
        messages: list[dict[str, str]],
        history: list[AgentHistoryEntry],
    ) -> bool:
        """执行单步 Agent 循环，返回是否应停止"""
        # 调 LLM
        try:
            resp = await self.cli.chat(
                model=self.model,
                messages=messages,
                temperature=0.1,
                max_tokens=1024,
            )
        except Exception as e:
            history.append(AgentHistoryEntry(
                step=step, thought=f"LLM 调用失败: {e}",
                tool_call=None, tool_result=None,
                is_final=True, latency_ms=0,
            ))
            return True

        # 解析 AgentStep
        agent_step = self._parse_step(resp.content)
        if agent_step is None:
            history.append(AgentHistoryEntry(
                step=step, thought="LLM 输出无法解析，强制结束",
                tool_call=None, tool_result=None,
                is_final=True, latency_ms=resp.latency_ms,
            ))
            return True

        self._log_step(step, agent_step)

        # 如果是最终结论
        if agent_step.is_final or agent_step.tool_call is None:
            history.append(AgentHistoryEntry(
                step=step, thought=agent_step.thought,
                tool_call=None, tool_result=None,
                is_final=True, latency_ms=resp.latency_ms,
            ))
            return True

        # 执行工具
        tool_result = await self.tools.execute(
            agent_step.tool_call.tool, **agent_step.tool_call.args,
        )
        history.append(AgentHistoryEntry(
            step=step, thought=agent_step.thought,
            tool_call=agent_step.tool_call, tool_result=tool_result,
            is_final=False, latency_ms=resp.latency_ms,
        ))

        if self.verbose and tool_result:
            print(f"    ← {('OK' if tool_result.ok else 'FAIL')} "
                  f"({tool_result.latency_ms}ms)")

        # 把工具结果加入对话
        messages.append({"role": "assistant", "content": resp.content})
        messages.append({
            "role": "user",
            "content": f"工具结果:\n{tool_result.to_llm_message()}\n\n继续。如果是最终结论请把 is_final 设为 true，否则继续调用工具。",
        })

        # 收敛检测：连续两步工具调用相同 → 截断
        return self._detect_repeated_tool_call(history)

    def _log_step(self, step: int, agent_step: AgentStep) -> None:
        """verbose 模式下打印步骤"""
        if not self.verbose:
            return
        print(f"  [step {step}] {agent_step.thought[:80]}")
        if agent_step.tool_call:
            print(f"    → {agent_step.tool_call.tool.value}({agent_step.tool_call.args})")

    def _detect_repeated_tool_call(
        self, history: list[AgentHistoryEntry],
    ) -> bool:
        """检测连续两步是否调用相同工具，是则提前结束"""
        if len(history) < 2:
            return False
        prev = history[-2]
        curr = history[-1]
        if not (prev.tool_call and curr.tool_call):
            return False
        if (prev.tool_call.tool == curr.tool_call.tool
                and prev.tool_call.args == curr.tool_call.args):
            if self.verbose:
                print("  ⚠️ 检测到重复工具调用，提前结束")
            return True
        return False

    # -------- 内部 --------

    @staticmethod
    def _parse_step(content: str) -> AgentStep | None:
        """容错解析 LLM 输出为 AgentStep"""
        data = AgentLoop._parse_step_json(content)
        if data is None:
            return None
        return AgentLoop._build_step_from_data(data)

    @staticmethod
    def _parse_step_json(content: str) -> dict | None:
        """从 LLM 输出解析 JSON（剥离代码块 + 容错）"""
        import json
        import re
        text = content.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*\n", "", text)
            text = re.sub(r"\n```\s*$", "", text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            m = re.search(r"\{[\s\S]*\}", text)
            if not m:
                return None
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None

    @staticmethod
    def _build_step_from_data(data: dict) -> AgentStep | None:
        """从解析后的 dict 构造 AgentStep"""
        try:
            thought = data.get("thought", "")
            is_final = bool(data.get("is_final", False))
            tool_call = AgentLoop._build_tool_call(data.get("tool_call"))
            return AgentStep(
                thought=thought,
                tool_call=tool_call,
                is_final=is_final or (tool_call is None),
            )
        except Exception:
            return None

    @staticmethod
    def _build_tool_call(tc_data) -> ToolCall | None:
        """从 dict 构造 ToolCall"""
        if not (tc_data and isinstance(tc_data, dict)):
            return None
        tool_name = tc_data.get("tool")
        if not tool_name:
            return None
        try:
            tool_name = ToolName(tool_name)
        except ValueError:
            return None
        return ToolCall(
            tool=tool_name,
            args=tc_data.get("args", {}),
            reasoning=tc_data.get("reasoning", ""),
        )

    async def _compose_final_summary(
        self,
        task: str,
        context: str,
        history: list[AgentHistoryEntry],
        messages: list[dict[str, str]],
    ) -> str:
        """让 LLM 基于完整历史生成最终结构化总结"""
        # 把历史压缩成摘要
        history_text = []
        for h in history:
            line = f"[step {h.step}] {h.thought}"
            if h.tool_call:
                line += f" → {h.tool_call.tool.value}({h.tool_call.args})"
            if h.tool_result:
                line += f" → {'OK' if h.tool_result.ok else 'FAIL'}"
                # 工具结果截断
                output = h.tool_result.output[:500]
                line += f"\n    输出: {output}"
            history_text.append(line)

        summary_prompt = (
            f"# 原始任务\n{task}\n\n"
            f"# Agent 执行历史\n" + "\n".join(history_text) + "\n\n"
            "请基于以上历史，输出最终结论（中文，800-2000 字）：\n"
            "1. 你验证/反驳了哪些 finding？结论是什么？\n"
            "2. 引用具体证据（文件名 + 行号 + 代码片段）\n"
            "3. 给出最终严重度评级（critical/high/medium/low）\n"
            "4. 是否需要修复？给出具体修复建议"
        )

        try:
            resp = await self.cli.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是代码审计 Agent 的总结模块。基于执行历史，给出最终结构化结论。"},
                    {"role": "user", "content": summary_prompt},
                ],
                temperature=0.2,
                max_tokens=2048,
            )
            return resp.content
        except Exception as e:
            return f"(总结生成失败: {e})\n最后一步思考: {history[-1].thought if history else '(无)'}"
