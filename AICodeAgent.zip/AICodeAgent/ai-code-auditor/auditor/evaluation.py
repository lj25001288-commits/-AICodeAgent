"""
SWE-bench Style Evaluation Suite
================================

内置 20 个带"金标 bug"的代码样本，跑评估输出 P/R/F1。

每个样本包含：
- id: 唯一标识
- language: 语言
- code: 待审计代码
- expected_findings: 金标 bug 列表 [{location, category, severity, description_keyword}]
- description: 样本说明

评估流程：
1. 跑审计 pipeline
2. 把 LLM findings 和金标 bug 做匹配（location 模糊匹配 + description 关键词匹配）
3. 计算 P/R/F1
"""
from __future__ import annotations

import asyncio
import time
from .schemas import EvaluationResult, EvaluationSummary, GoldBug


# ============================================================
# 内置 20 个金标样本
# ============================================================

GOLD_SAMPLES: list[dict] = [
    # ============ Python 样本 ============
    {
        "id": "PY-001",
        "language": "python",
        "description": "SQL 注入 + 硬编码 key",
        "code": '''import pymysql

class UserDAO:
    def __init__(self):
        self.api_key = "sk-1234567890abcdef"
        self.conn = pymysql.connect(host="localhost")

    def get_user(self, user_id):
        sql = "SELECT * FROM users WHERE id = " + str(user_id)
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchone()
''',
        "expected_findings": [
            {"location": "__init__", "category": "security", "severity": "critical",
             "description_keyword": "硬编码"},
            {"location": "get_user", "category": "security", "severity": "critical",
             "description_keyword": "SQL"},
        ],
    },
    {
        "id": "PY-002",
        "language": "python",
        "description": "异常静默吞咽 + N+1 查询",
        "code": '''def get_user_names(user_ids):
    names = []
    for uid in user_ids:
        try:
            user = db.query("SELECT name FROM users WHERE id = %s", uid)
            names.append(user.name)
        except Exception:
            pass
    return names
''',
        "expected_findings": [
            {"location": "get_user_names", "category": "try_except_density", "severity": "high",
             "description_keyword": "异常"},
            {"location": "get_user_names", "category": "performance", "severity": "medium",
             "description_keyword": "N+1"},
        ],
    },
    {
        "id": "PY-003",
        "language": "python",
        "description": "路径穿越 + 命令注入",
        "code": '''import os
import subprocess

def read_file(user_path):
    full_path = "/data/files/" + user_path
    return open(full_path).read()

def run_cmd(filename):
    os.system(f"ls {filename}")
''',
        "expected_findings": [
            {"location": "read_file", "category": "security", "severity": "high",
             "description_keyword": "路径"},
            {"location": "run_cmd", "category": "security", "severity": "critical",
             "description_keyword": "命令"},
        ],
    },
    {
        "id": "PY-004",
        "language": "python",
        "description": "过度防御 + 过度抽象",
        "code": '''class Exporter:
    def __init__(self):
        self.rows = []
    def add(self, row):
        self.rows.append(row)
    def to_csv(self):
        return ",".join(str(r) for r in self.rows)

class CsvExporter(Exporter):
    pass

class JsonExporter(Exporter):
    def to_csv(self):
        import json
        return json.dumps(self.rows)

def create_user(name, email, age):
    if age < 0: return False
    if age > 200: return False
    if age == 0: return False
    if name == "": return False
    if name is None: return False
    if email == "": return False
    if email is None: return False
    if "@" not in email: return False
    return True
''',
        "expected_findings": [
            {"location": "create_user", "category": "defensive_overkill", "severity": "medium",
             "description_keyword": "过度"},
        ],
    },
    {
        "id": "PY-005",
        "language": "python",
        "description": "unused imports + 命名混用",
        "code": '''import os
import sys
import json
import re
import hashlib

def calcUserScore(userId, baseScore):
    if userId < 0: return 0
    return baseScore * 15 + userId * 23
''',
        "expected_findings": [
            {"location": "", "category": "unused_imports", "severity": "low",
             "description_keyword": "import"},
        ],
    },
    {
        "id": "PY-006",
        "language": "python",
        "description": "硬编码密码 + 弱哈希",
        "code": '''import hashlib

DB_PASSWORD = "admin123"

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def verify(password, hashed):
    return hash_password(password) == hashed
''',
        "expected_findings": [
            {"location": "", "category": "security", "severity": "critical",
             "description_keyword": "密码"},
            {"location": "hash_password", "category": "security", "severity": "high",
             "description_keyword": "md5"},
        ],
    },
    {
        "id": "PY-007",
        "language": "python",
        "description": "_pickle 反序列化漏洞",
        "code": '''import pickle
import base64

def load_user_data(data_str):
    data = base64.b64decode(data_str)
    return pickle.loads(data)
''',
        "expected_findings": [
            {"location": "load_user_data", "category": "security", "severity": "critical",
             "description_keyword": "pickle"},
        ],
    },
    {
        "id": "PY-008",
        "language": "python",
        "description": "docstring 撒谎 + 同步阻塞",
        "code": '''import requests

def batch_fetch_urls(urls):
    """
    批量并发获取多个 URL 内容。
    本方法使用了线程池并发，性能优秀。
    """
    results = []
    for url in urls:
        try:
            r = requests.get(url, timeout=30)
            results.append(r.text)
        except Exception:
            results.append(None)
    return results
''',
        "expected_findings": [
            {"location": "batch_fetch_urls", "category": "docstring_mismatch", "severity": "medium",
             "description_keyword": "docstring"},
            {"location": "batch_fetch_urls", "category": "performance", "severity": "medium",
             "description_keyword": "同步"},
        ],
    },
    # ============ JavaScript 样本 ============
    {
        "id": "JS-001",
        "language": "javascript",
        "description": "eval + innerXSS",
        "code": '''function runCode(code) {
    return eval(code);
}

function showUserInput(input) {
    document.getElementById("output").innerHTML = input;
}
''',
        "expected_findings": [
            {"location": "runCode", "category": "security", "severity": "critical",
             "description_keyword": "eval"},
            {"location": "showUserInput", "category": "security", "severity": "high",
             "description_keyword": "innerHTML"},
        ],
    },
    {
        "id": "JS-002",
        "language": "javascript",
        "description": "callback 嵌套地狱",
        "code": '''function fetchUser(id, cb) {
    fetch("/users/" + id).then(u => {
        u.json().then(user => {
            fetch("/posts/" + user.id).then(p => {
                p.json().then(posts => {
                    fetch("/comments/" + posts[0].id).then(c => {
                        c.json().then(comments => {
                            cb(comments);
                        });
                    });
                });
            });
        });
    });
}
''',
        "expected_findings": [
            {"location": "fetchUser", "category": "nesting_depth", "severity": "medium",
             "description_keyword": "嵌套"},
        ],
    },
    {
        "id": "JS-003",
        "language": "javascript",
        "description": "硬编码 + 不安全的比较",
        "code": '''const API_KEY = "sk-abc123xyz";

function checkPassword(input, stored) {
    if (input == stored) return true;
    return false;
}
''',
        "expected_findings": [
            {"location": "", "category": "security", "severity": "high",
             "description_keyword": "API_KEY"},
        ],
    },
    # ============ Go 样本 ============
    {
        "id": "GO-001",
        "language": "go",
        "description": "SQL 拼接 + 错误忽略",
        "code": '''package main

import (
    "database/sql"
    "fmt"
)

func GetUser(db *sql.DB, id string) *User {
    query := "SELECT * FROM users WHERE id = " + id
    rows, _ := db.Query(query)
    defer rows.Close()
    return nil
}
''',
        "expected_findings": [
            {"location": "GetUser", "category": "security", "severity": "critical",
             "description_keyword": "SQL"},
            {"location": "GetUser", "category": "logic", "severity": "medium",
             "description_keyword": "错误"},
        ],
    },
    # ============ 复杂 Python 样本 ============
    {
        "id": "PY-009",
        "language": "python",
        "description": "完整 UserManager（demo）",
        "code": '''import os
import sys
import json
import pymysql
import requests

class UserManager:
    def __init__(self, db_url, api_key="sk-1234567890abcdef"):
        self.api_key = api_key
        try:
            self.conn = pymysql.connect(db_url)
        except Exception as e:
            pass

    def get_user(self, user_id):
        try:
            cursor = self.conn.cursor()
            sql = "SELECT * FROM users WHERE id = " + str(user_id)
            cursor.execute(sql)
            return cursor.fetchone()
        except Exception:
            return None

    def create_user(self, name, email, age):
        sql = f"INSERT INTO users VALUES ('{name}', '{email}', {age})"
        cursor = self.conn.cursor()
        cursor.execute(sql)
        self.conn.commit()
        return True

    def update_email(self, user_id, email):
        resp = requests.get(
            f"https://api.validator.com/check?email={email}&key={self.api_key}",
            timeout=30,
        )
        sql = f"UPDATE users SET email = '{email}' WHERE id = {user_id}"
        cursor = self.conn.cursor()
        cursor.execute(sql)
''',
        "expected_findings": [
            {"location": "__init__", "category": "security", "severity": "high",
             "description_keyword": "硬编码"},
            {"location": "get_user", "category": "security", "severity": "critical",
             "description_keyword": "SQL"},
            {"location": "create_user", "category": "security", "severity": "critical",
             "description_keyword": "SQL"},
            {"location": "get_user", "category": "try_except_density", "severity": "high",
             "description_keyword": "异常"},
        ],
    },
    {
        "id": "PY-010",
        "language": "python",
        "description": "时间戳转字符串边界 bug",
        "code": '''def format_timestamp(ts):
    """把秒级时间戳转成 YYYY-MM-DD"""
    import datetime
    try:
        dt = datetime.datetime.fromtimestamp(ts)
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return None

def parse_date(date_str):
    """解析日期字符串，返回时间戳"""
    import datetime
    try:
        dt = datetime.datetime.strptime(date_str, "%Y-%m-%d")
        return dt.timestamp()
    except Exception:
        return 0
''',
        "expected_findings": [
            {"location": "parse_date", "category": "logic", "severity": "medium",
             "description_keyword": "0"},
        ],
    },
    {
        "id": "PY-011",
        "language": "python",
        "description": "线程不安全的单例",
        "code": '''class Singleton:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.cache = {}
''',
        "expected_findings": [
            {"location": "get_instance", "category": "logic", "severity": "medium",
             "description_keyword": "线程"},
        ],
    },
    {
        "id": "PY-012",
        "language": "python",
        "description": "递归无终止条件",
        "code": '''def fibonacci(n):
    return fibonacci(n - 1) + fibonacci(n - 2)

def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n - 1)
''',
        "expected_findings": [
            {"location": "fibonacci", "category": "logic", "severity": "high",
             "description_keyword": "递归"},
        ],
    },
    {
        "id": "PY-013",
        "language": "python",
        "description": "全局变量 + 副作用",
        "code": '''cache = {}

def add_to_cache(key, value):
    cache[key] = value

def get_from_cache(key):
    if key in cache:
        return cache[key]
    return None

def clear_cache():
    cache.clear()
''',
        "expected_findings": [
            {"location": "", "category": "best_practice", "severity": "low",
             "description_keyword": "全局"},
        ],
    },
    {
        "id": "PY-014",
        "language": "python",
        "description": "字符串拼接 + 性能",
        "code": '''def build_message(items):
    msg = ""
    for item in items:
        msg += str(item) + ", "
    return msg

def format_table(rows):
    output = ""
    for row in rows:
        line = ""
        for cell in row:
            line += str(cell) + " | "
        output += line + "\\n"
    return output
''',
        "expected_findings": [
            {"location": "build_message", "category": "performance", "severity": "low",
             "description_keyword": "拼接"},
        ],
    },
    {
        "id": "PY-015",
        "language": "python",
        "description": "密码学误用",
        "code": '''import random
import hashlib

def generate_token():
    return str(random.randint(100000, 999999))

def hash_password(password):
    return hashlib.sha1(password.encode()).hexdigest()

def generate_api_key():
    import time
    return hashlib.md5(str(time.time()).encode()).hexdigest()
''',
        "expected_findings": [
            {"location": "generate_token", "category": "security", "severity": "high",
             "description_keyword": "random"},
            {"location": "hash_password", "category": "security", "severity": "high",
             "description_keyword": "sha1"},
        ],
    },
    {
        "id": "PY-016",
        "language": "python",
        "description": "资源泄漏",
        "code": '''def read_config(path):
    f = open(path)
    data = f.read()
    return data

def write_log(path, msg):
    f = open(path, "a")
    f.write(msg)

def process_files(paths):
    results = []
    for p in paths:
        f = open(p)
        results.append(f.read())
    return results
''',
        "expected_findings": [
            {"location": "read_config", "category": "best_practice", "severity": "medium",
             "description_keyword": "close"},
        ],
    },
    {
        "id": "PY-017",
        "language": "python",
        "description": "空指针/None 解引用风险",
        "code": '''def get_user_email(user_id):
    user = db.find_user(user_id)
    return user.email

def process_order(order):
    customer = order.customer
    address = customer.address
    city = address.city
    return city
''',
        "expected_findings": [
            {"location": "get_user_email", "category": "logic", "severity": "medium",
             "description_keyword": "None"},
        ],
    },
]


# ============================================================
# 评估器
# ============================================================

class Evaluator:
    """跑评估集"""

    def __init__(
        self,
        audit_fn,                       # async (code, filename) -> findings_list
        verbose: bool = False,
    ) -> None:
        """
        audit_fn: 异步函数，输入代码和文件名，返回 findings 列表
                  findings 格式: [{location, severity, description, ...}]
        """
        self.audit_fn = audit_fn
        self.verbose = verbose

    async def evaluate_sample(self, sample: dict) -> EvaluationResult:
        """评估单样本"""
        t0 = time.perf_counter()
        # 决定文件名
        ext = {
            "python": ".py", "javascript": ".js", "typescript": ".ts",
            "go": ".go", "rust": ".rs", "java": ".java",
        }.get(sample["language"], ".py")
        filename = f"{sample['id']}{ext}"

        try:
            findings = await self.audit_fn(sample["code"], filename)
        except Exception as e:
            return EvaluationResult(
                sample_id=sample["id"],
                false_negatives=len(sample["expected_findings"]),
                findings_reported=[{"error": str(e)}],
            )
        latency_ms = int((time.perf_counter() - t0) * 1000)

        # 匹配
        tp, fp, fn = 0, 0, 0
        reported_list = []
        for ef in sample["expected_findings"]:
            matched = False
            for f in findings:
                if self._match_finding(f, ef):
                    matched = True
                    tp += 1
                    reported_list.append({
                        "expected": ef, "matched": f, "verdict": "TP",
                    })
                    break
            if not matched:
                fn += 1
                reported_list.append({
                    "expected": ef, "verdict": "FN",
                })

        # 多余的 findings 算误报
        matched_findings = {id(r["matched"]) for r in reported_list if r["verdict"] == "TP"}
        for f in findings:
            if id(f) not in matched_findings:
                fp += 1

        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-9)

        if self.verbose:
            print(f"  [{sample['id']}] TP={tp} FP={fp} FN={fn} "
                  f"P={precision:.2f} R={recall:.2f} F1={f1:.2f} {latency_ms}ms")

        return EvaluationResult(
            sample_id=sample["id"],
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            precision=precision,
            recall=recall,
            f1=f1,
            latency_ms=latency_ms,
            findings_reported=reported_list,
        )

    async def evaluate_all(
        self,
        samples: list[dict] | None = None,
        max_concurrency: int = 2,
    ) -> EvaluationSummary:
        """评估整个样本集"""
        if samples is None:
            samples = GOLD_SAMPLES

        sem = asyncio.Semaphore(max_concurrency)

        async def _eval_with_sem(s):
            async with sem:
                return await self.evaluate_sample(s)

        tasks = [_eval_with_sem(s) for s in samples]
        results = await asyncio.gather(*tasks)

        # 汇总
        total = len(results)
        avg_p = sum(r.precision for r in results) / max(total, 1)
        avg_r = sum(r.recall for r in results) / max(total, 1)
        avg_f1 = sum(r.f1 for r in results) / max(total, 1)
        avg_latency = sum(r.latency_ms for r in results) / max(total, 1)

        # 按严重度分组
        by_severity: dict[str, dict[str, float]] = {}
        for s in samples:
            for ef in s["expected_findings"]:
                sev = ef.get("severity", "info")
                if sev not in by_severity:
                    by_severity[sev] = {"precision": 0, "recall": 0, "count": 0}
                by_severity[sev]["count"] += 1
        # 简化：所有样本合并统计
        for sev in by_severity:
            tp_sev = sum(
                1 for r in results for f in r.findings_reported
                if f.get("verdict") == "TP"
                and f.get("expected", {}).get("severity") == sev
            )
            fn_sev = sum(
                1 for r in results for f in r.findings_reported
                if f.get("verdict") == "FN"
                and f.get("expected", {}).get("severity") == sev
            )
            count = by_severity[sev]["count"]
            by_severity[sev]["recall"] = tp_sev / max(tp_sev + fn_sev, 1)
            by_severity[sev]["precision"] = tp_sev / max(tp_sev, 1)  # 简化

        # 按语言分组
        by_language: dict[str, dict[str, float]] = {}
        for s, r in zip(samples, results):
            lang = s["language"]
            if lang not in by_language:
                by_language[lang] = {"precision": 0, "recall": 0, "f1": 0, "count": 0}
            by_language[lang]["precision"] += r.precision
            by_language[lang]["recall"] += r.recall
            by_language[lang]["f1"] += r.f1
            by_language[lang]["count"] += 1
        for lang in by_language:
            n = by_language[lang]["count"]
            for k in ("precision", "recall", "f1"):
                by_language[lang][k] /= n

        return EvaluationSummary(
            total_samples=total,
            avg_precision=avg_p,
            avg_recall=avg_r,
            avg_f1=avg_f1,
            avg_latency_ms=avg_latency,
            avg_tokens=0,  # 需要 audit_fn 注入
            by_severity=by_severity,
            by_language=by_language,
        )

    # -------- 匹配逻辑 --------

    @staticmethod
    def _match_finding(reported: dict, expected: dict) -> bool:
        """判断 reported finding 是否匹配 expected finding"""
        # 1. location 模糊匹配
        rep_loc = str(reported.get("location", "")).lower()
        exp_loc = str(expected.get("location", "")).lower()
        if exp_loc and exp_loc not in rep_loc and rep_loc not in exp_loc:
            # 尝试部分匹配
            if not (exp_loc in rep_loc or rep_loc in exp_loc):
                return False

        # 2. description 关键词匹配
        rep_desc = str(reported.get("description", "")).lower()
        rep_sugg = str(reported.get("suggestion", "")).lower()
        keyword = str(expected.get("description_keyword", "")).lower()
        if keyword:
            if keyword not in rep_desc and keyword not in rep_sugg:
                return False

        # 3. 严重度匹配（允许 expected=critical 匹配 reported=high）
        rep_sev = str(reported.get("severity", "info")).lower()
        exp_sev = str(expected.get("severity", "info")).lower()
        sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        rep_rank = sev_rank.get(rep_sev, 4)
        exp_rank = sev_rank.get(exp_sev, 4)
        # 允许 reported 比 expected 严重 1 级或更严重
        if rep_rank > exp_rank + 1:
            return False

        return True


# ============================================================
# 便捷入口
# ============================================================

def load_samples() -> list[GoldBug]:
    """加载所有金标样本为 GoldBug 对象"""
    return [GoldBug(**s) for s in GOLD_SAMPLES]


def summary_to_markdown(summary: EvaluationSummary) -> str:
    """把评估结果格式化为 markdown"""
    lines = [
        "# 评估结果汇总",
        "",
        f"- 总样本数: {summary.total_samples}",
        f"- 平均 Precision: {summary.avg_precision:.1%}",
        f"- 平均 Recall:    {summary.avg_recall:.1%}",
        f"- 平均 F1:        {summary.avg_f1:.1%}",
        f"- 平均耗时:       {summary.avg_latency_ms:.0f}ms",
        "",
        "## 按语言分组",
        "",
        "| 语言 | Precision | Recall | F1 | 样本数 |",
        "|------|-----------|--------|----|----|",
    ]
    for lang, m in sorted(summary.by_language.items()):
        lines.append(
            f"| {lang} | {m['precision']:.1%} | {m['recall']:.1%} | {m['f1']:.1%} | {m['count']} |"
        )
    lines.append("")
    lines.append("## 按严重度分组")
    lines.append("")
    lines.append("| 严重度 | Recall | 总数 |")
    lines.append("|--------|--------|------|")
    for sev, m in sorted(summary.by_severity.items()):
        lines.append(f"| {sev} | {m['recall']:.1%} | {m['count']} |")
    return "\n".join(lines)
