"""
Patch Generator
===============

从 LLM 报告中提取 unified diff patch，并应用。
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class PatchResult:
    """patch 应用结果"""
    success: bool
    applied_files: list[str]
    rejected_files: list[str]
    output: str


class PatchExtractor:
    """从 LLM 输出文本中提取所有 unified diff patch"""

    @staticmethod
    def extract(report: str) -> list[str]:
        """
        从 Markdown 报告中提取所有 ```diff ... ``` 代码块。
        也能识别不带语言标签的 ```diff 形式。
        """
        # 匹配 ```diff ... ``` 或 ``` ... ```（内容必须以 --- / +++ 开头）
        patches: list[str] = []
        pattern = r"```(?:diff)?\s*\n(---\s.*?```)"
        for m in re.finditer(pattern, report, re.DOTALL):
            block = m.group(1)
            # 去掉结尾的 ```
            block = block.rstrip("`").rstrip()
            if block.startswith("--- ") and "+++" in block:
                patches.append(block)
        return patches

    @staticmethod
    def extract_to_files(report: str, output_dir: str = ".") -> list[Path]:
        """把提取出的 patch 写成独立 .patch 文件"""
        patches = PatchExtractor.extract(report)
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []
        for i, p in enumerate(patches, 1):
            path = out_dir / f"fix-{i:02d}.patch"
            path.write_text(p + "\n", encoding="utf-8")
            written.append(path)
        return written


class PatchApplier:
    """应用 patch 到工作区"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    def apply(self, patch_text: str, check: bool = True) -> PatchResult:
        """应用 patch。check=True 时先做 dry-run。"""
        if check:
            # dry-run
            r = subprocess.run(
                ["git", "apply", "--check", "-"],
                cwd=self.cwd,
                input=patch_text,
                text=True,
                capture_output=True,
                timeout=10,
            )
            if r.returncode != 0:
                return PatchResult(
                    success=False, applied_files=[], rejected_files=["<unknown>"],
                    output=f"Dry-run failed:\n{r.stderr}",
                )

        r = subprocess.run(
            ["git", "apply", "-"],
            cwd=self.cwd,
            input=patch_text,
            text=True,
            capture_output=True,
            timeout=10,
        )
        if r.returncode != 0:
            return PatchResult(
                success=False, applied_files=[], rejected_files=["<unknown>"],
                output=r.stderr,
            )

        # 解析涉及的文件
        applied: list[str] = []
        for line in patch_text.splitlines():
            if line.startswith("+++ b/"):
                applied.append(line[6:].strip())
            elif line.startswith("+++ ") and line != "+++ /dev/null":
                applied.append(line[4:].strip())

        return PatchResult(
            success=True, applied_files=applied, rejected_files=[],
            output=f"成功应用到 {len(applied)} 个文件",
        )

    def apply_files(self, patch_paths: list[str], check: bool = True) -> list[PatchResult]:
        """批量应用 patch 文件"""
        results: list[PatchResult] = []
        for p in patch_paths:
            text = Path(p).read_text(encoding="utf-8")
            results.append(self.apply(text, check=check))
        return results
