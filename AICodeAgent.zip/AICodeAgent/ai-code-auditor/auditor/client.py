"""
Multi-Model OpenAI-Compatible Client (v2)
=========================================

升级点：
1. 流式输出 (SSE) —— 实时看到模型在审什么
2. 多模型 fallback —— 主模型挂了自动切备选
3. 并发限流 —— 避免中转站 429
4. 细粒度 token 计量 —— prompt / completion / cached 分开
5. 调用统计 —— 全程累计 token、耗时、调用次数
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx


@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0  # 部分 provider 返回 prompt_tokens_details
    reasoning_tokens: int = 0  # reasoning 模型（如 glm-5.2/o1）的推理 token

    def add(self, other: "Usage") -> None:
        self.prompt_tokens += other.prompt_tokens
        self.completion_tokens += other.completion_tokens
        self.total_tokens += other.total_tokens
        self.cached_tokens += other.cached_tokens
        self.reasoning_tokens += other.reasoning_tokens

    @property
    def content_tokens(self) -> int:
        """实际输出 content 消耗的 token（= completion - reasoning）"""
        return max(0, self.completion_tokens - self.reasoning_tokens)


@dataclass
class ModelResponse:
    content: str
    model: str
    usage: Usage
    latency_ms: int
    reasoning_content: str = ""  # reasoning 模型的推理过程（如 glm-5.2 的 reasoning_content 字段）
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def is_empty_content(self) -> bool:
        """reasoning 占满 token 导致 content 为空"""
        return not self.content.strip() and self.usage.reasoning_tokens > 0

    def __repr__(self) -> str:
        rs = f" reasoning={self.usage.reasoning_tokens}" if self.usage.reasoning_tokens else ""
        empty = " ⚠️empty" if self.is_empty_content else ""
        return (
            f"<ModelResponse model={self.model} "
            f"in={self.usage.prompt_tokens} out={self.usage.completion_tokens}{rs} "
            f"cached={self.usage.cached_tokens} {self.latency_ms}ms{empty}>"
        )


@dataclass
class CallStats:
    """全程调用统计"""
    total_calls: int = 0
    total_tokens: Usage = field(default_factory=Usage)
    by_model: dict[str, Usage] = field(default_factory=dict)
    by_role: dict[str, Usage] = field(default_factory=dict)
    failures: int = 0

    def record(self, role: str, model: str, usage: Usage) -> None:
        self.total_calls += 1
        self.total_tokens.add(usage)
        self.by_model.setdefault(model, Usage()).add(usage)
        self.by_role.setdefault(role, Usage()).add(usage)

    def fail(self) -> None:
        self.failures += 1

    def summary(self) -> str:
        lines = [f"  总调用次数: {self.total_calls} (失败 {self.failures})"]
        lines.append(
            f"  总 token: 输入 {self.total_tokens.prompt_tokens:,} + "
            f"输出 {self.total_tokens.completion_tokens:,} = "
            f"{self.total_tokens.total_tokens:,}"
        )
        if self.total_tokens.cached_tokens:
            lines.append(f"  命中缓存: {self.total_tokens.cached_tokens:,} tokens")
        if self.total_tokens.reasoning_tokens:
            pct = self.total_tokens.reasoning_tokens / max(self.total_tokens.completion_tokens, 1) * 100
            lines.append(
                f"  ⚠️ reasoning token: {self.total_tokens.reasoning_tokens:,} "
                f"(占输出 {pct:.0f}%)"
            )
        lines.append("  各模型消耗:")
        for m, u in sorted(self.by_model.items(), key=lambda x: -x[1].total_tokens):
            lines.append(f"    {m:<40} {u.total_tokens:>8,} tokens")
        lines.append("  各角色消耗:")
        for r, u in sorted(self.by_role.items(), key=lambda x: -x[1].total_tokens):
            lines.append(f"    {r:<24} {u.total_tokens:>8,} tokens")
        return "\n".join(lines)


class MultiModelClient:
    """
    用法：
        async with MultiModelClient(base_url=..., api_key=...) as cli:
            # 单模型调用（带 fallback）
            resp = await cli.chat_with_fallback(
                role="logic_auditor",
                candidates=["claude-3-5-sonnet-20241022", "gpt-4o"],
                messages=[...],
            )

            # 流式调用
            async for chunk in cli.chat_stream(model="gpt-4o", messages=[...]):
                print(chunk, end="", flush=True)

            # 查看统计
            print(cli.stats.summary())
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 180.0,
        max_retries: int = 3,
        max_concurrency: int = 4,
    ) -> None:
        if not base_url.rstrip("/").endswith("/v1"):
            base_url = base_url.rstrip("/") + "/v1"
        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self._sem = asyncio.Semaphore(max_concurrency)
        self._client: httpx.AsyncClient | None = None
        self.stats = CallStats()

    async def __aenter__(self) -> "MultiModelClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
            },
            timeout=httpx.Timeout(self.timeout, connect=10.0),
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
        )
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # -------- 单次调用（带重试） --------

    async def chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int | None = None,
        response_format: dict | None = None,
        **kwargs: Any,
    ) -> ModelResponse:
        assert self._client is not None, "必须 async with"

        payload = self._build_chat_payload(
            model, messages, temperature, max_tokens, response_format, kwargs,
        )
        return await self._chat_with_retry(model, payload)

    def _build_chat_payload(
        self, model: str, messages: list[dict], temperature: float,
        max_tokens: int | None, response_format: dict | None, kwargs: dict,
    ) -> dict[str, Any]:
        """构造 chat completions 请求体"""
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            **kwargs,
        }
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if response_format is not None:
            payload["response_format"] = response_format
        return payload

    async def _chat_with_retry(
        self, model: str, payload: dict[str, Any],
    ) -> ModelResponse:
        """带重试的 chat 调用"""
        last_exc: Exception | None = None
        async with self._sem:
            for attempt in range(1, self.max_retries + 1):
                try:
                    return await self._do_chat_request(model, payload)
                except httpx.HTTPStatusError as e:
                    last_exc = e
                    if 400 <= e.response.status_code < 500:
                        raise RuntimeError(
                            f"[{model}] HTTP {e.response.status_code}: "
                            f"{e.response.text[:500]}"
                        ) from e
                    await asyncio.sleep(min(0.5 * (2 ** (attempt - 1)), 8.0))
                except (httpx.TimeoutException, httpx.NetworkError) as e:
                    last_exc = e
                    await asyncio.sleep(min(0.5 * (2 ** (attempt - 1)), 8.0))
        raise RuntimeError(f"[{model}] 重试 {self.max_retries} 次仍失败: {last_exc}")

    async def _do_chat_request(
        self, model: str, payload: dict[str, Any],
    ) -> ModelResponse:
        """执行单次 chat 请求并解析响应"""
        t0 = time.perf_counter()
        r = await self._client.post("/chat/completions", json=payload)
        r.raise_for_status()
        data = r.json()
        latency_ms = int((time.perf_counter() - t0) * 1000)
        usage = self._parse_usage(data.get("usage", {}))
        msg = data.get("choices", [{}])[0].get("message", {})
        return ModelResponse(
            content=msg.get("content") or "",
            model=data.get("model", model),
            usage=usage,
            latency_ms=latency_ms,
            reasoning_content=msg.get("reasoning_content") or "",
            raw=data,
        )

    async def chat_with_reasoning_recovery(
        self,
        model: str,
        messages: list[dict[str, str]],
        max_tokens: int = 4096,
        max_recovery_attempts: int = 2,
        reasoning_budget_ratio: float = 3.0,
        **kwargs: Any,
    ) -> ModelResponse:
        """
        带 reasoning 恢复的 chat：
        如果第一次返回的 content 为空但 reasoning_tokens > 0（reasoning 占满），
        自动把 max_tokens 扩大 reasoning_budget_ratio 倍重试。

        这是 reasoning 模型（如 glm-5.2 / o1）在结构化 JSON 输出任务上的真实问题：
        模型会把所有 max_tokens 用在 reasoning_content 上，content 字段为空。

        用法：
            resp = await cli.chat_with_reasoning_recovery(
                model="glm-5.2",
                messages=[...],
                max_tokens=8192,
            )
            # resp.content 保证非空（除非真的超过 max_recovery_attempts）
        """
        current_max = max_tokens
        last_resp: ModelResponse | None = None
        for attempt in range(max_recovery_attempts + 1):
            resp = await self.chat(
                model=model, messages=messages,
                max_tokens=current_max, **kwargs,
            )
            last_resp = resp
            if not resp.is_empty_content:
                return resp
            # content 为空 + reasoning > 0 → 扩容重试
            if attempt < max_recovery_attempts:
                current_max = int(current_max * reasoning_budget_ratio)
                # 不超过模型上下文限制（按 32K 算）
                current_max = min(current_max, 32768)
                continue
        # 所有恢复尝试都失败，返回最后一次（content 为空）
        return last_resp  # type: ignore[return-value]

    async def chat_with_fallback(
        self,
        role: str,
        candidates: list[str],
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> ModelResponse:
        """主备模型链：第一个挂了用第二个，依次类推"""
        assert candidates, "candidates 不能为空"
        last_exc: Exception | None = None
        for i, model in enumerate(candidates):
            try:
                resp = await self.chat(model=model, messages=messages, **kwargs)
                self.stats.record(role, resp.model, resp.usage)
                return resp
            except Exception as e:
                last_exc = e
                self.stats.fail()
                if i < len(candidates) - 1:
                    # 还有备选，继续
                    continue
                raise
        raise RuntimeError(f"所有候选模型都失败: {last_exc}")

    # -------- 流式调用 --------

    async def chat_stream(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int | None = None,
    ) -> AsyncIterator[str]:
        """流式输出 token，便于 CLI 实时打印"""
        assert self._client is not None, "必须 async with"
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        async with self._sem:
            async with self._client.stream(
                "POST", "/chat/completions", json=payload
            ) as r:
                r.raise_for_status()
                usage_buf: dict[str, Any] = {}
                async for line in r.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:].strip()
                    if data_str == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    if chunk.get("usage"):
                        usage_buf = chunk["usage"]
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    if "content" in delta and delta["content"]:
                        yield delta["content"]

                # 把 usage 记下来，调用方可通过 stats 查
                if usage_buf:
                    self.stats.record("stream", model, self._parse_usage(usage_buf))

    # -------- 并发批量 --------

    async def chat_batch(
        self,
        calls: list[dict[str, Any]],
    ) -> list[ModelResponse | Exception]:
        """
        并发调用多个模型，返回结果列表（顺序对应）。
        不会因为单个失败而整体失败——失败的项返回 Exception 对象。
        """
        return await asyncio.gather(*[self._run_batch_call(c.copy()) for c in calls])

    async def _run_batch_call(self, c: dict[str, Any]) -> ModelResponse | Exception:
        """执行单个 batch 调用，异常时返回 Exception 而非抛出"""
        try:
            role = c.pop("role", "batch")
            candidates = c.pop("candidates", None)
            if candidates:
                return await self.chat_with_fallback(role, candidates, **c)
            return await self.chat(**c)
        except Exception as e:
            return e

    # -------- Pydantic 结构化输出 --------

    async def chat_structured(
        self,
        model: str,
        messages: list[dict[str, str]],
        response_model: type,
        max_retries: int = 2,
        **kwargs: Any,
    ):
        """
        调用 LLM 并返回符合 Pydantic schema 的结构化对象。
        失败时自动重试，把 validation 错误反馈给 LLM 修正。
        """
        current_messages = list(messages)
        last_error = None

        for attempt in range(max_retries + 1):
            if last_error and attempt > 0:
                current_messages.append({
                    "role": "user",
                    "content": (
                        f"上次输出无法通过 schema 校验：\n{last_error}\n\n"
                        f"请严格按 schema 重新输出，只输出 JSON，不要 markdown 代码块。"
                    ),
                })
            result = await self._try_chat_structured_once(
                model, current_messages, response_model, kwargs,
            )
            if isinstance(result, str):
                last_error = result
                continue
            return result

        raise RuntimeError(
            f"Pydantic 结构化输出失败，重试 {max_retries} 次仍不通过: {last_error}"
        )

    async def _try_chat_structured_once(
        self, model: str, messages: list[dict],
        response_model: type, kwargs: dict,
    ):
        """单次结构化输出尝试，返回 Pydantic 对象或错误字符串"""
        from pydantic import ValidationError
        import json
        import re

        try:
            resp = await self.chat(
                model=model, messages=messages,
                temperature=kwargs.get("temperature", 0.1),
                max_tokens=kwargs.get("max_tokens", 4096),
            )
        except Exception as e:
            raise RuntimeError(f"LLM 调用失败: {e}")

        content = self._strip_code_fence(resp.content)
        data = self._parse_json_lenient(content)
        if data is None:
            return "输出不是有效 JSON"
        try:
            return response_model.model_validate(data)
        except ValidationError as e:
            return str(e)[:500]

    @staticmethod
    def _strip_code_fence(content: str) -> str:
        """剥离 ```json ... ``` 代码块"""
        import re
        content = content.strip()
        if content.startswith("```"):
            content = re.sub(r"^```(?:json)?\s*\n", "", content)
            content = re.sub(r"\n```\s*$", "", content)
        return content

    @staticmethod
    def _parse_json_lenient(content: str) -> dict | None:
        """容错 JSON 解析"""
        import json
        import re
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            m = re.search(r"\{[\s\S]*\}", content)
            if not m:
                return None
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None

    # -------- 内部 --------

    @staticmethod
    def _parse_usage(raw: dict[str, Any]) -> Usage:
        prompt = raw.get("prompt_tokens", 0)
        completion = raw.get("completion_tokens", 0)
        total = raw.get("total_tokens", prompt + completion)
        # OpenAI / 部分 provider 在 prompt_tokens_details 里返回 cached_tokens
        cached = 0
        details = raw.get("prompt_tokens_details") or {}
        if isinstance(details, dict):
            cached = details.get("cached_tokens", 0)
        # reasoning 模型（如 glm-5.2 / o1）在 completion_tokens_details 里返回 reasoning_tokens
        reasoning = 0
        completion_details = raw.get("completion_tokens_details") or {}
        if isinstance(completion_details, dict):
            reasoning = completion_details.get("reasoning_tokens", 0)
        return Usage(
            prompt_tokens=prompt,
            completion_tokens=completion,
            total_tokens=total,
            cached_tokens=cached,
            reasoning_tokens=reasoning,
        )
