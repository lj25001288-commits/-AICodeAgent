"""
AST-based Static Analyzer
=========================

用 Python ast 模块把代码结构化，量化 8 类 AI 生成代码 smell 信号。
这些信号作为 LLM 审计的"重点区域标记"——不是把整个文件无脑丢给模型，
而是先告诉模型"这里 try/except 密度异常"、"这里函数复杂度爆表"。

8 类信号：
1. try_except_density    — 异常吞咽密度（裸 except / except Exception: pass）
2. defensive_overkill    — 过度防御性检查（连续 5+ 个独立 if return）
3. unused_imports        — import 了但没用的模块
4. complexity_hotspots   — 圈复杂度 > 10 的函数
5. nesting_depth         — 嵌套深度 > 4 的代码块
6. naming_inconsistency  — 同一函数内 camelCase / snake_case 混用
7. docstring_mismatch    — docstring 长度 / 函数体长度 比例异常
8. magic_numbers         — 函数内魔法数字 > 5 个
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Literal


SmellCategory = Literal[
    "try_except_density",
    "defensive_overkill",
    "unused_imports",
    "complexity_hotspots",
    "nesting_depth",
    "naming_inconsistency",
    "docstring_mismatch",
    "magic_numbers",
]


@dataclass
class SmellSignal:
    category: SmellCategory
    location: str           # 函数名/类名 + 行号
    line_start: int
    line_end: int
    severity: str           # high / medium / low
    detail: str             # 具体证据
    evidence: str = ""      # 代码片段


@dataclass
class FunctionProfile:
    name: str
    line_start: int
    line_end: int
    line_count: int
    complexity: int                # 圈复杂度（ McCabe ）
    max_nesting: int
    try_except_count: int
    bare_except_count: int         # except: 或 except Exception:
    pass_in_except: int            # except 块里直接 pass
    sequential_guard_count: int    # 连续 if-return 检查数
    magic_numbers: list[str]
    docstring_lines: int
    has_docstring: bool
    naming_styles: dict[str, int]  # {"snake": n, "camel": n, "pascal": n}


@dataclass
class StaticReport:
    file: str
    language: str
    line_count: int
    function_profiles: list[FunctionProfile] = field(default_factory=list)
    smells: list[SmellSignal] = field(default_factory=list)
    overall_smell_score: float = 0.0     # AI 风格评分：0-100，越低越好（越不像 AI 写的）
    quality_score: float = 0.0           # 代码质量评分：0-100，越高越好（工程质量越好）

    def top_smells(self, k: int = 10) -> list[SmellSignal]:
        """按严重度排序，取 top-k"""
        order = {"high": 0, "medium": 1, "low": 2}
        return sorted(self.smells, key=lambda s: (order[s.severity], s.line_start))[:k]

    def summary(self) -> str:
        return (
            f"  静态分析: {self.line_count} 行, "
            f"{len(self.function_profiles)} 函数, "
            f"{len(self.smells)} smell 信号, "
            f"AI 风格评分 {self.overall_smell_score:.1f}/100 (越低越好), "
            f"代码质量评分 {self.quality_score:.1f}/100 (越高越好)"
        )


# ============================================================
# 主分析器
# ============================================================

class PythonAnalyzer:
    """Python AST 分析器"""

    def analyze(self, source: str, filename: str = "<code>") -> StaticReport:
        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            return StaticReport(
                file=filename, language="python",
                line_count=source.count("\n") + 1,
                overall_smell_score=-1,
            ).__class__(
                file=filename, language="python",
                line_count=source.count("\n") + 1,
                smells=[SmellSignal(
                    category="complexity_hotspots",
                    location=f"<file:{e.lineno}>",
                    line_start=e.lineno or 0, line_end=e.lineno or 0,
                    severity="high", detail=f"语法错误: {e.msg}",
                )],
            )

        lines = source.splitlines()
        report = StaticReport(
            file=filename, language="python", line_count=len(lines),
        )

        # 收集所有顶层 import，做 unused 检测
        imports = self._collect_imports(tree)

        # 逐函数 / 方法分析
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                profile = self._profile_function(node, lines)
                report.function_profiles.append(profile)
                report.smells.extend(self._detect_smells(profile))

        # unused imports
        report.smells.extend(self._detect_unused_imports(tree, source, imports))

        # 全局 smell 评分
        report.overall_smell_score = self._compute_smell_score(report)
        report.quality_score = self._compute_quality_score(report)
        return report

    # -------- 函数画像 --------

    def _profile_function(
        self, node: ast.FunctionDef | ast.AsyncFunctionDef, lines: list[str],
    ) -> FunctionProfile:
        line_start = node.lineno
        line_end = max(
            (n.lineno for n in ast.walk(node) if hasattr(n, "lineno")),
            default=line_start,
        )
        line_count = line_end - line_start + 1

        # try/except 统计
        try_stats = self._count_try_except(node)

        # 命名风格统计
        naming_styles = self._count_naming_styles(node)

        return FunctionProfile(
            name=node.name, line_start=line_start, line_end=line_end,
            line_count=line_count,
            complexity=self._compute_complexity(node),
            max_nesting=self._max_nesting(node),
            try_except_count=try_stats[0],
            bare_except_count=try_stats[1],
            pass_in_except=try_stats[2],
            sequential_guard_count=self._count_sequential_guards(node),
            magic_numbers=self._collect_magic_numbers(node),
            docstring_lines=(
                len(ast.get_docstring(node).splitlines())
                if ast.get_docstring(node) else 0
            ),
            has_docstring=ast.get_docstring(node) is not None,
            naming_styles=naming_styles,
        )

    @staticmethod
    def _count_try_except(node: ast.AST) -> tuple[int, int, int]:
        """统计 try/except 数量，返回 (try_count, bare_except, pass_in_except)"""
        try_count = 0
        bare_except_count = 0
        pass_in_except = 0
        for sub in ast.walk(node):
            if not isinstance(sub, ast.Try):
                continue
            try_count += 1
            for handler in sub.handlers:
                is_bare = handler.type is None or (
                    isinstance(handler.type, ast.Name)
                    and handler.type.id in ("Exception", "BaseException")
                )
                if not is_bare:
                    continue
                bare_except_count += 1
                # 检查 handler body 是不是只有 pass / return None
                body = handler.body
                if len(body) == 1 and isinstance(body[0], ast.Pass):
                    pass_in_except += 1
                elif (
                    len(body) == 1
                    and isinstance(body[0], ast.Return)
                    and (body[0].value is None)
                ):
                    pass_in_except += 1
        return try_count, bare_except_count, pass_in_except

    def _count_naming_styles(self, node: ast.AST) -> dict[str, int]:
        """命名风格统计（变量名 + 函数名 + 参数）"""
        naming_styles = {"snake": 0, "camel": 0, "pascal": 0, "single": 0, "other": 0}
        for sub in ast.walk(node):
            if isinstance(sub, (ast.Name, ast.arg)):
                name = getattr(sub, "arg", None) or sub.id
                style = self._naming_style(name)
                naming_styles[style] += 1
        return naming_styles

    def _compute_complexity(self, node: ast.AST) -> int:
        """McCabe 圈复杂度：起点 1，每个分支 / 循环 / 异常处理 +1"""
        c = 1
        for sub in ast.walk(node):
            if isinstance(sub, (ast.If, ast.IfExp)):
                c += 1
            elif isinstance(sub, (ast.For, ast.While, ast.AsyncFor)):
                c += 1
            elif isinstance(sub, ast.ExceptHandler):
                c += 1
            elif isinstance(sub, (ast.BoolOp,)):
                c += len(sub.values) - 1
        return c

    def _max_nesting(self, node: ast.AST) -> int:
        """最大嵌套深度"""
        def _depth(n: ast.AST, current: int = 0) -> int:
            max_d = current
            for child in ast.iter_child_nodes(n):
                if isinstance(child, (
                    ast.If, ast.For, ast.While, ast.With,
                    ast.Try, ast.AsyncFor, ast.AsyncWith,
                    ast.FunctionDef, ast.AsyncFunctionDef,
                )):
                    max_d = max(max_d, _depth(child, current + 1))
                else:
                    max_d = max(max_d, _depth(child, current))
            return max_d
        return _depth(node)

    def _count_sequential_guards(
        self, node: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> int:
        """统计函数开头连续的 if ... return 检查数量"""
        guards = 0
        for stmt in node.body:
            if isinstance(stmt, ast.If):
                # if 体里只有 return / raise
                body = stmt.body
                if len(body) == 1 and isinstance(body[0], (ast.Return, ast.Raise)):
                    guards += 1
                    continue
            break
        return guards

    def _collect_magic_numbers(self, node: ast.AST) -> list[str]:
        """收集字面量数字（除 0、1、-1、2 之外都算魔法数字）"""
        nums: list[str] = []
        for sub in ast.walk(node):
            if isinstance(sub, ast.Constant) and isinstance(sub.value, (int, float)):
                v = sub.value
                if isinstance(v, int) and v in (-1, 0, 1, 2):
                    continue
                nums.append(str(v))
        return nums

    @staticmethod
    def _naming_style(name: str) -> str:
        """分类命名风格（dispatch table 替代 if-return 链）"""
        if not name or name == "_" or len(name) == 1:
            return "single" if name else "other"
        # 按优先级匹配（snake > camel > pascal）
        patterns = [
            ("snake",  r"_*[a-z][a-z0-9_]*"),
            ("camel",  r"_*[a-z][a-zA-Z0-9]*"),
            ("pascal", r"_*[A-Z][a-zA-Z0-9]*"),
        ]
        for style, pattern in patterns:
            if re.fullmatch(pattern, name):
                if style == "camel" and "_" in name:
                    continue
                return style
        return "other"

    # -------- smell 检测 --------

    def _detect_smells(self, p: FunctionProfile) -> list[SmellSignal]:
        """主入口：调用各 smell 检测器并合并结果"""
        detectors = [
            self._smell_try_except_density,
            self._smell_defensive_overkill,
            self._smell_complexity,
            self._smell_nesting,
            self._smell_naming_mixing,
            self._smell_docstring_mismatch,
            self._smell_magic_numbers,
        ]
        smells: list[SmellSignal] = []
        for detector in detectors:
            smells.extend(detector(p))
        return smells

    @staticmethod
    def _smell_try_except_density(p: FunctionProfile) -> list[SmellSignal]:
        """try/except 滥用检测"""
        if p.pass_in_except >= 2:
            return [SmellSignal(
                category="try_except_density",
                location=f"{p.name}() L{p.line_start}-{p.line_end}",
                line_start=p.line_start, line_end=p.line_end,
                severity="high" if p.pass_in_except >= 3 else "medium",
                detail=(
                    f"函数内 {p.pass_in_except} 处 except 直接 pass/return None，"
                    f"异常被静默吞掉，bug 会被埋到生产环境"
                ),
            )]
        if p.bare_except_count >= 1 and p.try_except_count >= 2:
            return [SmellSignal(
                category="try_except_density",
                location=f"{p.name}() L{p.line_start}",
                line_start=p.line_start, line_end=p.line_end,
                severity="medium",
                detail=f"裸 except Exception 出现 {p.bare_except_count} 次",
            )]
        return []

    @staticmethod
    def _smell_defensive_overkill(p: FunctionProfile) -> list[SmellSignal]:
        """过度防御检测"""
        if p.sequential_guard_count < 5:
            return []
        return [SmellSignal(
            category="defensive_overkill",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="medium" if p.sequential_guard_count < 8 else "high",
            detail=(
                f"函数开头连续 {p.sequential_guard_count} 个 if-return 检查，"
                f"典型的 AI 过度防御模式，应该用数据类校验或提前 return"
            ),
        )]

    @staticmethod
    def _smell_complexity(p: FunctionProfile) -> list[SmellSignal]:
        """圈复杂度检测"""
        if p.complexity < 15:
            return []
        return [SmellSignal(
            category="complexity_hotspots",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="high" if p.complexity >= 20 else "medium",
            detail=f"圈复杂度 {p.complexity}，建议拆分",
        )]

    @staticmethod
    def _smell_nesting(p: FunctionProfile) -> list[SmellSignal]:
        """嵌套深度检测"""
        if p.max_nesting < 4:
            return []
        return [SmellSignal(
            category="nesting_depth",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="medium" if p.max_nesting < 6 else "high",
            detail=f"最大嵌套深度 {p.max_nesting}",
        )]

    @staticmethod
    def _smell_naming_mixing(p: FunctionProfile) -> list[SmellSignal]:
        """命名风格混用检测"""
        if not (p.naming_styles.get("snake", 0) > 0 and p.naming_styles.get("camel", 0) > 0):
            return []
        if sum(p.naming_styles.values()) < 5:  # 排除小函数
            return []
        return [SmellSignal(
            category="naming_inconsistency",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="low",
            detail=(
                f"snake_case {p.naming_styles['snake']} 个 + "
                f"camelCase {p.naming_styles['camel']} 个，"
                f"AI 生成代码常见问题"
            ),
        )]

    @staticmethod
    def _smell_docstring_mismatch(p: FunctionProfile) -> list[SmellSignal]:
        """docstring 比例失调检测"""
        if not p.has_docstring or p.line_count <= 5:
            return []
        ratio = p.docstring_lines / p.line_count
        if ratio <= 0.5:
            return []
        return [SmellSignal(
            category="docstring_mismatch",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="low",
            detail=(
                f"docstring 占函数 {ratio:.0%}，"
                f"AI 经常写很长 docstring 但实现很简陋"
            ),
        )]

    @staticmethod
    def _smell_magic_numbers(p: FunctionProfile) -> list[SmellSignal]:
        """魔法数字检测"""
        if len(p.magic_numbers) < 5:
            return []
        return [SmellSignal(
            category="magic_numbers",
            location=f"{p.name}() L{p.line_start}",
            line_start=p.line_start, line_end=p.line_end,
            severity="low",
            detail=f"函数内 {len(p.magic_numbers)} 个魔法数字: {p.magic_numbers[:5]}",
        )]

    def _collect_imports(self, tree: ast.AST) -> list[tuple[str, str | None, int]]:
        """返回 [(模块名, asname 或别名, 行号)]"""
        imports: list[tuple[str, str | None, int]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name.split(".")[0]
                    imports.append((name, alias.asname, node.lineno))
            elif isinstance(node, ast.ImportFrom):
                # __future__ import 不算 unused（如 from __future__ import annotations）
                if node.module == "__future__":
                    continue
                for alias in node.names:
                    name = alias.asname or alias.name
                    imports.append((name, alias.asname, node.lineno))
        return imports

    def _detect_unused_imports(
        self, tree: ast.AST, source: str, imports: list[tuple[str, str | None, int]],
    ) -> list[SmellSignal]:
        """检查 import 的名字在文件其他地方有没有被引用"""
        smells: list[SmellSignal] = []
        used_names = self._collect_used_names(tree)

        for name, _asname, lineno in imports:
            if name == "*":
                continue
            if name not in used_names:
                smells.append(SmellSignal(
                    category="unused_imports",
                    location=f"L{lineno}",
                    line_start=lineno, line_end=lineno,
                    severity="low",
                    detail=f"import 了 `{name}` 但全文未使用",
                ))
        return smells

    @staticmethod
    def _collect_used_names(tree: ast.AST) -> set[str]:
        """收集文件中所有"被使用"的名字：Name 引用 + 属性访问 + __all__ 导出"""
        used: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                used.add(node.id)
            elif isinstance(node, ast.Attribute):
                # 形如 os.path —— 把 os 加进去
                if isinstance(node.value, ast.Name):
                    used.add(node.value.id)
            elif isinstance(node, ast.Assign):
                # __all__ = ["X", "Y"] —— 把 X、Y 加进去（包导出算使用）
                PythonAnalyzer._collect_all_exports(node, used)
        return used

    @staticmethod
    def _collect_all_exports(node: ast.Assign, used: set[str]) -> None:
        """从 __all__ = [...] 收集导出名字"""
        if not (len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "__all__"
                and isinstance(node.value, (ast.List, ast.Tuple))):
            return
        for elt in node.value.elts:
            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                used.add(elt.value)

    def _compute_smell_score(self, report: StaticReport) -> float:
        """综合 smell 评分 0-100，越高越像 AI 生成"""
        if not report.function_profiles:
            return 0.0
        score = 0.0
        # 异常吞咽权重最高
        pass_in_except_total = sum(p.pass_in_except for p in report.function_profiles)
        score += min(pass_in_except_total * 12, 30)

        # 过度防御
        overkill_total = sum(
            max(0, p.sequential_guard_count - 3) for p in report.function_profiles
        )
        score += min(overkill_total * 5, 20)

        # unused imports
        unused_count = sum(
            1 for s in report.smells if s.category == "unused_imports"
        )
        score += min(unused_count * 5, 15)

        # 复杂度爆表
        hotspots = sum(
            1 for p in report.function_profiles if p.complexity >= 15
        )
        score += min(hotspots * 8, 20)

        # docstring 比例
        docstring_funcs = sum(1 for p in report.function_profiles if p.has_docstring)
        if report.function_profiles:
            ratio = docstring_funcs / len(report.function_profiles)
            # AI 倾向于"每个函数都写 docstring"
            if ratio > 0.8:
                score += 8
            elif ratio > 0.5:
                score += 4

        # 命名混用
        mixed_naming = sum(
            1 for s in report.smells if s.category == "naming_inconsistency"
        )
        score += min(mixed_naming * 5, 7)

        return min(score, 100.0)

    def _compute_quality_score(self, report: StaticReport) -> float:
        """
        代码质量评分：0-100，越高越好。
        考虑维度：smell 严重度、复杂度、函数长度、嵌套、异常处理、命名一致性。
        """
        if not report.function_profiles:
            return 50.0
        score = 100.0
        n_funcs = len(report.function_profiles)

        # 1. smell 按严重度扣分
        high_count = sum(1 for s in report.smells if s.severity == "high")
        medium_count = sum(1 for s in report.smells if s.severity == "medium")
        low_count = sum(1 for s in report.smells if s.severity == "low")
        score -= min(high_count * 8, 30)
        score -= min(medium_count * 2, 20)
        score -= min(low_count * 0.5, 10)

        # 2. 异常静默吞咽
        pass_total = sum(p.pass_in_except for p in report.function_profiles)
        score -= min(pass_total * 5, 15)

        # 3. 高复杂度
        hotspots = sum(1 for p in report.function_profiles if p.complexity >= 15)
        score -= min(hotspots * 5, 15)

        # 4. 过长函数
        long_funcs = sum(1 for p in report.function_profiles if p.line_count >= 80)
        score -= min(long_funcs * 4, 12)

        # 5. 深嵌套
        deep_nesting = sum(1 for p in report.function_profiles if p.max_nesting >= 5)
        score -= min(deep_nesting * 3, 9)

        # 6. unused imports
        unused_count = sum(1 for s in report.smells if s.category == "unused_imports")
        score -= min(unused_count * 2, 10)

        # 7. 过度防御
        overkill = sum(1 for p in report.function_profiles if p.sequential_guard_count >= 5)
        score -= min(overkill * 3, 9)

        # 8. 命名混用
        mixed_naming = sum(1 for s in report.smells if s.category == "naming_inconsistency")
        score -= min(mixed_naming * 3, 9)

        # 9. docstring 适中加分
        doc_ratio = sum(1 for p in report.function_profiles if p.has_docstring) / n_funcs
        if 0.3 <= doc_ratio <= 0.7:
            score += 3
        elif doc_ratio > 0.9:
            score -= 2

        # 10. 函数粒度合理加分
        avg_len = sum(p.line_count for p in report.function_profiles) / n_funcs
        if 10 <= avg_len <= 40:
            score += 2

        # 11. 平均复杂度低加分
        avg_complexity = sum(p.complexity for p in report.function_profiles) / n_funcs
        if avg_complexity <= 5:
            score += 3
        elif avg_complexity <= 10:
            score += 1

        return max(0.0, min(score, 100.0))


# ============================================================
# 对外统一入口
# ============================================================

def analyze_file(source: str, filename: str = "<code>") -> StaticReport:
    """根据文件后缀选择分析器（当前只支持 Python，其他语言走兜底）"""
    if filename.endswith(".py"):
        return PythonAnalyzer().analyze(source, filename)
    # 非 Python 文件：返回最小报告
    lines = source.splitlines()
    return StaticReport(
        file=filename, language="unknown", line_count=len(lines),
        overall_smell_score=0.0,
    )
