"""
Tree-sitter Multi-Language Analyzer
====================================

替代 v2 的 Python-only ast 模块。
统一支持 Python / JavaScript / TypeScript / Go / Rust / Java / Ruby。

核心思路：
1. 用 tree-sitter 把代码解析为统一 AST
2. 通过 query 提取跨语言一致的"函数画像"和"smell 信号"
3. 同一套 smell 检测规则适配 7 种语言

注意：tree-sitter 返回的 node 是字节偏移，需要转成行列号。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# tree-sitter-language-pack 是新的统一包
try:
    from tree_sitter_language_pack import get_parser
    _HAS_TS = True
except ImportError:
    _HAS_TS = False


SUPPORTED_LANGUAGES = {
    "python", "javascript", "typescript", "tsx",
    "go", "rust", "java", "ruby", "c", "cpp",
}

# 文件后缀 → 语言
EXT_LANG_MAP = {
    ".py": "python",
    ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "tsx",
    ".go": "go", ".rs": "rust", ".java": "java",
    ".kt": "java",  # Kotlin 用 Java 解析器近似
    ".rb": "ruby",
    ".c": "c", ".h": "c", ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
}


# ============================================================
# 数据结构（与 v2 static_analyzer 兼容）
# ============================================================

@dataclass
class TSFunctionProfile:
    """跨语言统一的函数画像"""
    name: str
    line_start: int
    line_end: int
    line_count: int
    param_count: int
    complexity: int                # 估算圈复杂度
    max_nesting: int
    try_except_count: int
    bare_except_count: int
    pass_in_except: int
    return_count: int
    has_docstring: bool
    docstring_lines: int


@dataclass
class TSSmellSignal:
    category: str
    location: str
    line_start: int
    line_end: int
    severity: str
    detail: str
    evidence: str = ""


@dataclass
class TSStaticReport:
    file: str
    language: str
    line_count: int
    function_profiles: list[TSFunctionProfile] = field(default_factory=list)
    smells: list[TSSmellSignal] = field(default_factory=list)
    overall_smell_score: float = 0.0     # AI 风格评分：0-100，越低越好（越不像 AI 写的）
    quality_score: float = 0.0           # 代码质量评分：0-100，越高越好（工程质量越好）
    parser_used: str = "tree-sitter"

    def top_smells(self, k: int = 10) -> list[TSSmellSignal]:
        order = {"high": 0, "medium": 1, "low": 2}
        return sorted(self.smells, key=lambda s: (order.get(s.severity, 3), s.line_start))[:k]

    def summary(self) -> str:
        return (
            f"  静态分析 (tree-sitter/{self.language}): "
            f"{self.line_count} 行, "
            f"{len(self.function_profiles)} 函数, "
            f"{len(self.smells)} smell 信号, "
            f"AI 风格评分 {self.overall_smell_score:.1f}/100 (越低越好), "
            f"代码质量评分 {self.quality_score:.1f}/100 (越高越好)"
        )


# ============================================================
# Tree-sitter Query Patterns（每种语言一套）
# ============================================================

# 通用：函数定义节点类型
FUNCTION_NODE_TYPES = {
    "python":     {"function_definition", "decorated_definition"},
    "javascript": {"function_declaration", "method_definition", "arrow_function"},
    "typescript": {"function_declaration", "method_definition", "arrow_function"},
    "tsx":        {"function_declaration", "method_definition", "arrow_function"},
    "go":         {"function_declaration", "method_declaration"},
    "rust":       {"function_item"},
    "java":       {"method_declaration", "constructor_declaration"},
    "ruby":       {"method", "singleton_method"},
    "c":          {"function_definition"},
    "cpp":        {"function_definition"},
}

# try / except 节点类型
TRY_NODE_TYPES = {
    "python":     {"try_statement"},
    "javascript": {"try_statement"},
    "typescript": {"try_statement"},
    "tsx":        {"try_statement"},
    "go":         set(),  # Go 没有 try/except
    "rust":       set(),  # Rust 用 Result/?
    "java":       {"try_statement"},
    "ruby":       {"begin_block", "rescue_block"},
    "c":          set(),
    "cpp":        {"try_statement"},
}

# 控制流节点（用于复杂度估算）
CONTROL_FLOW_TYPES = {
    "if_statement", "if_expression", "for_statement", "while_statement",
    "for_in_statement", "catch_clause", "except_clause",
    "binary_expression",  # && || 用于估算
}


# ============================================================
# 主分析器
# ============================================================

class TreeSitterAnalyzer:
    """跨语言 tree-sitter 分析器"""

    def __init__(self) -> None:
        self._parsers: dict[str, object] = {}

    def _get_parser(self, language: str):
        if not _HAS_TS:
            return None
        if language not in self._parsers:
            try:
                self._parsers[language] = get_parser(language)
            except Exception:
                return None
        return self._parsers[language]

    def analyze(self, source: str, filename: str = "<code>", language: str | None = None) -> TSStaticReport:
        # 推断语言
        if language is None:
            language = self._detect_language(filename, source)
        if language not in SUPPORTED_LANGUAGES:
            return TSStaticReport(
                file=filename, language=language or "unknown",
                line_count=len(source.splitlines()),
                parser_used="none",
            )

        parser = self._get_parser(language)
        if parser is None:
            return TSStaticReport(
                file=filename, language=language,
                line_count=len(source.splitlines()),
                parser_used="fallback",
            )

        # tree-sitter 解析
        tree = parser.parse(source.encode("utf-8"))
        root = tree.root_node
        lines = source.splitlines()
        report = TSStaticReport(
            file=filename, language=language,
            line_count=len(lines),
        )

        # 提取所有函数
        self._collect_function_profiles(root, lines, language, report)

        # smell 检测
        for p in report.function_profiles:
            report.smells.extend(self._detect_smells(p))

        # unused imports（简化版：所有 import 名 vs 全文出现）
        report.smells.extend(self._detect_unused_imports(root, source, language, lines))

        # 全局评分
        report.overall_smell_score = self._compute_smell_score(report)
        report.quality_score = self._compute_quality_score(report)
        return report

    def _collect_function_profiles(
        self, root, lines: list[str], language: str, report: TSStaticReport,
    ) -> None:
        """遍历 AST，收集所有函数画像"""
        func_types = FUNCTION_NODE_TYPES.get(language, set())
        for node in self._walk(root):
            if node.type not in func_types:
                continue
            if node.type == "decorated_definition":
                self._profile_decorated(node, func_types, lines, language, report)
            else:
                profile = self._profile_function(node, lines, language)
                if profile:
                    report.function_profiles.append(profile)

    def _profile_decorated(
        self, node, func_types: set, lines: list[str],
        language: str, report: TSStaticReport,
    ) -> None:
        """decorated_definition 的真实函数在内部"""
        for child in node.children:
            if child.type in func_types and child.type != "decorated_definition":
                profile = self._profile_function(child, lines, language)
                if profile:
                    report.function_profiles.append(profile)
                break

    # -------- 基础工具 --------

    @staticmethod
    def _detect_language(filename: str, source: str) -> str | None:
        for ext, lang in EXT_LANG_MAP.items():
            if filename.endswith(ext):
                return lang
        return None

    @staticmethod
    def _walk(node):
        """前序遍历 AST"""
        stack = [node]
        while stack:
            n = stack.pop()
            yield n
            # 反向 push 保持顺序
            for child in reversed(n.children):
                stack.append(child)

    @staticmethod
    def _node_text(node, source: str) -> str:
        start = node.start_byte
        end = node.end_byte
        return source.encode("utf-8")[start:end].decode("utf-8", errors="replace")

    @staticmethod
    def _find_child_by_type(node, types: set[str]):
        for child in node.children:
            if child.type in types:
                return child
        return None

    def _find_children_by_type(self, node, types: set[str]) -> list:
        return [c for c in node.children if c.type in types]

    # -------- 函数画像 --------

    def _profile_function(
        self, node, lines: list[str], language: str,
    ) -> TSFunctionProfile | None:
        """构造函数画像（指标计算拆到 _count_function_metrics）"""
        name = self._extract_function_name(node, language)
        if not name:
            return None

        line_start = node.start_point[0] + 1
        line_end = node.end_point[0] + 1
        param_count = self._count_parameters(node)
        metrics = self._count_function_metrics(node, lines, language)
        has_docstring, docstring_lines = self._detect_docstring(node, language, lines)

        return TSFunctionProfile(
            name=name, line_start=line_start, line_end=line_end,
            line_count=line_end - line_start + 1, param_count=param_count,
            complexity=metrics["complexity"], max_nesting=metrics["max_nesting"],
            try_except_count=metrics["try_except_count"],
            bare_except_count=metrics["bare_except_count"],
            pass_in_except=metrics["pass_in_except"],
            return_count=metrics["return_count"],
            has_docstring=has_docstring, docstring_lines=docstring_lines,
        )

    @staticmethod
    def _count_parameters(node) -> int:
        """统计函数参数个数"""
        params_node = TreeSitterAnalyzer._find_child_by_type(
            node,
            {"parameters", "parameter_list", "formal_parameters", "argument_list"},
        )
        if not params_node:
            return 0
        param_types = {
            "identifier", "typed_parameter", "parameter",
            "required_parameter", "optional_parameter",
            "parameter_declaration", "simple_parameter",
            "const_pattern", "name",
        }
        return sum(1 for c in params_node.children if c.type in param_types)

    def _count_function_metrics(
        self, node, lines: list[str], language: str,
    ) -> dict:
        """统计复杂度、嵌套、try/except、return 等指标"""
        complexity = 1
        max_nesting = 0
        try_except_count = 0
        bare_except_count = 0
        pass_in_except = 0
        return_count = 0

        try_types = TRY_NODE_TYPES.get(language, set())
        except_types = {"except_clause", "catch_clause", "rescue_block"}
        return_types = {"return_statement", "return_expression"}
        source_text = "\n".join(lines)

        for sub in self._walk(node):
            if sub.type in CONTROL_FLOW_TYPES:
                if sub.type == "binary_expression":
                    text = self._node_text(sub, source_text)
                    complexity += min(text.count("&&") + text.count("||"), 5)
                else:
                    complexity += 1
            elif sub.type in try_types:
                try_except_count += 1
            elif sub.type in except_types:
                handler_text = self._node_text(sub, source_text)
                if not re.search(r"(Exception|Error|Throwable|:\s*\w+)", handler_text):
                    bare_except_count += 1
                body_text = handler_text.strip()
                if re.search(r"pass\s*$", body_text) or "return None" in body_text or "return null" in body_text:
                    pass_in_except += 1
            elif sub.type in return_types:
                return_count += 1
            # 嵌套深度
            depth = self._node_depth(sub, node)
            if depth > max_nesting:
                max_nesting = depth

        return {
            "complexity": complexity,
            "max_nesting": max_nesting,
            "try_except_count": try_except_count,
            "bare_except_count": bare_except_count,
            "pass_in_except": pass_in_except,
            "return_count": return_count,
        }

    def _extract_function_name(self, node, language: str) -> str | None:
        """提取函数名：优先用 AST 字段，兜底用语言特定正则"""
        # 1. 优先用 AST 的 name / declarator 字段
        name = self._extract_name_from_ast_fields(node)
        if name:
            return name
        # 2. 兜底：从节点 text 用语言特定正则
        return self._extract_name_from_text(node, language)

    @staticmethod
    def _extract_name_from_ast_fields(node) -> str | None:
        """从 AST 的 name / declarator 字段提取标识符"""
        for field in ("name", "declarator"):
            try:
                name_node = node.child_by_field_name(field)
                if not name_node:
                    continue
                try:
                    text = name_node.text.decode("utf-8", errors="replace")
                except Exception:
                    continue
                m = re.search(r"[A-Za-z_\$][A-Za-z0-9_\$]*", text)
                if m:
                    return m.group(0)
            except Exception:
                pass
        return None

    @staticmethod
    def _extract_name_from_text(node, language: str) -> str | None:
        """从节点 text 用语言特定正则提取函数名"""
        try:
            text = node.text.decode("utf-8", errors="replace")
        except Exception:
            return None
        # 每种语言一个 pattern
        patterns: dict[str, list[str]] = {
            "go": [r"\s*func\s+(?:\([^)]*\)\s+)?([A-Za-z_]\w*)"],
            "python": [r"\s*(?:async\s+)?def\s+([A-Za-z_]\w*)"],
            "javascript": [
                r"\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)",
                r"\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=",
            ],
            "typescript": [
                r"\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)",
                r"\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=",
            ],
            "tsx": [
                r"\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)",
                r"\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=",
            ],
            "rust": [r"\s*(?:pub\s+)?fn\s+([A-Za-z_]\w*)"],
            "java": [r"\s+\w+\s+([A-Za-z_]\w*)\s*\("],
            "ruby": [r"\s*def\s+([A-Za-z_]\w*)"],
        }
        lang_patterns = patterns.get(language, [r"([A-Za-z_]\w*)\s*\("])
        for pattern in lang_patterns:
            m = re.match(pattern, text) if language != "java" else re.search(pattern, text)
            if m:
                return m.group(1)
        return None

    def _node_depth(self, node, root) -> int:
        """node 相对于 root 的真实控制流嵌套深度。
        不算 function_definition 本身（避免函数体本身就 +1），
        不算 block（block 是语法容器不是控制流）。"""
        depth = 0
        current = node.parent
        while current is not None and current != root:
            if current.type in {
                "if_statement", "for_statement", "while_statement",
                "try_statement", "with_statement",
                "except_clause", "catch_clause",
                # 函数 / 类定义本身不算嵌套深度（它内部的代码才是）
            }:
                depth += 1
            current = current.parent
        return depth

    def _detect_docstring(self, node, language: str, lines: list[str]) -> tuple[bool, int]:
        """检测函数是否有 docstring / doc comment"""
        if language == "python":
            return self._detect_python_docstring(node)
        return self._detect_other_docstring(node, lines)

    @staticmethod
    def _detect_python_docstring(node) -> tuple[bool, int]:
        """Python: 函数体第一个子语句是字符串字面量"""
        body = TreeSitterAnalyzer._find_child_by_type(node, {"block", "suite"})
        if not body or not body.children:
            return False, 0
        first = body.children[0]
        # 跳过注释
        while first and first.type == "comment":
            first = first.next_sibling
        if first and first.type == "expression_statement":
            inner = first.children[0] if first.children else None
            if inner and inner.type == "string":
                return True, 1
        return False, 0

    @staticmethod
    def _detect_other_docstring(node, lines: list[str]) -> tuple[bool, int]:
        """JS/Go/Java: 用 /** ... */ 或 // 注释"""
        line_start = node.start_point[0]
        if line_start <= 0:
            return False, 0
        prev_line = lines[line_start - 1].strip() if line_start - 1 < len(lines) else ""
        if prev_line.endswith("*/") or prev_line.startswith("//"):
            return True, 1
        return False, 0

    # -------- smell 检测 --------

    def _detect_smells(self, p: TSFunctionProfile) -> list[TSSmellSignal]:
        smells: list[TSSmellSignal] = []

        if p.pass_in_except >= 2:
            smells.append(TSSmellSignal(
                category="try_except_density",
                location=f"{p.name}() L{p.line_start}-{p.line_end}",
                line_start=p.line_start, line_end=p.line_end,
                severity="high" if p.pass_in_except >= 3 else "medium",
                detail=f"函数内 {p.pass_in_except} 处 except 直接 pass/return None，异常被静默吞掉",
            ))

        if p.complexity >= 15:
            smells.append(TSSmellSignal(
                category="complexity_hotspots",
                location=f"{p.name}() L{p.line_start}",
                line_start=p.line_start, line_end=p.line_end,
                severity="high" if p.complexity >= 20 else "medium",
                detail=f"圈复杂度 {p.complexity}，建议拆分",
            ))

        if p.max_nesting >= 4:
            smells.append(TSSmellSignal(
                category="nesting_depth",
                location=f"{p.name}() L{p.line_start}",
                line_start=p.line_start, line_end=p.line_end,
                severity="medium" if p.max_nesting < 6 else "high",
                detail=f"最大嵌套深度 {p.max_nesting}",
            ))

        if p.param_count >= 6:
            smells.append(TSSmellSignal(
                category="param_count",
                location=f"{p.name}() L{p.line_start}",
                line_start=p.line_start, line_end=p.line_end,
                severity="low",
                detail=f"参数数 {p.param_count}，建议用对象封装",
            ))

        if p.line_count >= 80:
            smells.append(TSSmellSignal(
                category="long_function",
                location=f"{p.name}() L{p.line_start}-{p.line_end}",
                line_start=p.line_start, line_end=p.line_end,
                severity="medium" if p.line_count < 150 else "high",
                detail=f"函数 {p.line_count} 行，建议拆分",
            ))

        return smells

    def _detect_unused_imports(self, root, source: str, language: str, lines: list[str]) -> list[TSSmellSignal]:
        """简化版 unused import 检测：找 import 节点 + 全文匹配"""
        smells: list[TSSmellSignal] = []
        import_node_types = {
            "python":     {"import_statement", "import_from_statement"},
            "javascript": {"import_statement"},
            "typescript": {"import_statement"},
            "tsx":        {"import_statement"},
            "go":         {"import_declaration"},
            "rust":       {"use_declaration"},
            "java":       {"import_declaration"},
            "ruby":       set(),
            "c":          {"preproc_include"},
            "cpp":        {"preproc_include"},
        }.get(language, set())

        if not import_node_types:
            return smells

        # 收集 __all__ 里列出的名字（这些是包导出，算"使用"）
        all_exported_names: set[str] = set()
        if language == "python":
            all_pattern = re.compile(r'^__all__\s*=\s*[\[(]', re.MULTILINE)
            if all_pattern.search(source):
                # 提取 __all__ 里的字符串字面量
                for m in re.finditer(r'__all__\s*=\s*[\[(][^\])]*[\])]', source, re.DOTALL):
                    for s in re.finditer(r'"([^"]+)"|\'([^\']+)\'', m.group(0)):
                        all_exported_names.add(s.group(1) or s.group(2))

        for node in self._walk(root):
            if node.type not in import_node_types:
                continue
            text = self._node_text(node, source)
            line = node.start_point[0] + 1
            # 跳过 __future__ import（如 from __future__ import annotations）
            if language == "python" and "__future__" in text:
                continue
            # 提取 import 的标识符
            identifiers = self._extract_imported_names(text, language)
            for name in identifiers:
                if name in ("*", "_", "self"):
                    continue
                # 过滤掉非标识符（如括号、运算符等被误识别的）
                if not re.fullmatch(r"[A-Za-z_$][\w$]*", name):
                    continue
                # __all__ 里的名字算使用
                if name in all_exported_names:
                    continue
                # 全文搜索（排除 import 行本身）
                other_lines = lines[:line-1] + lines[line:]
                other_text = "\n".join(other_lines)
                # 简化：标识符必须在其他地方出现
                if not re.search(rf"\b{re.escape(name)}\b", other_text):
                    smells.append(TSSmellSignal(
                        category="unused_imports",
                        location=f"L{line}",
                        line_start=line, line_end=line,
                        severity="low",
                        detail=f"import 了 `{name}` 但全文未使用",
                    ))
                    break  # 同一 import 节点只报一次
        return smells

    @staticmethod
    def _extract_imported_names(text: str, language: str) -> list[str]:
        """根据语言提取 import 的标识符列表"""
        extractors = {
            "python":     TreeSitterAnalyzer._extract_python_imports,
            "javascript": TreeSitterAnalyzer._extract_js_imports,
            "typescript": TreeSitterAnalyzer._extract_js_imports,
            "tsx":        TreeSitterAnalyzer._extract_js_imports,
            "go":         TreeSitterAnalyzer._extract_go_imports,
            "rust":       TreeSitterAnalyzer._extract_rust_imports,
            "java":       TreeSitterAnalyzer._extract_java_imports,
        }
        extractor = extractors.get(language)
        return extractor(text) if extractor else []

    @staticmethod
    def _extract_python_imports(text: str) -> list[str]:
        """Python: from X import a, b as c / import X.Y"""
        # from X import a, b, c as d
        m = re.search(r"import\s+(.+)$", text, re.MULTILINE)
        if m:
            names = []
            for part in m.group(1).split(","):
                part = part.strip()
                if " as " in part:
                    part = part.split(" as ")[-1]
                names.append(part.split(".")[0])
            return names
        # import X.Y
        m = re.match(r"import\s+([\w.]+)", text)
        if m:
            return [m.group(1).split(".")[0]]
        return []

    @staticmethod
    def _extract_js_imports(text: str) -> list[str]:
        """JS/TS: import { a, b as c } from 'x' / import X from 'y'"""
        m = re.search(r"\{([^}]+)\}", text)
        if m:
            names = []
            for part in m.group(1).split(","):
                part = part.strip()
                if " as " in part:
                    part = part.split(" as ")[-1]
                names.append(part)
            return names
        m = re.match(r"import\s+(\w+)\s+from", text)
        if m:
            return [m.group(1)]
        return []

    @staticmethod
    def _extract_go_imports(text: str) -> list[str]:
        """Go: import "x" or import ( "a"; "b" )"""
        matches = re.findall(r'"([^"]+)"', text)
        return [m.split("/")[-1] for m in matches if m]

    @staticmethod
    def _extract_rust_imports(text: str) -> list[str]:
        """Rust: use X::Y::Z"""
        m = re.search(r"use\s+([\w:]+)", text)
        if m:
            return [m.group(1).split("::")[-1].split("{")[0]]
        return []

    @staticmethod
    def _extract_java_imports(text: str) -> list[str]:
        """Java: import x.y.Z;"""
        m = re.search(r"import\s+[\w.]+\.(\w+);", text)
        if m:
            return [m.group(1)]
        return []

    def _compute_smell_score(self, report: TSStaticReport) -> float:
        """AI 风格评分：0-100，越低越好（越不像 AI 写的）"""
        if not report.function_profiles:
            return 0.0
        score = 0.0
        pass_total = sum(p.pass_in_except for p in report.function_profiles)
        score += min(pass_total * 12, 30)

        unused_count = sum(1 for s in report.smells if s.category == "unused_imports")
        score += min(unused_count * 5, 15)

        hotspots = sum(1 for p in report.function_profiles if p.complexity >= 15)
        score += min(hotspots * 8, 20)

        long_funcs = sum(1 for p in report.function_profiles if p.line_count >= 80)
        score += min(long_funcs * 6, 15)

        doc_ratio = sum(1 for p in report.function_profiles if p.has_docstring) / max(len(report.function_profiles), 1)
        if doc_ratio > 0.8:
            score += 8
        elif doc_ratio > 0.5:
            score += 4

        deep_nesting = sum(1 for p in report.function_profiles if p.max_nesting >= 4)
        score += min(deep_nesting * 5, 12)

        return min(score, 100.0)

    def _compute_quality_score(self, report: TSStaticReport) -> float:
        """
        代码质量评分：0-100，越高越好（工程质量越好）。
        与 AI smell 评分方向相反，但考虑维度更全面：
          - 无 HIGH 级 smell 加分
          - 函数复杂度低加分
          - 函数长度合理加分
          - 嵌套浅加分
          - 无异常静默吞咽加分
          - 无 unused imports 加分
          - 有 docstring 加分（适中有度）
        """
        if not report.function_profiles:
            return 50.0  # 无函数的文件给中等分
        score = 100.0
        n_funcs = len(report.function_profiles)

        # 1. HIGH 级 smell 严重扣分（每个 -8）
        high_count = sum(1 for s in report.smells if s.severity == "high")
        score -= min(high_count * 8, 30)

        # 2. MEDIUM 级 smell 扣分（每个 -2）
        medium_count = sum(1 for s in report.smells if s.severity == "medium")
        score -= min(medium_count * 2, 20)

        # 3. LOW 级 smell 轻微扣分（每个 -0.5）
        low_count = sum(1 for s in report.smells if s.severity == "low")
        score -= min(low_count * 0.5, 10)

        # 4. 异常静默吞咽严重扣分
        pass_total = sum(p.pass_in_except for p in report.function_profiles)
        score -= min(pass_total * 5, 15)

        # 5. 高复杂度函数扣分
        hotspots = sum(1 for p in report.function_profiles if p.complexity >= 15)
        score -= min(hotspots * 5, 15)

        # 6. 过长函数扣分
        long_funcs = sum(1 for p in report.function_profiles if p.line_count >= 80)
        score -= min(long_funcs * 4, 12)

        # 7. 深嵌套扣分
        deep_nesting = sum(1 for p in report.function_profiles if p.max_nesting >= 5)
        score -= min(deep_nesting * 3, 9)

        # 8. unused imports 扣分
        unused_count = sum(1 for s in report.smells if s.category == "unused_imports")
        score -= min(unused_count * 2, 10)

        # 9. docstring 覆盖率适中加分（30%-70% 最佳）
        doc_ratio = sum(1 for p in report.function_profiles if p.has_docstring) / n_funcs
        if 0.3 <= doc_ratio <= 0.7:
            score += 3  # 适中有度，加分
        elif doc_ratio > 0.9:
            score -= 2  # 过度注释反而是 AI 味

        # 10. 函数平均长度合理加分（10-40 行最佳）
        avg_len = sum(p.line_count for p in report.function_profiles) / n_funcs
        if 10 <= avg_len <= 40:
            score += 2  # 函数粒度合理

        # 11. 平均复杂度低加分
        avg_complexity = sum(p.complexity for p in report.function_profiles) / n_funcs
        if avg_complexity <= 5:
            score += 3
        elif avg_complexity <= 10:
            score += 1

        return max(0.0, min(score, 100.0))


# ============================================================
# 对外统一入口
# ============================================================

# 用 thread-local 缓存 parser（避免每次新建 parser 的开销，但避免全局单例的并发问题）
import threading
_analyzer_tls = threading.local()


def analyze_with_tree_sitter(
    source: str, filename: str = "<code>", language: str | None = None,
) -> TSStaticReport:
    """对外入口：tree-sitter 多语言分析"""
    if not hasattr(_analyzer_tls, 'analyzer'):
        _analyzer_tls.analyzer = TreeSitterAnalyzer()
    return _analyzer_tls.analyzer.analyze(source, filename, language)
