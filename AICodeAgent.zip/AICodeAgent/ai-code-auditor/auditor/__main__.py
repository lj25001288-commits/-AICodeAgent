"""
AI Code Auditor v3 — CLI 入口
=============================

三种审计模式：
    python -m auditor <file>                       # 默认 standard 模式
    python -m auditor <file> --mode simple         # 快速模式（单模型）
    python -m auditor <file> --mode full           # 完整模式（Agent + 红蓝 + 沙箱）

三种使用场景：
    python -m auditor <file>                       # 审单文件
    python -m auditor --diff HEAD~1                # 审 git diff 改动
    python -m auditor evaluate                     # 跑评估集（benchmark）

Patch 操作：
    python -m auditor <file> --apply-patch         # 应用 patch 到工作区
    python -m auditor <file> --save-patches ./p/   # 保存 patch 到目录
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

import yaml

from .cache import AuditCache
from .client import MultiModelClient
from .evaluation import Evaluator, GOLD_SAMPLES, summary_to_markdown
from .patcher import PatchApplier, PatchExtractor
from .pipeline import AuditPipeline, DiffPipeline
from .tools import ToolRegistry


DEFAULT_CONFIG_PATHS = [
    "./config.yaml",
    "./config.yml",
    "~/.ai-code-auditor.yaml",
]


def _load_config(explicit: str | None) -> dict:
    if explicit:
        with open(explicit, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    for p in DEFAULT_CONFIG_PATHS:
        path = Path(p).expanduser()
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
    base_url = os.environ.get("RELAY_BASE_URL") or os.environ.get("OPENAI_BASE_URL", "")
    api_key = os.environ.get("RELAY_API_KEY") or os.environ.get("OPENAI_API_KEY", "")
    if not base_url or not api_key:
        print(
            "[ERROR] 找不到配置。\n"
            "  方案1：创建 config.yaml（参考 config.example.yaml）\n"
            "  方案2：设置环境变量 RELAY_BASE_URL / RELAY_API_KEY",
            file=sys.stderr,
        )
        sys.exit(2)
    return {"base_url": base_url, "api_key": api_key}


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ai-code-auditor",
        description=(
            "AI Code Auditor v3 — 商业级多模型 Agent 审计工具\n"
            "Models: GPT-4o + Claude + DeepSeek-Coder + Qwen-Max\n"
            "Modules: tree-sitter / Agent Loop / 红蓝对抗 / Sandbox 验证 / 评估集"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例：\n"
            "  python -m auditor examples/bad_code.py\n"
            "  python -m auditor app/api.py --mode full --verbose\n"
            "  python -m auditor --diff HEAD~1\n"
            "  python -m auditor main.py --apply-patch --save-patches ./patches/\n"
            "  python -m auditor --evaluate --samples 5    # 跑评估集\n"
        ),
    )
    p.add_argument("file", nargs="?", help="待审计的代码文件路径")
    p.add_argument("--config", "-c", help="配置文件路径（默认 ./config.yaml）")
    p.add_argument("--out", "-o", help="报告输出路径（默认只打印到 stdout）")
    p.add_argument("--verbose", "-v", action="store_true", help="打印详细明细")
    p.add_argument("--no-banner", action="store_true", help="不打印执行摘要")
    p.add_argument(
        "--mode", "-m", choices=["simple", "standard", "full"], default="standard",
        help="审计模式：simple(单模型)/standard(多模型+辩论)/full(Agent+红蓝+沙箱)",
    )
    p.add_argument(
        "--diff", "-d", nargs="?", const="HEAD~1",
        help="审 git diff 改动，参数为 base ref（默认 HEAD~1）",
    )
    p.add_argument("--cached", action="store_true", help="审已 stage 的改动")
    p.add_argument("--apply-patch", action="store_true", help="审完直接把 patch 应用到工作区")
    p.add_argument("--save-patches", metavar="DIR", help="把 patch 写到指定目录")
    p.add_argument("--no-debate", action="store_true", help="跳过红蓝对抗（仅 full 模式）")
    p.add_argument("--no-agent", action="store_true", help="跳过 Agent Loop（仅 full 模式）")
    p.add_argument("--no-sandbox", action="store_true", help="跳过 Sandbox 验证（仅 full 模式）")
    p.add_argument("--no-fingerprint", action="store_true", help="跳过 AI 指纹识别")
    p.add_argument("--cache", metavar="PATH", help="启用缓存，缓存文件路径")
    p.add_argument("--no-cache", action="store_true", help="禁用缓存")
    # evaluate 用 --evaluate 标志而非子命令，避免和 positional file 冲突
    p.add_argument("--evaluate", action="store_true", help="跑评估集（benchmark）")
    p.add_argument("--samples", type=int, default=0, help="评估样本数（0=全部）")
    p.add_argument("--concurrency", type=int, default=2, help="评估并发数")
    # 一键配置
    p.add_argument(
        "--register", action="store_true",
        help="打开浏览器注册中转站 API key（推荐首次使用）",
    )
    p.add_argument(
        "--setup-key", metavar="KEY",
        help="用 API key 一键生成 config.yaml（如 --setup-key sk-xxx）",
    )
    return p


# 默认中转站地址（用户可改）
DEFAULT_RELAY_URL = "https://aitokenlink.cn/"
DEFAULT_RELAY_API_BASE = "https://aitokenlink.cn/v1"


def _run_register() -> int:
    """打开浏览器注册中转站 API key"""
    import webbrowser
    url = os.environ.get("AUDITOR_RELAY_URL", DEFAULT_RELAY_URL)
    print("=" * 60)
    print("  AI Code Auditor — 一键注册 API key")
    print("=" * 60)
    print()
    print(f"  正在打开浏览器: {url}")
    print()
    print("  注册步骤:")
    print("  1. 在打开的页面注册账号")
    print("  2. 在控制台获取 API key（以 sk- 开头）")
    print("  3. 回到终端运行:")
    print()
    print(f"     python -m auditor --setup-key sk-你的key")
    print()
    print("  配置完成后即可运行审计:")
    print()
    print("     python -m auditor examples/bad_code.py")
    print()
    print("=" * 60)
    try:
        webbrowser.open(url)
        print(f"✅ 浏览器已打开: {url}")
    except Exception:
        print(f"⚠️  无法自动打开浏览器，请手动访问: {url}")
    return 0


def _run_setup_key(api_key: str) -> int:
    """用 API key 一键生成 config.yaml"""
    config_path = Path("config.yaml")
    relay_base = os.environ.get("AUDITOR_RELAY_API_BASE", DEFAULT_RELAY_API_BASE)

    config_content = f"""# AI Code Auditor 配置文件（由 --setup-key 自动生成）
# 中转站: {relay_base}

base_url: "{relay_base}"
api_key: "{api_key}"

timeout: 180.0
max_concurrency: 4

# 模型角色分配：每个角色可配多候选，主模型挂了自动 fallback
# 如需多模型协作，把不同角色配不同模型（如 GPT-4o + Claude + DeepSeek）
models:
  decomposer:      ["gpt-4o", "glm-4-plus"]
  logic_auditor:   ["claude-3-5-sonnet-20241022", "gpt-4o"]
  code_specialist: ["deepseek-coder", "gpt-4o-mini"]
  agent:           ["gpt-4o"]
  red_security:      ["gpt-4o"]
  red_performance:   ["claude-3-5-sonnet-20241022"]
  red_archaeologist: ["deepseek-coder"]
  blue_devils:       ["claude-3-5-sonnet-20241022"]
  blue_test:         ["deepseek-coder"]
  blue_doc:          ["gpt-4o"]
  judge:             ["qwen-max", "gpt-4o"]
  arbiter:           ["qwen-max", "gpt-4o"]
  sandbox:           ["gpt-4o"]
  simple:            ["gpt-4o-mini", "glm-4-plus"]

enable_debate: true
enable_agent: true
enable_sandbox: true
enable_fingerprint: true

# 缓存（可选）
# cache_path: "./.auditor-cache.json"
"""

    config_path.write_text(config_content, encoding="utf-8")
    print("=" * 60)
    print("  AI Code Auditor — 配置完成！")
    print("=" * 60)
    print()
    print(f"  ✅ 配置文件已生成: {config_path.resolve()}")
    print(f"  ✅ 中转站: {relay_base}")
    print(f"  ✅ API Key: {api_key[:8]}...{api_key[-4:]}")
    print()
    print("  现在可以运行审计了:")
    print()
    print("     python -m auditor examples/bad_code.py              # 标准模式")
    print("     python -m auditor examples/bad_code.py --mode full  # 完整模式")
    print()
    print("  想改用其他模型？编辑 config.yaml 的 models 部分。")
    print("=" * 60)
    return 0


async def _audit_file(args, cfg, pipeline: AuditPipeline) -> int:
    if not args.file:
        print("[ERROR] 必须指定文件路径或使用 --diff 模式", file=sys.stderr)
        return 1
    if not Path(args.file).exists():
        print(f"[ERROR] 文件不存在: {args.file}", file=sys.stderr)
        return 1
    result = await pipeline.run(args.file)
    return await _output_result(args, result)


async def _audit_diff(args, cfg, pipeline: AuditPipeline) -> int:
    diff_pipeline = DiffPipeline(pipeline.cli, cfg, git_cwd=".")
    results = await diff_pipeline.run(base=args.diff, cached=args.cached)
    if not results:
        print("[INFO] 没有可审计的文件改动", file=sys.stderr)
        return 0
    for r in results:
        await _output_result(args, r)
    return 0


async def _output_result(args, result) -> int:
    _print_report(args, result)
    if not args.no_banner or args.verbose:
        print(result.banner(), file=sys.stderr)
    if result.patches:
        _handle_patches(args, result)
    return 0


def _print_report(args, result) -> None:
    """输出审计报告到文件或 stdout"""
    if args.out:
        Path(args.out).write_text(result.report, encoding="utf-8")
        print(f"[OK] 报告已写入: {args.out}", file=sys.stderr)
    else:
        print("\n" + result.report)


def _handle_patches(args, result) -> None:
    """处理提取出的 patch（保存 / 应用）"""
    if args.save_patches:
        written = PatchExtractor.extract_to_files(result.report, args.save_patches)
        print(f"[OK] 提取 {len(written)} 个 patch 到 {args.save_patches}/", file=sys.stderr)
    if args.apply_patch:
        _apply_patches(result.patches)


def _apply_patches(patches: list[str]) -> None:
    """逐个应用 patch 到工作区"""
    applier = PatchApplier(cwd=".")
    for p in patches:
        r = applier.apply(p, check=True)
        if r.success:
            print(f"[OK] patch 已应用: {', '.join(r.applied_files)}", file=sys.stderr)
        else:
            print(f"[WARN] patch 应用失败: {r.output}", file=sys.stderr)


async def _run_evaluate(args, cfg) -> int:
    """跑评估集"""
    async with MultiModelClient(
        base_url=cfg["base_url"], api_key=cfg["api_key"],
        timeout=cfg.get("timeout", 180.0),
        max_concurrency=cfg.get("max_concurrency", 4),
    ) as cli:
        # 构造 audit_fn：simple 模式跑评估，省 token
        cfg_eval = dict(cfg)
        cfg_eval["mode"] = "simple"
        pipeline = AuditPipeline(cli, cfg_eval)

        async def audit_fn(code: str, filename: str) -> list[dict]:
            result = await pipeline.run_source(code, filename)
            # 从报告中提取 findings（简化：解析 markdown 列表）
            findings: list[dict] = []
            # 从静态分析 + 报告中提取
            if result.static_report:
                for s in result.static_report.smells:
                    findings.append({
                        "location": s.location,
                        "severity": s.severity,
                        "description": s.detail,
                        "suggestion": "",
                    })
            # 从报告文本中粗略提取
            import re
            for m in re.finditer(
                r"^(?:#+\s*)?\*?\*?\[?(\w+)\]?\*?\*?\s*(.+?)(?:$|\n)",
                result.report, re.MULTILINE,
            ):
                sev = m.group(1).lower()
                if sev in {"critical", "high", "medium", "low", "info"}:
                    findings.append({
                        "location": "",
                        "severity": sev,
                        "description": m.group(2),
                        "suggestion": "",
                    })
            return findings

        samples = GOLD_SAMPLES
        if args.samples > 0:
            samples = samples[:args.samples]

        evaluator = Evaluator(audit_fn, verbose=args.verbose)
        print(f"开始评估 {len(samples)} 个样本...", file=sys.stderr)
        summary = await evaluator.evaluate_all(
            samples=samples, max_concurrency=args.concurrency,
        )

        md = summary_to_markdown(summary)
        if args.out:
            Path(args.out).write_text(md, encoding="utf-8")
            print(f"[OK] 评估报告已写入: {args.out}", file=sys.stderr)
        else:
            print(md)
    return 0


def main() -> None:
    args = _build_parser().parse_args()

    # --register: 打开浏览器注册
    if args.register:
        sys.exit(_run_register())

    # --setup-key: 一键生成 config.yaml
    if args.setup_key:
        sys.exit(_run_setup_key(args.setup_key))

    cfg = _load_config(args.config)

    # --evaluate 标志：跑评估集
    if args.evaluate:
        try:
            code = asyncio.run(_run_evaluate(args, cfg))
        except KeyboardInterrupt:
            code = 130
        sys.exit(code)

    # 主命令：audit
    _apply_args_to_config(args, cfg)
    cache = _build_cache(args, cfg)
    code = _run_audit(args, cfg, cache)
    sys.exit(code)


def _apply_args_to_config(args, cfg: dict) -> None:
    """把 CLI 参数应用到 config"""
    cfg["mode"] = args.mode
    flag_to_cfg = {
        "no_debate": "enable_debate",
        "no_agent": "enable_agent",
        "no_sandbox": "enable_sandbox",
        "no_fingerprint": "enable_fingerprint",
    }
    for arg_name, cfg_key in flag_to_cfg.items():
        if getattr(args, arg_name, False):
            cfg[cfg_key] = False


def _build_cache(args, cfg: dict):
    """根据 args 和 cfg 构建缓存（或返回 None）"""
    if args.cache and not args.no_cache:
        return AuditCache(args.cache)
    if not args.no_cache and cfg.get("cache_path"):
        return AuditCache(cfg["cache_path"])
    return None


def _run_audit(args, cfg: dict, cache) -> int:
    """运行主审计流程"""
    async def _run() -> int:
        async with MultiModelClient(
            base_url=cfg["base_url"], api_key=cfg["api_key"],
            timeout=cfg.get("timeout", 180.0),
            max_concurrency=cfg.get("max_concurrency", 4),
        ) as cli:
            tools = ToolRegistry(cwd=".")
            pipeline = AuditPipeline(cli, cfg, cache=cache, tool_registry=tools)
            if args.diff is not None:
                return await _audit_diff(args, cfg, pipeline)
            return await _audit_file(args, cfg, pipeline)

    try:
        return asyncio.run(_run())
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        import traceback
        print(f"[FATAL] {type(e).__name__}: {e}", file=sys.stderr)
        if args.verbose:
            traceback.print_exc(file=sys.stderr)
        return 1


if __name__ == "__main__":
    main()
