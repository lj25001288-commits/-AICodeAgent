"""
Adversarial Red-Blue Team Debate Engine
=======================================

替代 v2 的"两模型互看 findings"，做真正的红蓝对抗：

Round 1 - 红队攻击（3 个模型轮流找 bug，必须找对方漏的）
Round 2 - 蓝队反驳（3 个模型轮流反驳，必须证明"这不是 bug"）
Round 3 - 法官判定（综合所有证据，逐条 ruling）

收敛条件：
  - 红队连续 1 轮无新发现
  - 或达到 max_rounds（默认 3）

每个模型带"角色 persona"，强制不同视角：
  - 红队 1: 安全研究员视角（找漏洞）
  - 红队 2: 性能工程师视角（找性能问题）
  - 红队 3: 代码考古学家视角（找历史/兼容问题）
  - 蓝队 1: 原作者辩护律师视角（最大化合理怀疑）
  - 蓝队 2: 测试工程师视角（"在 X 场景下这不是 bug"）
  - 蓝队 3: 文档撰写者视角（"代码确实和文档一致"）
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from .client import MultiModelClient
from .schemas import (
    BlueTeamOutput,
    BlueTeamRebuttal,
    JudgeOutput,
    JudgeRuling,
    RedTeamFinding,
    RedTeamOutput,
    Severity,
)


# ============================================================
# Persona Prompts（让每个模型带不同视角）
# ============================================================

RED_PERSONAS = {
    "security": {
        "name": "红队-安全研究员",
        "system": """你是红队攻击方的【安全研究员】。
你的唯一目标是找出代码中的安全漏洞：
- SQL 注入 / 命令注入 / 路径穿越
- 硬编码密钥 / 凭证泄露
- 反序列化漏洞 / SSRF / XXE
- 权限提升 / 越权访问
- 敏感信息日志泄露

要求：
1. 每条发现必须有具体代码证据（行号 + 代码片段）
2. 给出严重度评级（critical/high/medium/low）
3. 不要报告"风格问题"或"性能问题"——那是其他红队成员的活
4. 必须找出【其他红队成员可能漏掉】的安全问题
""",
    },
    "performance": {
        "name": "红队-性能工程师",
        "system": """你是红队攻击方的【性能工程师】。
你的唯一目标是找出性能反模式：
- N+1 查询 / 循环里建连接 / 循环里调 IO
- O(n²) / O(2^n) 算法在热路径
- 同步阻塞调用应该改异步
- 重复计算 / 缓存未命中 / 内存泄漏
- 锁粒度过粗 / 死锁风险

要求：
1. 每条发现必须有具体代码证据
2. 估算性能影响（"在 1k QPS 下会让 p99 涨 200ms"）
3. 必须找出【其他红队成员可能漏掉】的性能问题
""",
    },
    "archaeologist": {
        "name": "红队-代码考古学家",
        "system": """你是红队攻击方的【代码考古学家】。
你的视角是"这段代码在历史演化中埋了什么雷"：
- API 已废弃但还在用（os.system / requests.get 同步）
- 库版本升级后的 breaking change
- 兼容性 bug（Python 3.12 vs 3.9 行为不同）
- 错误的抽象（5 层工厂包一个 if）
- docstring 撒谎（实现和文档不符）

要求：
1. 每条发现引用具体代码
2. 给出"如果改了 X 会破坏什么"的预测
3. 必须找出【其他红队成员可能漏掉】的历史/兼容问题
""",
    },
}

BLUE_PERSONAS = {
    "devils_advocate": {
        "name": "蓝队-原作者辩护律师",
        "system": """你是蓝队防御方的【原作者辩护律师】。
你的目标是最大化合理怀疑——证明红队的发现"不一定是 bug"：
- "在 X 场景下这段代码是合理的"
- "红队忽略了上下文：这个函数只在内部调用"
- "严重度被夸大了：实际不会触发"
- "这是已知 trade-off，不是 bug"

要求：
1. 必须针对每条红队发现给出反驳
2. 反驳必须有具体证据，不能空喊"这不是 bug"
3. 如果确实是 bug，必须诚实承认（VALID_CONCEDE）——不要为了赢而硬辩
4. 标记反驳结论：INVALID / EXAGGERATED / DUPLICATE / VALID_CONCEDE
""",
    },
    "test_engineer": {
        "name": "蓝队-测试工程师",
        "system": """你是蓝队防御方的【测试工程师】。
你的视角是"这段代码有没有测试覆盖？测试是否证明它是对的？"：
- "这个函数有 95% 测试覆盖率，红队的发现不会触发"
- "红队假设的输入场景实际不会发生（被上游校验拦截）"
- "这是 defensive code，红队说的边界不会触发"

要求：
1. 优先引用测试代码反驳
2. 给出"在什么测试场景下能复现红队说的问题"
3. 如果测试覆盖不足，承认 VALID_CONCEDE
""",
    },
    "doc_writer": {
        "name": "蓝队-文档撰写者",
        "system": """你是蓝队防御方的【文档撰写者】。
你的视角是"代码是否和文档/注释一致？"：
- "红队说 docstring 撒谎，但实际第 5 行注释已经说明了"
- "红队说命名混乱，但实际项目命名约定就是这样"
- "代码确实违反了 docstring 承诺 → VALID_CONCEDE"

要求：
1. 引用具体文档/注释反驳
2. 如代码确实和文档不符，承认 VALID_CONCEDE
3. 标记反驳结论
""",
    },
}

JUDGE_SYSTEM = """你是【法官】。给你红队的所有 finding + 蓝队的所有反驳，你要逐条做出最终判定。

判定规则：
- confirmed: 红队证据充分，蓝队反驳无效或承认
- rejected: 蓝队反驳有理，红队 finding 不成立
- needs_review: 双方都有道理，需要人工审

对每条 finding 输出：
- final_verdict: confirmed / rejected / needs_review
- final_severity: 综合 red 和 blue 的意见给出最终严重度
- final_confidence: 0-1，反映你对此判定的信心
- reasoning: 50-200 字的判定理由

要求：
1. 不能为了"达成共识"而强行 confirmed——红队确实可能误报
2. 不能为了"保护作者"而 rejected——bug 就是 bug
3. VALID_CONCEDE 的反驳应该让你倾向 confirmed
4. INVALID 且证据充分的反驳应该让你倾向 rejected
"""


# ============================================================
# 数据结构
# ============================================================

@dataclass
class DebateRoundResult:
    """单轮辩论结果"""
    round_num: int
    red_team_findings: list[RedTeamFinding] = field(default_factory=list)
    blue_team_rebuttals: list[BlueTeamRebuttal] = field(default_factory=list)
    new_findings_count: int = 0           # 本轮新增的 finding 数
    confirmed_count: int = 0
    rejected_count: int = 0


@dataclass
class DebateResult:
    """完整对抗辩论结果"""
    rounds: list[DebateRoundResult] = field(default_factory=list)
    judge: JudgeOutput | None = None
    total_findings_raised: int = 0
    final_confirmed: list[JudgeRuling] = field(default_factory=list)
    final_rejected: list[JudgeRuling] = field(default_factory=list)
    final_needs_review: list[JudgeRuling] = field(default_factory=list)
    total_ms: int = 0

    def banner(self) -> str:
        lines = ["", "=" * 60, "  红蓝对抗辩论结果:"]
        lines.append(f"    总轮次: {len(self.rounds)}")
        lines.append(f"    总红队 findings: {self.total_findings_raised}")
        lines.append(f"    法官 confirmed: {len(self.final_confirmed)}")
        lines.append(f"    法官 rejected:  {len(self.final_rejected)}")
        lines.append(f"    法官 needs_review: {len(self.final_needs_review)}")
        if self.final_confirmed:
            lines.append("    已确认问题:")
            for r in self.final_confirmed:
                lines.append(
                    f"      [{r.final_severity.value:<8}] {r.red_finding_location}: {r.reasoning[:60]}"
                )
        lines.append("=" * 60)
        return "\n".join(lines)


# ============================================================
# 红蓝对抗引擎
# ============================================================

class AdversarialDebateEngine:
    """主引擎"""

    def __init__(
        self,
        client: MultiModelClient,
        config: dict,
        max_rounds: int = 2,
        verbose: bool = False,
    ) -> None:
        self.cli = client
        self.cfg = config
        self.max_rounds = max_rounds
        self.verbose = verbose

        models = config.get("models", {})
        # 红队 3 个模型（默认同模型不同 persona）
        self.red_models = {
            "security":      models.get("red_security",      ["gpt-4o"])[0],
            "performance":   models.get("red_performance",   ["claude-3-5-sonnet-20241022"])[0],
            "archaeologist": models.get("red_archaeologist", ["deepseek-coder"])[0],
        }
        # 蓝队 3 个模型
        self.blue_models = {
            "devils_advocate": models.get("blue_devils",     ["claude-3-5-sonnet-20241022"])[0],
            "test_engineer":   models.get("blue_test",       ["deepseek-coder"])[0],
            "doc_writer":      models.get("blue_doc",        ["gpt-4o"])[0],
        }
        # 法官
        self.judge_model = models.get("judge", ["qwen-max", "gpt-4o"])[0]

    async def run(
        self,
        code: str,
        filename: str,
        language: str,
        initial_findings: list[dict] | None = None,
    ) -> DebateResult:
        """
        跑完整对抗辩论。
        initial_findings: v2 流水线产出的 findings，作为红队 Round 1 的种子
        """
        t0 = time.perf_counter()
        result = DebateResult()

        # 阶段 1: 初始化红队种子 findings
        all_red_findings = self._init_red_findings(initial_findings)

        # 阶段 2: 多轮对抗
        all_red_findings = await self._run_debate_rounds(
            code, filename, language, all_red_findings, result,
        )

        # 阶段 3: 法官判定
        await self._run_judge_phase(
            code, filename, language, all_red_findings, result,
        )

        result.total_findings_raised = len(all_red_findings)
        result.total_ms = int((time.perf_counter() - t0) * 1000)
        return result

    @staticmethod
    def _init_red_findings(
        initial_findings: list[dict] | None,
    ) -> list[RedTeamFinding]:
        """把 initial_findings 转成 RedTeamFinding 格式"""
        if not initial_findings:
            return []
        findings: list[RedTeamFinding] = []
        for f in initial_findings:
            try:
                findings.append(RedTeamFinding(
                    severity=Severity(f.get("severity", "medium")),
                    location=f.get("location", "unknown"),
                    description=f.get("description", ""),
                    evidence=f.get("suggestion", ""),
                    proposed_fix=f.get("fix_diff"),
                    confidence=f.get("confidence", 0.5),
                ))
            except Exception:
                pass
        return findings

    async def _run_debate_rounds(
        self,
        code: str,
        filename: str,
        language: str,
        all_red_findings: list[RedTeamFinding],
        result: DebateResult,
    ) -> list[RedTeamFinding]:
        """执行多轮红蓝对抗"""
        for round_num in range(1, self.max_rounds + 1):
            if self.verbose:
                print(f"\n=== 对抗辩论 Round {round_num} ===")

            round_result = DebateRoundResult(round_num=round_num)

            # 红队攻击
            new_findings = await self._run_red_team_round(
                code, filename, language, all_red_findings, round_result,
            )
            all_red_findings.extend(new_findings)

            # 蓝队反驳
            if all_red_findings:
                await self._run_blue_team_round(
                    code, filename, language, all_red_findings, round_result,
                )

            result.rounds.append(round_result)

            # 收敛条件：本轮无新发现
            if not new_findings and round_num > 1:
                if self.verbose:
                    print(f"  红队无新发现，提前收敛")
                break

        return all_red_findings

    async def _run_red_team_round(
        self,
        code: str,
        filename: str,
        language: str,
        all_red_findings: list[RedTeamFinding],
        round_result: DebateRoundResult,
    ) -> list[RedTeamFinding]:
        """单轮红队攻击"""
        red_tasks = [
            self._run_red_team(
                persona_key, persona_data,
                code, filename, language,
                existing_findings=all_red_findings,
            )
            for persona_key, persona_data in RED_PERSONAS.items()
        ]
        red_outputs = await asyncio.gather(*red_tasks, return_exceptions=True)

        new_findings: list[RedTeamFinding] = []
        for output in red_outputs:
            if isinstance(output, Exception):
                if self.verbose:
                    print(f"  红队失败: {output}")
                continue
            for f in output.findings:
                if not self._is_duplicate(f, all_red_findings + new_findings):
                    new_findings.append(f)

        round_result.red_team_findings = new_findings
        round_result.new_findings_count = len(new_findings)
        if self.verbose:
            print(f"  红队新增 {len(new_findings)} findings")
        return new_findings

    async def _run_blue_team_round(
        self,
        code: str,
        filename: str,
        language: str,
        all_red_findings: list[RedTeamFinding],
        round_result: DebateRoundResult,
    ) -> None:
        """单轮蓝队反驳"""
        blue_tasks = [
            self._run_blue_team(
                persona_key, persona_data,
                code, filename, language,
                red_findings=all_red_findings,
            )
            for persona_key, persona_data in BLUE_PERSONAS.items()
        ]
        blue_outputs = await asyncio.gather(*blue_tasks, return_exceptions=True)

        all_rebuttals: list[BlueTeamRebuttal] = []
        for output in blue_outputs:
            if isinstance(output, Exception):
                continue
            all_rebuttals.extend(output.rebuttals)
        round_result.blue_team_rebuttals = all_rebuttals

        # 统计本轮反驳结果
        for r in all_rebuttals:
            if r.rebuttal_verdict == "VALID_CONCEDE":
                round_result.confirmed_count += 1
            elif r.rebuttal_verdict == "INVALID":
                round_result.rejected_count += 1

    async def _run_judge_phase(
        self,
        code: str,
        filename: str,
        language: str,
        all_red_findings: list[RedTeamFinding],
        result: DebateResult,
    ) -> None:
        """法官判定阶段"""
        if not all_red_findings:
            return
        # 收集所有反驳（按 finding location 索引）
        rebuttals_by_finding: dict[str, list[BlueTeamRebuttal]] = {}
        for r in result.rounds:
            for b in r.blue_team_rebuttals:
                rebuttals_by_finding.setdefault(b.red_finding_location, []).append(b)

        judge = await self._run_judge(
            all_red_findings, rebuttals_by_finding,
            code, filename, language,
        )
        result.judge = judge
        if not judge:
            return
        for r in judge.rulings:
            if r.final_verdict == "confirmed":
                result.final_confirmed.append(r)
            elif r.final_verdict == "rejected":
                result.final_rejected.append(r)
            else:
                result.final_needs_review.append(r)

    # -------- 红队 --------

    async def _run_red_team(
        self,
        persona_key: str,
        persona: dict,
        code: str,
        filename: str,
        language: str,
        existing_findings: list[RedTeamFinding],
    ) -> RedTeamOutput:
        """红队单 persona 攻击"""
        model = self.red_models[persona_key]
        user_prompt = self._build_red_team_prompt(
            persona, code, filename, language, existing_findings,
        )
        try:
            resp = await self.cli.chat(
                model=model,
                messages=[
                    {"role": "system", "content": persona["system"]},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
                max_tokens=3072,
            )
            return self._parse_red_team_output(resp.content, persona_key)
        except Exception as e:
            if self.verbose:
                print(f"  红队 {persona_key} 失败: {e}")
            return RedTeamOutput(findings=[])

    @staticmethod
    def _build_red_team_prompt(
        persona: dict, code: str, filename: str, language: str,
        existing_findings: list[RedTeamFinding],
    ) -> str:
        """构造红队 prompt"""
        existing_summary = ""
        if existing_findings:
            existing_summary = "\n\n【已知 finding，不要重复报】\n"
            for f in existing_findings[:20]:
                existing_summary += f"- [{f.severity.value}] {f.location}: {f.description[:80]}\n"
        return (
            f"# 代码文件: {filename} ({language})\n\n"
            f"```{language}\n{code}\n```\n"
            f"{existing_summary}\n\n"
            f"请以【{persona['name']}】视角找出代码中的问题。\n"
            f"只输出 JSON，格式：\n"
            '{\n  "findings": [\n    {\n'
            '      "severity": "critical|high|medium|low",\n'
            '      "location": "函数名 + 行号",\n'
            '      "description": "问题描述，至少 30 字",\n'
            '      "evidence": "代码证据",\n'
            '      "proposed_fix": "修复建议",\n'
            '      "confidence": 0.0-1.0\n'
            '    }\n  ]\n}'
        )

    def _parse_red_team_output(self, content: str, persona_key: str) -> RedTeamOutput:
        """解析红队 LLM 输出为 RedTeamOutput"""
        data = self._safe_json_loads(content)
        if not data:
            return RedTeamOutput(findings=[])
        findings = []
        for f in (data.get("findings") or [])[:10]:
            try:
                findings.append(RedTeamFinding(
                    severity=Severity(f.get("severity", "medium")),
                    location=f.get("location", "unknown"),
                    description=f.get("description", ""),
                    evidence=f.get("evidence", ""),
                    proposed_fix=f.get("proposed_fix"),
                    confidence=float(f.get("confidence", 0.5)),
                ))
            except Exception:
                continue
        return RedTeamOutput(findings=findings)

    # -------- 蓝队 --------

    async def _run_blue_team(
        self,
        persona_key: str,
        persona: dict,
        code: str,
        filename: str,
        language: str,
        red_findings: list[RedTeamFinding],
    ) -> BlueTeamOutput:
        """蓝队单 persona 反驳"""
        model = self.blue_models[persona_key]
        user_prompt = self._build_blue_team_prompt(
            persona, code, filename, language, red_findings,
        )
        try:
            resp = await self.cli.chat(
                model=model,
                messages=[
                    {"role": "system", "content": persona["system"]},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
                max_tokens=3072,
            )
            return self._parse_blue_team_output(resp.content)
        except Exception as e:
            if self.verbose:
                print(f"  蓝队 {persona_key} 失败: {e}")
            return BlueTeamOutput(rebuttals=[])

    @staticmethod
    def _build_blue_team_prompt(
        persona: dict, code: str, filename: str, language: str,
        red_findings: list[RedTeamFinding],
    ) -> str:
        """构造蓝队 prompt"""
        red_summary = "【红队 finding 列表】\n"
        for i, f in enumerate(red_findings, 1):
            red_summary += (
                f"{i}. [{f.severity.value}] {f.location}\n"
                f"   描述: {f.description}\n"
                f"   证据: {f.evidence[:200]}\n\n"
            )
        return (
            f"# 代码文件: {filename} ({language})\n\n"
            f"```{language}\n{code}\n```\n\n"
            f"{red_summary}\n\n"
            f"请以【{persona['name']}】视角，对每条红队 finding 给出反驳。\n"
            f"输出 JSON：\n"
            '{\n  "rebuttals": [\n    {\n'
            '      "red_finding_location": "对应红队 finding 的 location",\n'
            '      "rebuttal_verdict": "INVALID|EXAGGERATED|DUPLICATE|VALID_CONCEDE",\n'
            '      "reasoning": "反驳理由",\n'
            '      "evidence": "反驳证据"\n'
            '    }\n  ]\n}'
        )

    def _parse_blue_team_output(self, content: str) -> BlueTeamOutput:
        """解析蓝队 LLM 输出"""
        data = self._safe_json_loads(content)
        if not data:
            return BlueTeamOutput(rebuttals=[])
        rebuttals = []
        for b in (data.get("rebuttals") or [])[:30]:
            try:
                rebuttals.append(BlueTeamRebuttal(
                    red_finding_location=b.get("red_finding_location", ""),
                    rebuttal_verdict=b.get("rebuttal_verdict", "VALID_CONCEDE"),
                    reasoning=b.get("reasoning", ""),
                    evidence=b.get("evidence", ""),
                ))
            except Exception:
                continue
        return BlueTeamOutput(rebuttals=rebuttals)

    # -------- 法官 --------

    async def _run_judge(
        self,
        red_findings: list[RedTeamFinding],
        rebuttals_by_finding: dict[str, list[BlueTeamRebuttal]],
        code: str,
        filename: str,
        language: str,
    ) -> JudgeOutput:
        """法官仲裁"""
        user_prompt = self._build_judge_prompt(
            code, filename, language, red_findings, rebuttals_by_finding,
        )
        try:
            resp = await self.cli.chat(
                model=self.judge_model,
                messages=[
                    {"role": "system", "content": JUDGE_SYSTEM},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
                max_tokens=4096,
            )
            return self._parse_judge_output(resp.content)
        except Exception as e:
            if self.verbose:
                print(f"  法官失败: {e}")
            return JudgeOutput(rulings=[])

    @staticmethod
    def _build_judge_prompt(
        code: str, filename: str, language: str,
        red_findings: list[RedTeamFinding],
        rebuttals_by_finding: dict[str, list[BlueTeamRebuttal]],
    ) -> str:
        """构造法官 prompt（含完整法庭记录）"""
        court_record = AdversarialDebateEngine._build_court_record(
            red_findings, rebuttals_by_finding,
        )
        return (
            f"# 代码文件: {filename} ({language})\n\n"
            f"```{language}\n{code}\n```\n\n"
            f"{court_record}\n\n"
            f"请逐条判定。输出 JSON：\n"
            '{\n  "rulings": [\n    {\n'
            '      "red_finding_location": "对应 finding 的 location",\n'
            '      "final_verdict": "confirmed|rejected|needs_review",\n'
            '      "final_severity": "critical|high|medium|low|info",\n'
            '      "final_confidence": 0.0-1.0,\n'
            '      "reasoning": "判定理由，50-200 字"\n'
            '    }\n  ]\n}'
        )

    @staticmethod
    def _build_court_record(
        red_findings: list[RedTeamFinding],
        rebuttals_by_finding: dict[str, list[BlueTeamRebuttal]],
    ) -> str:
        """构造法庭记录"""
        record = "【法庭记录】\n\n"
        for i, f in enumerate(red_findings, 1):
            record += (
                f"--- Finding #{i} ---\n"
                f"严重度: {f.severity.value}\n"
                f"位置: {f.location}\n"
                f"红队描述: {f.description}\n"
                f"红队证据: {f.evidence[:300]}\n"
                f"红队置信度: {f.confidence}\n"
            )
            rebuttals = rebuttals_by_finding.get(f.location, [])
            if rebuttals:
                record += "蓝队反驳:\n"
                for b in rebuttals:
                    record += (
                        f"  - [{b.rebuttal_verdict}] {b.reasoning[:200]}\n"
                        f"    证据: {b.evidence[:150]}\n"
                    )
            else:
                record += "蓝队反驳: (无)\n"
            record += "\n"
        return record

    def _parse_judge_output(self, content: str) -> JudgeOutput:
        """解析法官 LLM 输出"""
        data = self._safe_json_loads(content)
        if not data:
            return JudgeOutput(rulings=[])
        rulings = []
        for r in (data.get("rulings") or []):
            try:
                rulings.append(JudgeRuling(
                    red_finding_location=r.get("red_finding_location", ""),
                    final_verdict=r.get("final_verdict", "needs_review"),
                    final_severity=Severity(r.get("final_severity", "info")),
                    final_confidence=float(r.get("final_confidence", 0.5)),
                    reasoning=r.get("reasoning", ""),
                ))
            except Exception:
                continue
        return JudgeOutput(rulings=rulings)

    # -------- 工具 --------

    @staticmethod
    def _safe_json_loads(text: str) -> dict | None:
        """容错 JSON 解析：剥离代码块 → 直接解析 → 正则提取"""
        text = AdversarialDebateEngine._strip_code_fence(text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return AdversarialDebateEngine._try_parse_json_from_regex(text)

    @staticmethod
    def _strip_code_fence(text: str) -> str:
        """剥离 ```json ... ``` 代码块"""
        text = text.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*\n", "", text)
            text = re.sub(r"\n```\s*$", "", text)
        return text

    @staticmethod
    def _try_parse_json_from_regex(text: str) -> dict | None:
        """正则提取 {...} 后尝试解析"""
        m = re.search(r"\{[\s\S]*\}", text)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    @staticmethod
    def _is_duplicate(
        new_finding: RedTeamFinding,
        existing: list[RedTeamFinding],
    ) -> bool:
        """简单去重：location + description 前 50 字"""
        new_key = (new_finding.location, new_finding.description[:50])
        for f in existing:
            old_key = (f.location, f.description[:50])
            if new_key == old_key:
                return True
        return False
