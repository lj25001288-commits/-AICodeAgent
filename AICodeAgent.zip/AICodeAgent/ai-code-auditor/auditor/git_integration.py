"""
Git Diff Integration
====================

支持只审 PR 改动 hunks，而不是整个文件。
模式：
  - python -m auditor file.py        # 审整个文件
  python -m auditor --diff HEAD~1    # 审 HEAD~1 之后的改动
  python -m auditor --diff main      # 审 main 分支分叉以来的改动
  python -m auditor --diff --cached  # 审已 stage 的改动
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Hunk:
    file: str                    # 改动文件路径
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    added_lines: list[str] = field(default_factory=list)
    removed_lines: list[str] = field(default_factory=list)
    context_lines: list[str] = field(default_factory=list)
    raw: str = ""


@dataclass
class _DiffParseState:
    """_parse_unified_diff 的内部状态，避免长函数里多个本地变量"""
    current_file: str | None = None
    current_hunk: Hunk | None = None


@dataclass
class DiffResult:
    base: str
    hunks_by_file: dict[str, list[Hunk]] = field(default_factory=dict)
    files_changed: list[str] = field(default_factory=list)

    def total_added_lines(self) -> int:
        return sum(len(h.added_lines) for hs in self.hunks_by_file.values() for h in hs)


class GitIntegration:
    """git 命令封装"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    def _run_git(self, *args: str) -> str:
        try:
            r = subprocess.run(
                ["git", *args],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if r.returncode != 0:
                raise RuntimeError(f"git {' '.join(args)} 失败: {r.stderr.strip()}")
            return r.stdout
        except FileNotFoundError as e:
            raise RuntimeError("未找到 git 命令，请确认已安装 git") from e

    def diff(self, base: str = "HEAD~1", cached: bool = False) -> DiffResult:
        """获取 git diff，解析 unified diff 格式"""
        if cached:
            out = self._run_git("diff", "--cached", "--unified=3")
        else:
            out = self._run_git("diff", base, "--unified=3")

        result = DiffResult(base=base)
        self._parse_unified_diff(out, result)
        return result

    def _parse_unified_diff(self, diff_text: str, result: DiffResult) -> None:
        """解析 unified diff 文本（拆分为子方法以降低复杂度）"""
        state = _DiffParseState()
        for line in diff_text.splitlines():
            if self._handle_file_header_line(line, result, state):
                continue
            if self._handle_hunk_header_line(line, result, state):
                continue
            self._handle_hunk_body_line(line, state)
        # 最后一个 hunk
        if state.current_hunk and state.current_file:
            result.hunks_by_file[state.current_file].append(state.current_hunk)

    @staticmethod
    def _handle_file_header_line(
        line: str, result: DiffResult, state: "_DiffParseState",
    ) -> bool:
        """处理 +++ / --- 文件头行，返回 True 表示已处理"""
        if not (line.startswith("+++ ") or line.startswith("--- ")):
            return False
        if line.startswith("+++ "):
            path = line[4:].strip()
            # 去掉 b/ 前缀
            if path.startswith("b/"):
                path = path[2:]
            if path != "/dev/null":
                state.current_file = path
                result.files_changed.append(path)
                result.hunks_by_file.setdefault(path, [])
        return True

    @staticmethod
    def _handle_hunk_header_line(
        line: str, result: DiffResult, state: "_DiffParseState",
    ) -> bool:
        """处理 @@ hunk 头行，返回 True 表示已处理"""
        if not line.startswith("@@"):
            return False
        # 上一个 hunk 入库
        if state.current_hunk and state.current_file:
            result.hunks_by_file[state.current_file].append(state.current_hunk)
        m = re.match(
            r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line,
        )
        if m:
            state.current_hunk = Hunk(
                file=state.current_file or "",
                old_start=int(m.group(1)),
                old_count=int(m.group(2) or 1),
                new_start=int(m.group(3)),
                new_count=int(m.group(4) or 1),
            )
        return True

    @staticmethod
    def _handle_hunk_body_line(line: str, state: "_DiffParseState") -> None:
        """处理 hunk body 行（+/-/context）"""
        if state.current_hunk is None:
            return
        if line.startswith("+"):
            state.current_hunk.added_lines.append(line[1:])
        elif line.startswith("-"):
            state.current_hunk.removed_lines.append(line[1:])
        elif line.startswith(" "):
            state.current_hunk.context_lines.append(line[1:])

    def read_file_at_ref(self, ref: str, path: str) -> str:
        """读取指定 ref 的文件内容"""
        try:
            return self._run_git("show", f"{ref}:{path}")
        except RuntimeError:
            # 新增的文件，ref 里没有
            return ""

    def read_current_file(self, path: str) -> str:
        """读取工作区当前文件"""
        full = Path(self.cwd) / path
        if not full.exists():
            return ""
        return full.read_text(encoding="utf-8", errors="replace")

    def changed_functions(self, diff: DiffResult) -> dict[str, list[str]]:
        """
        根据 diff 行号推断改动了哪些函数。
        返回 {file: [func_name, ...]}（仅支持 Python）
        """
        result: dict[str, list[str]] = {}
        for file, hunks in diff.hunks_by_file.items():
            if not file.endswith(".py"):
                continue
            changed = self._find_changed_functions_in_file(file, hunks)
            if changed:
                result[file] = changed
        return result

    def _find_changed_functions_in_file(
        self, file: str, hunks: list[Hunk],
    ) -> list[str]:
        """在单个文件中找出被 hunks 影响的函数"""
        import ast
        source = self.read_current_file(file)
        if not source:
            return []
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return []
        funcs = self._collect_function_ranges(tree)
        return self._match_hunks_to_funcs(hunks, funcs)

    @staticmethod
    def _collect_function_ranges(tree) -> list[tuple[str, int, int]]:
        """收集所有函数的 (name, start_line, end_line)"""
        import ast
        funcs: list[tuple[str, int, int]] = []
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = max(
                    (c.lineno for c in ast.walk(n) if hasattr(c, "lineno")),
                    default=n.lineno,
                )
                funcs.append((n.name, n.lineno, end))
        return funcs

    @staticmethod
    def _match_hunks_to_funcs(
        hunks: list[Hunk], funcs: list[tuple[str, int, int]],
    ) -> list[str]:
        """匹配 hunk 行号到函数，返回受影响的函数名列表"""
        changed: list[str] = []
        for hunk in hunks:
            for name, start, end in funcs:
                if start <= hunk.new_start <= end and name not in changed:
                    changed.append(name)
        return changed
