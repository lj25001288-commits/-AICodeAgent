"""
v3 Audit Pipeline — Orchestrator
================================

集成所有模块：
  静态分析 (tree-sitter) → AI 指纹 → Agent Loop → 红蓝对抗 → Sandbox 验证 → 报告

支持 3 种模式：
  - simple   : 只跑静态分析 + 单模型审计（最快，省 token）
  - standard : 静态 + 多模型 + 辩论（默认）
  - full     : 静态 + Agent Loop + 红蓝对抗 + Sandbox 验证（最慢，最准）
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from .adversarial_debate import AdversarialDebateEngine, DebateResult
from .agent_loop import AgentLoop, AgentRunResult
from .ai_fingerprint import FingerprintDetector, FingerprintReport
from .cache import AuditCache, CacheEntry
from .client import CallStats, MultiModelClient
from .patcher import PatchExtractor
from .sandbox import BatchValidationResult, validate_all_patches
from .tools import ToolRegistry
from .tree_sitter_analyzer import TSStaticReport, analyze_with_tree_sitter


# ============================================================
# 数据结构
# ============================================================

@dataclass
class AuditStage:
    role: str
    model: str
    usage_in: int
    usage_out: int
    latency_ms: int
    ok: bool
    error: str = ""


@dataclass
class AuditResult:
    filename: str
    language: str
    line_count: int
    mode: str = "standard"          # simple / standard / full

    static_report: TSStaticReport | None = None
    fingerprint: FingerprintReport | None = None
    agent_result: AgentRunResult | None = None
    debate_result: DebateResult | None = None
    sandbox_result: BatchValidationResult | None = None

    cache_hit: bool = False
    report: str = ""
    patches: list[str] = field(default_factory=list)
    verified_patches: list[str] = field(default_factory=list)
    stages: list[AuditStage] = field(default_factory=list)
    stats: CallStats | None = None
    total_ms: int = 0

    def banner(self) -> str:
        lines = ["", "=" * 72]
        lines.append(
            f"  审计完成: {self.filename}  ({self.line_count} 行, 模式: {self.mode})"
        )
        lines.append(f"  总耗时: {self.total_ms / 1000:.2f}s")
        if self.cache_hit:
            lines.append("  ⚡ 全部命中缓存，未调用模型")
        if self.stats:
            lines.append(self.stats.summary())
        if self.static_report:
            lines.append(self.static_report.summary())
        if self.fingerprint:
            lines.append(self.fingerprint.summary())
        if self.agent_result:
            lines.append(
                f"  Agent Loop: {self.agent_result.total_steps} 步, "
                f"{self.agent_result.tool_calls} 次工具调用, "
                f"{self.agent_result.total_ms / 1000:.2f}s"
            )
        if self.debate_result:
            lines.append(
                f"  红蓝对抗: {len(self.debate_result.rounds)} 轮, "
                f"红队提出 {self.debate_result.total_findings_raised} 个 finding, "
                f"法官 confirmed {len(self.debate_result.final_confirmed)}"
            )
        if self.sandbox_result:
            lines.append(
                f"  Sandbox 验证: {self.sandbox_result.verified}/{self.sandbox_result.total} 通过"
            )
        if self.patches:
            lines.append(f"  提取到 {len(self.patches)} 个 patch")
            if self.verified_patches:
                lines.append(f"  ✅ 其中 {len(self.verified_patches)} 个通过沙箱验证")
        lines.append("=" * 72)
        return "\n".join(lines)


# ============================================================
# 工具函数
# ============================================================

def _detect_language(filename: str) -> str:
    ext_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "tsx", ".jsx": "javascript", ".go": "go", ".rs": "rust",
        ".java": "java", ".rb": "ruby", ".c": "c", ".cpp": "cpp",
    }
    for ext, lang in ext_map.items():
        if filename.endswith(ext):
            return lang
    return "unknown"


def _strip_code_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*\n", "", text)
        text = re.sub(r"\n```\s*$", "", text)
    return text.strip()


def _safe_json_loads(text: str) -> dict | None:
    """容错 JSON 解析：先直接解析，失败则正则提取 {...} 再解析"""
    text = _strip_code_fence(text)
    # 第一次尝试：直接解析
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # 第二次尝试：正则提取 {...} 后解析
    return _try_parse_json_from_regex(text)


def _try_parse_json_from_regex(text: str) -> dict | None:
    """从文本中正则提取 {...} 后尝试解析"""
    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


def _format_static_signals(smells: list) -> str:
    if not smells:
        return "（无显著信号）"
    lines = []
    for s in smells[:15]:
        lines.append(
            f"- [{s.severity.upper()}] {s.location} ({s.category}): {s.detail}"
        )
    return "\n".join(lines)


# ============================================================
# 主流水线
# ============================================================

class AuditPipeline:
    """v3 主流水线"""

    def __init__(
        self,
        client: MultiModelClient,
        config: dict,
        cache: AuditCache | None = None,
        tool_registry: ToolRegistry | None = None,
    ) -> None:
        self.cli = client
        self.cfg = config
        self.cache = cache
        self.tools = tool_registry or ToolRegistry(cwd=config.get("cwd", "."))

        self.models = config.get("models", {})
        # 兼容旧配置（单字符串）
        for k, v in list(self.models.items()):
            if isinstance(v, str):
                self.models[k] = [v]

        self.mode = config.get("mode", "standard")  # simple / standard / full
        self.enable_fingerprint = config.get("enable_fingerprint", True)
        self.enable_agent = config.get("enable_agent", True)
        self.enable_debate = config.get("enable_debate", True)
        self.enable_sandbox = config.get("enable_sandbox", True)

        # full 模式默认开启所有
        if self.mode == "full":
            self.enable_agent = True
            self.enable_debate = True
            self.enable_sandbox = True
        # simple 模式默认关闭
        elif self.mode == "simple":
            self.enable_agent = False
            self.enable_debate = False
            self.enable_sandbox = False

    def _models_signature(self) -> str:
        return "|".join(
            f"{k}={','.join(v) if isinstance(v, list) else v}"
            for k, v in sorted(self.models.items())
        )

    # ============= 主入口 =============

    async def run(self, filepath: str) -> AuditResult:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            source = f.read()
        return await self.run_source(source, filepath)

    async def run_source(
        self, source: str, filename: str = "<code>",
    ) -> AuditResult:
        t0 = time.perf_counter()
        language = _detect_language(filename)
        result = AuditResult(
            filename=filename, language=language,
            line_count=source.count("\n") + 1, mode=self.mode,
        )

        # Step 0 + 0.5: 静态分析 + 指纹
        self._run_static_analysis(source, filename, language, result)

        # Step 1: 缓存检查
        if self._try_cache_hit(source, filename, result, t0):
            return result

        # Step 2: Simple 模式只跑单模型
        if self.mode == "simple":
            await self._run_simple(source, filename, language, result, t0)
            return result

        # Step 3-5: Standard / Full 模式
        decompose_data, logic_findings, code_findings = await self._run_main_pipeline(
            source, filename, language, result,
        )

        # Step 6: 提取 patch + 沙箱验证
        await self._finalize_report(source, filename, result)

        # Step 7: 写缓存
        self._write_cache(source, filename, result)

        result.total_ms = int((time.perf_counter() - t0) * 1000)
        result.stats = self.cli.stats
        return result

    def _run_static_analysis(
        self, source: str, filename: str, language: str, result: AuditResult,
    ) -> None:
        """Step 0 + 0.5: tree-sitter 静态分析 + AI 指纹识别"""
        result.static_report = analyze_with_tree_sitter(source, filename, language)
        if self.enable_fingerprint:
            result.fingerprint = FingerprintDetector().detect(source, filename)

    def _try_cache_hit(
        self, source: str, filename: str, result: AuditResult, t0: float,
    ) -> bool:
        """Step 1: 缓存检查，命中则填充 result 并返回 True"""
        if not self.cache:
            return False
        file_hash = AuditCache.hash_function(
            filename, "<whole-file>", source, self._models_signature(),
        )
        cached = self.cache.get(file_hash)
        if not cached:
            return False
        result.cache_hit = True
        result.report = cached.raw_report or cached.findings_summary
        result.total_ms = int((time.perf_counter() - t0) * 1000)
        return True

    async def _run_main_pipeline(
        self, source: str, filename: str, language: str, result: AuditResult,
    ) -> tuple[dict, dict, dict]:
        """Step 3-5: 拆解 + 多模型审计 + (Full 模式额外阶段) + 生成报告"""
        static_signals = _format_static_signals(result.static_report.top_smells(15))
        decompose_data = await self._run_decomposer(
            source, filename, language, static_signals, result,
        )
        logic_findings, code_findings = await self._run_auditors(
            source, filename, language, decompose_data, static_signals, result,
        )

        # Full 模式：Agent Loop + 红蓝对抗
        if self.mode == "full":
            await self._run_full_mode_extras(
                source, filename, language, logic_findings, code_findings, result,
            )

        # 生成最终报告
        result.report = await self._generate_final_report(
            source, filename, language, result,
            decompose_data, logic_findings, code_findings,
        )
        return decompose_data, logic_findings, code_findings

    async def _run_full_mode_extras(
        self, source: str, filename: str, language: str,
        logic_findings: dict, code_findings: dict, result: AuditResult,
    ) -> None:
        """Full 模式独有：Agent Loop + 红蓝对抗"""
        if self.enable_agent:
            result.agent_result = await self._run_agent_loop(
                source, filename, language, logic_findings, code_findings, result,
            )
        if self.enable_debate:
            initial_findings = self._collect_findings_for_debate(
                logic_findings, code_findings,
            )
            debate_engine = AdversarialDebateEngine(
                self.cli, self.cfg, max_rounds=2, verbose=False,
            )
            result.debate_result = await debate_engine.run(
                code=source, filename=filename, language=language,
                initial_findings=initial_findings,
            )

    async def _finalize_report(
        self, source: str, filename: str, result: AuditResult,
    ) -> None:
        """Step 6: 提取 patch + 沙箱验证"""
        result.patches = PatchExtractor.extract(result.report)
        if self.enable_sandbox and result.patches:
            await self._validate_patches(source, filename, result)

    def _write_cache(self, source: str, filename: str, result: AuditResult) -> None:
        """Step 7: 写缓存"""
        if not (self.cache and result.report and not result.cache_hit):
            return
        file_hash = AuditCache.hash_function(
            filename, "<whole-file>", source, self._models_signature(),
        )
        self.cache.put(CacheEntry(
            function_hash=file_hash,
            function_name="<whole-file>",
            file=filename,
            findings_summary=result.report[:500],
            severity_count={},
            created_at=time.time(),
            raw_report=result.report,
        ))

    # ============= 各阶段实现 =============

    async def _run_simple(
        self, source: str, filename: str, language: str,
        result: AuditResult, t0: float,
    ) -> None:
        """Simple 模式：单模型直接审"""
        static_signals = _format_static_signals(result.static_report.top_smells(15))
        model = (self.models.get("simple") or self.models.get("decomposer") or ["gpt-4o"])[0]

        try:
            resp = await self.cli.chat(
                model=model,
                messages=[
                    {"role": "system", "content": (
                        "你是代码审计专家。基于静态分析信号审计代码，"
                        "输出中文 Markdown 报告，含问题列表和修复建议。"
                    )},
                    {"role": "user", "content": (
                        f"# 代码文件: {filename} ({language})\n\n"
                        f"```{language}\n{source}\n```\n\n"
                        f"# 静态分析信号\n{static_signals}\n\n"
                        f"请输出审计报告。"
                    )},
                ],
                temperature=0.2,
                max_tokens=4096,
            )
            self.cli.stats.record("simple", resp.model, resp.usage)
            result.report = resp.content
            result.stages.append(AuditStage(
                role="simple", model=resp.model,
                usage_in=resp.usage.prompt_tokens,
                usage_out=resp.usage.completion_tokens,
                latency_ms=resp.latency_ms, ok=True,
            ))
        except Exception as e:
            result.report = f"# 审计失败\n\n{e}"
            result.stages.append(AuditStage(
                role="simple", model=model,
                usage_in=0, usage_out=0, latency_ms=0,
                ok=False, error=str(e),
            ))

        result.patches = PatchExtractor.extract(result.report)
        result.total_ms = int((time.perf_counter() - t0) * 1000)
        result.stats = self.cli.stats

    async def _run_decomposer(
        self, source: str, filename: str, language: str,
        static_signals: str, result: AuditResult,
    ) -> dict:
        """Round 1: 拆解"""
        from .prompts_v3 import DECOMPOSER_SYSTEM, DECOMPOSER_USER_TEMPLATE

        candidates = self.models.get("decomposer", ["gpt-4o"])
        try:
            resp = await self.cli.chat_with_fallback(
                role="decomposer", candidates=candidates,
                messages=[
                    {"role": "system", "content": DECOMPOSER_SYSTEM},
                    {"role": "user", "content": DECOMPOSER_USER_TEMPLATE.format(
                        language=language, filename=filename,
                        code=source, static_signals=static_signals,
                    )},
                ],
                temperature=0.2, max_tokens=2048,
            )
            result.stages.append(AuditStage(
                role="decomposer", model=resp.model,
                usage_in=resp.usage.prompt_tokens,
                usage_out=resp.usage.completion_tokens,
                latency_ms=resp.latency_ms, ok=True,
            ))
            return _safe_json_loads(resp.content) or {
                "intent": "(解析失败)", "audit_checklist": [],
            }
        except Exception as e:
            result.stages.append(AuditStage(
                role="decomposer", model=candidates[0],
                usage_in=0, usage_out=0, latency_ms=0,
                ok=False, error=str(e),
            ))
            return {"intent": "(失败)", "audit_checklist": []}

    async def _run_auditors(
        self, source: str, filename: str, language: str,
        decompose_data: dict, static_signals: str, result: AuditResult,
    ) -> tuple[dict, dict]:
        """Round 1: 逻辑审计 + 代码专项（并发）"""
        from .prompts_v3 import (
            LOGIC_AUDITOR_SYSTEM, LOGIC_AUDITOR_USER_TEMPLATE,
            CODE_SPECIALIST_SYSTEM, CODE_SPECIALIST_USER_TEMPLATE,
        )
        checklist_json = json.dumps(
            decompose_data.get("audit_checklist", []),
            ensure_ascii=False, indent=2,
        )
        logic_candidates = self.models.get("logic_auditor", ["claude-3-5-sonnet-20241022"])
        code_candidates = self.models.get("code_specialist", ["deepseek-coder"])

        logic_task = self._run_single_auditor(
            role="logic_auditor", candidates=logic_candidates,
            system=LOGIC_AUDITOR_SYSTEM,
            user=LOGIC_AUDITOR_USER_TEMPLATE.format(
                language=language, filename=filename, code=source,
                checklist_json=checklist_json, static_signals=static_signals,
            ),
            fallback={"findings": [], "additional_findings": []},
            result=result,
        )
        code_task = self._run_single_auditor(
            role="code_specialist", candidates=code_candidates,
            system=CODE_SPECIALIST_SYSTEM,
            user=CODE_SPECIALIST_USER_TEMPLATE.format(
                language=language, filename=filename, code=source,
                static_signals=static_signals,
            ),
            fallback={"findings": []},
            result=result,
        )
        return await asyncio.gather(logic_task, code_task)

    async def _run_single_auditor(
        self,
        role: str,
        candidates: list[str],
        system: str,
        user: str,
        fallback: dict,
        result: AuditResult,
    ) -> dict:
        """单个审计员调用（带 reasoning recovery + 错误兜底）"""
        try:
            resp = await self.cli.chat_with_reasoning_recovery(
                model=candidates[0],
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                temperature=0.2, max_tokens=8192,
                max_recovery_attempts=2,
            )
            self.cli.stats.record(role, resp.model, resp.usage)
            result.stages.append(AuditStage(
                role=role, model=resp.model,
                usage_in=resp.usage.prompt_tokens,
                usage_out=resp.usage.completion_tokens,
                latency_ms=resp.latency_ms, ok=True,
            ))
            return _safe_json_loads(resp.content) or fallback
        except Exception as e:
            self.cli.stats.fail()
            result.stages.append(AuditStage(
                role=role, model=candidates[0],
                usage_in=0, usage_out=0, latency_ms=0,
                ok=False, error=str(e),
            ))
            return fallback

    async def _run_agent_loop(
        self, source: str, filename: str, language: str,
        logic_findings: dict, code_findings: dict, result: AuditResult,
    ) -> AgentRunResult:
        """Agent Loop 验证关键 findings"""
        # 选 top 3 最严重的 findings 让 Agent 验证
        all_findings = (
            (logic_findings.get("findings") or [])
            + (logic_findings.get("additional_findings") or [])
            + (code_findings.get("findings") or [])
        )
        sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        all_findings.sort(key=lambda f: sev_rank.get(str(f.get("severity", "info")).lower(), 4))
        top_findings = all_findings[:3]

        if not top_findings:
            return AgentRunResult(final_summary="(无关键 finding 需要验证)")

        # 构造 Agent 任务
        findings_text = json.dumps(top_findings, ensure_ascii=False, indent=2)
        task = (
            "请验证以下审计发现是否真实存在。通过调用工具（grep_code/read_file/run_tests 等）"
            "找到证据，确认或反驳每条 finding。\n\n"
            f"待验证 findings:\n{findings_text}"
        )
        context = (
            f"# 待审计文件: {filename} ({language})\n"
            f"```{language}\n{source}\n```"
        )

        agent_model = (self.models.get("agent") or ["gpt-4o"])[0]
        loop = AgentLoop(
            client=self.cli, tool_registry=self.tools,
            model=agent_model, max_steps=8, verbose=False,
        )
        return await loop.run(task=task, context=context)

    def _collect_findings_for_debate(
        self, logic_findings: dict, code_findings: dict,
    ) -> list[dict]:
        """把所有 findings 合并成红队初始种子"""
        all_findings = []
        for f in (logic_findings.get("findings") or []):
            all_findings.append({
                "severity": f.get("severity", "medium"),
                "location": f.get("location", ""),
                "description": f.get("description", ""),
                "suggestion": f.get("suggestion", ""),
                "confidence": f.get("confidence", 0.5),
            })
        for f in (logic_findings.get("additional_findings") or []):
            all_findings.append({
                "severity": f.get("severity", "medium"),
                "location": f.get("location", ""),
                "description": f.get("description", ""),
                "suggestion": f.get("suggestion", ""),
                "confidence": f.get("confidence", 0.5),
            })
        for f in (code_findings.get("findings") or []):
            all_findings.append({
                "severity": f.get("severity", "medium"),
                "location": f.get("location", ""),
                "description": f.get("description", ""),
                "suggestion": f.get("suggestion", ""),
                "confidence": f.get("confidence", 0.5),
            })
        return all_findings

    async def _generate_final_report(
        self, source: str, filename: str, language: str,
        result: AuditResult,
        decompose_data: dict, logic_findings: dict, code_findings: dict,
    ) -> str:
        """生成最终中文报告"""
        from .prompts_v3 import ARBITER_SYSTEM, ARBITER_USER_TEMPLATE

        fingerprint_summary = "（未启用）"
        if result.fingerprint:
            fp = result.fingerprint
            sorted_scores = sorted(fp.scores.items(), key=lambda x: -x[1])
            fingerprint_summary = (
                f"结论: {fp.verdict} (置信度 {fp.confidence:.0%})\n"
                + "\n".join(f"  {k}: {v:.1%}" for k, v in sorted_scores)
                + "\n关键证据:\n  " + "\n  ".join(fp.signals)
            )

        agent_summary = "(未启用)"
        if result.agent_result:
            agent_summary = result.agent_result.final_summary[:2000]

        debate_summary = "(未启用)"
        if result.debate_result:
            d = result.debate_result
            debate_summary = (
                f"总轮次: {len(d.rounds)}\n"
                f"红队提出: {d.total_findings_raised} 个 finding\n"
                f"法官 confirmed: {len(d.final_confirmed)}\n"
                f"法官 rejected: {len(d.final_rejected)}\n"
                f"法官 needs_review: {len(d.final_needs_review)}\n\n"
                "已确认 findings:\n"
                + "\n".join(
                    f"  [{r.final_severity.value}] {r.red_finding_location}: {r.reasoning[:100]}"
                    for r in d.final_confirmed[:10]
                )
            )

        candidates = self.models.get("arbiter", ["qwen-max", "gpt-4o"])
        try:
            resp = await self.cli.chat_with_fallback(
                role="arbiter", candidates=candidates,
                messages=[
                    {"role": "system", "content": ARBITER_SYSTEM},
                    {"role": "user", "content": ARBITER_USER_TEMPLATE.format(
                        language=language, filename=filename,
                        intent=decompose_data.get("intent", ""),
                        fingerprint_summary=fingerprint_summary,
                        static_summary=_format_static_signals(result.static_report.top_smells(15)),
                        agent_summary=agent_summary,
                        debate_summary=debate_summary,
                        logic_findings_json=json.dumps(logic_findings, ensure_ascii=False, indent=2),
                        code_findings_json=json.dumps(code_findings, ensure_ascii=False, indent=2),
                    )},
                ],
                temperature=0.2, max_tokens=6144,
            )
            result.stages.append(AuditStage(
                role="arbiter", model=resp.model,
                usage_in=resp.usage.prompt_tokens,
                usage_out=resp.usage.completion_tokens,
                latency_ms=resp.latency_ms, ok=True,
            ))
            return resp.content
        except Exception as e:
            result.stages.append(AuditStage(
                role="arbiter", model=candidates[0],
                usage_in=0, usage_out=0, latency_ms=0,
                ok=False, error=str(e),
            ))
            return f"# 审计失败\n\n仲裁阶段失败: {e}"

    async def _validate_patches(
        self, source: str, filename: str, result: AuditResult,
    ) -> None:
        """沙箱验证所有 patch"""
        if not result.patches:
            return
        sandbox_model = (self.models.get("sandbox") or ["gpt-4o"])[0]
        try:
            sandbox_result = await validate_all_patches(
                client=self.cli,
                patches=result.patches,
                target_file=filename,
                original_code=source,
                cwd=self.cfg.get("cwd", "."),
                model=sandbox_model,
                max_concurrency=2,
                verbose=False,
            )
            result.sandbox_result = sandbox_result
            self._collect_verified_patches(sandbox_result, result)
        except Exception:
            # 沙箱失败不影响主流程
            pass

    @staticmethod
    def _collect_verified_patches(sandbox_result, result: AuditResult) -> None:
        """从沙箱结果收集通过验证的 patch"""
        for detail in sandbox_result.details:
            if isinstance(detail, dict) and detail.get("verdict") == "verified":
                patch = detail.get("final_patch")
                if patch:
                    result.verified_patches.append(patch)


# ============================================================
# Git Diff 模式
# ============================================================

class DiffPipeline:
    """只审 git diff 改动"""

    def __init__(
        self, client: MultiModelClient, config: dict, git_cwd: str = ".",
    ) -> None:
        self.cli = client
        self.cfg = config
        self.git_cwd = git_cwd
        self.inner = AuditPipeline(client, config)

    async def run(self, base: str = "HEAD~1", cached: bool = False) -> list[AuditResult]:
        from .git_integration import GitIntegration
        gi = GitIntegration(self.git_cwd)
        diff = gi.diff(base=base, cached=cached)
        results: list[AuditResult] = []
        for file in diff.files_changed:
            source = gi.read_current_file(file)
            if not source:
                continue
            hunks = diff.hunks_by_file.get(file, [])
            diff_context = "\n\n# === 本次改动的 hunks ===\n"
            for h in hunks:
                diff_context += f"# @@ L{h.new_start} (+{len(h.added_lines)} -{len(h.removed_lines)})\n"
                for line in h.added_lines:
                    diff_context += f"# + {line}\n"
                for line in h.removed_lines:
                    diff_context += f"# - {line}\n"
            r = await self.inner.run_source(source + diff_context, file)
            results.append(r)
        return results
