"""
Sandbox Patch Validation
========================

LLM 生成的 patch 不能直接应用——必须先在沙箱里跑测试。

流程：
1. 复制目标文件到临时目录
2. 应用 patch
3. 跑语法检查
4. 跑测试套件
5. 测试通过 → 标记 verified
6. 测试失败 → 把错误反馈给 LLM 重新生成（最多 3 轮）

不污染工作区，不破坏 git 状态。
"""
from __future__ import annotations

import asyncio
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .client import MultiModelClient
from .patcher import PatchApplier, PatchExtractor
from .schemas import PatchValidationResult
from .tools import RunTestsTool


# ============================================================
# 沙箱环境
# ============================================================

@dataclass
class SandboxEnv:
    """临时沙箱目录"""
    temp_dir: Path
    target_file_relative: str        # 相对于 cwd 的目标文件路径
    target_file_in_sandbox: Path     # 沙箱内的目标文件路径

    def cleanup(self) -> None:
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir, ignore_errors=True)


def create_sandbox(
    target_file: str,
    cwd: str = ".",
    extra_files: list[str] | None = None,
) -> SandboxEnv:
    """
    创建沙箱：把目标文件 + 相关文件 + 项目配置复制到临时目录
    """
    cwd_path = Path(cwd).resolve()
    target_path = (cwd_path / target_file).resolve()
    temp_dir = Path(tempfile.mkdtemp(prefix="auditor_sandbox_"))

    # 复制目标文件
    rel = target_path.relative_to(cwd_path)
    target_in_sandbox = temp_dir / rel
    target_in_sandbox.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target_path, target_in_sandbox)

    # 复制额外文件
    if extra_files:
        _copy_extra_files(cwd_path, temp_dir, extra_files)

    # 复制项目配置
    _copy_project_configs(cwd_path, temp_dir)

    return SandboxEnv(
        temp_dir=temp_dir,
        target_file_relative=str(rel),
        target_file_in_sandbox=target_in_sandbox,
    )


def _copy_extra_files(cwd_path: Path, temp_dir: Path, extra_files: list[str]) -> None:
    """复制额外文件或目录到沙箱"""
    for ef in extra_files:
        ef_path = (cwd_path / ef).resolve()
        if not ef_path.exists():
            continue
        ef_rel = ef_path.relative_to(cwd_path)
        if ef_path.is_dir():
            shutil.copytree(ef_path, temp_dir / ef_rel, dirs_exist_ok=True)
        else:
            (temp_dir / ef_rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ef_path, temp_dir / ef_rel)


def _copy_project_configs(cwd_path: Path, temp_dir: Path) -> None:
    """复制项目配置文件到沙箱"""
    config_files = [
        "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt",
        "package.json", "go.mod", "Cargo.toml",
    ]
    for cfg in config_files:
        cfg_path = cwd_path / cfg
        if cfg_path.exists():
            shutil.copy2(cfg_path, temp_dir / cfg)


# ============================================================
# 沙箱验证器
# ============================================================

class SandboxValidator:
    """Patch 沙箱验证器"""

    def __init__(
        self,
        client: MultiModelClient,
        model: str = "gpt-4o",
        max_retries: int = 3,
        test_path: str = "tests/",
        verbose: bool = False,
    ) -> None:
        self.cli = client
        self.model = model
        self.max_retries = max_retries
        self.test_path = test_path
        self.verbose = verbose

    async def validate_patch(
        self,
        patch_text: str,
        target_file: str,
        original_code: str,
        cwd: str = ".",
        extra_files: list[str] | None = None,
    ) -> PatchValidationResult:
        """验证单个 patch"""
        # 把 patch 中的文件路径改为沙箱内的路径
        # patch 格式：--- a/path/to/file  →  --- a/<sandbox>/path/to/file
        # 但 git apply 是相对 cwd 的，所以直接在沙箱目录跑就行

        sandbox = create_sandbox(target_file, cwd, extra_files)
        try:
            # 步骤 1: 应用 patch 到沙箱
            applier = PatchApplier(cwd=str(sandbox.temp_dir))
            apply_result = applier.apply(patch_text, check=False)

            if not apply_result.success:
                return PatchValidationResult(
                    patch_applied=False,
                    tests_passed=False,
                    test_output=apply_result.output,
                    syntax_valid=False,
                    verdict="apply_failed",
                    feedback_for_llm=f"patch 应用失败: {apply_result.output}",
                )

            # 步骤 2: 语法检查
            target_in_sandbox = sandbox.target_file_in_sandbox
            syntax_ok, syntax_err = self._check_syntax(
                str(target_in_sandbox), target_file,
            )
            if not syntax_ok:
                return PatchValidationResult(
                    patch_applied=True,
                    tests_passed=False,
                    test_output=syntax_err,
                    syntax_valid=False,
                    verdict="syntax_error",
                    feedback_for_llm=(
                        f"应用 patch 后语法错误:\n{syntax_err}\n\n"
                        f"请重新生成 patch，确保语法正确。"
                    ),
                )

            # 步骤 3: 跑测试
            test_tool = RunTestsTool(cwd=str(sandbox.temp_dir))
            test_result = await test_tool.run(
                test_path=self.test_path,
                runner="auto",
                timeout=60,
            )

            if test_result.ok:
                return PatchValidationResult(
                    patch_applied=True,
                    tests_passed=True,
                    test_output=test_result.output[:3000],
                    syntax_valid=True,
                    verdict="verified",
                )
            else:
                return PatchValidationResult(
                    patch_applied=True,
                    tests_passed=False,
                    test_output=test_result.output[:3000],
                    syntax_valid=True,
                    verdict="tests_failed",
                    feedback_for_llm=(
                        f"应用 patch 后测试失败:\n{test_result.output[:2000]}\n\n"
                        f"请重新生成 patch，确保不破坏现有测试。"
                    ),
                )

        finally:
            sandbox.cleanup()

    async def validate_and_regenerate(
        self,
        initial_patch: str,
        target_file: str,
        original_code: str,
        issue_description: str,
        cwd: str = ".",
        extra_files: list[str] | None = None,
    ) -> tuple[PatchValidationResult, str]:
        """
        验证 patch，失败则反馈给 LLM 重新生成。
        返回 (最终验证结果, 最终 patch 文本)
        """
        current_patch = initial_patch

        for attempt in range(1, self.max_retries + 1):
            if self.verbose:
                print(f"  [sandbox] 验证尝试 {attempt}/{self.max_retries}")

            result = await self.validate_patch(
                current_patch, target_file, original_code, cwd, extra_files,
            )

            if result.verdict == "verified":
                if self.verbose:
                    print(f"  [sandbox] ✅ 验证通过")
                return result, current_patch

            if self.verbose:
                print(f"  [sandbox] ❌ {result.verdict}, 重新生成 patch...")

            # 最后一次不再重生
            if attempt == self.max_retries:
                return result, current_patch

            # 反馈给 LLM 重新生成
            new_patch = await self._regenerate_patch(
                original_code=original_code,
                issue_description=issue_description,
                previous_patch=current_patch,
                failure_reason=result.feedback_for_llm or "未知错误",
                target_file=target_file,
            )
            if not new_patch:
                return result, current_patch
            current_patch = new_patch

        # 不应该走到这
        return result, current_patch

    # -------- 内部 --------

    @staticmethod
    def _check_syntax(file_path: str, filename: str) -> tuple[bool, str]:
        """语法检查"""
        ext = Path(filename).suffix.lower()
        try:
            if ext == ".py":
                r = subprocess.run(
                    ["python", "-m", "py_compile", file_path],
                    capture_output=True, text=True, timeout=10,
                )
                if r.returncode != 0:
                    return False, r.stderr
                return True, ""
            elif ext in (".js", ".jsx", ".ts", ".tsx"):
                # 用 node 检查 JS 语法
                r = subprocess.run(
                    ["node", "--check", file_path],
                    capture_output=True, text=True, timeout=10,
                )
                if r.returncode != 0:
                    return False, r.stderr
                return True, ""
            elif ext == ".go":
                r = subprocess.run(
                    ["gofmt", "-e", file_path],
                    capture_output=True, text=True, timeout=10,
                )
                if r.returncode != 0:
                    return False, r.stderr
                return True, ""
            else:
                # 不支持的语言，跳过语法检查
                return True, ""
        except FileNotFoundError as e:
            # 工具不存在，跳过
            return True, f"语法检查工具不可用: {e}"
        except Exception as e:
            return False, str(e)

    async def _regenerate_patch(
        self,
        original_code: str,
        issue_description: str,
        previous_patch: str,
        failure_reason: str,
        target_file: str,
    ) -> str | None:
        """让 LLM 重新生成 patch"""
        prompt = (
            f"# 任务\n"
            f"重新生成一个 unified diff patch。\n\n"
            f"# 待修复文件: {target_file}\n\n"
            f"# 原始代码\n```\n{original_code}\n```\n\n"
            f"# 要解决的问题\n{issue_description}\n\n"
            f"# 上次生成的 patch（失败了）\n```\n{previous_patch}\n```\n\n"
            f"# 失败原因\n{failure_reason}\n\n"
            f"# 要求\n"
            f"1. 生成严格 unified diff 格式（--- a/path, +++ b/path, @@ 行号 @@）\n"
            f"2. 确保行号准确\n"
            f"3. 只输出 patch 本身，不要解释\n"
        )
        try:
            resp = await self.cli.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是代码修复专家。生成严格 unified diff 格式的 patch。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.1,
                max_tokens=2048,
            )
            # 提取 patch 文本
            patches = PatchExtractor.extract(resp.content)
            return patches[0] if patches else None
        except Exception:
            return None


# ============================================================
# 批量验证
# ============================================================

@dataclass
class BatchValidationResult:
    """批量验证结果"""
    total: int = 0
    verified: int = 0
    syntax_error: int = 0
    tests_failed: int = 0
    apply_failed: int = 0
    details: list[dict] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            "",
            "=" * 60,
            f"  Patch 批量验证结果:",
            f"    总数: {self.total}",
            f"    ✅ 已验证: {self.verified}",
            f"    ❌ 语法错误: {self.syntax_error}",
            f"    ❌ 测试失败: {self.tests_failed}",
            f"    ❌ 应用失败: {self.apply_failed}",
            f"    验证率: {self.verified / max(self.total, 1):.0%}",
            "=" * 60,
        ]
        return "\n".join(lines)


async def validate_all_patches(
    client: MultiModelClient,
    patches: list[str],
    target_file: str,
    original_code: str,
    issue_descriptions: list[str] | None = None,
    cwd: str = ".",
    model: str = "gpt-4o",
    max_concurrency: int = 2,
    verbose: bool = False,
) -> BatchValidationResult:
    """并发验证多个 patch"""
    validator = SandboxValidator(client, model=model, verbose=verbose)
    sem = asyncio.Semaphore(max_concurrency)
    result = BatchValidationResult(total=len(patches))

    async def _validate_one(idx: int, patch: str) -> dict:
        async with sem:
            issue_desc = (
                issue_descriptions[idx] if issue_descriptions
                else "审计发现的问题"
            )
            res, final_patch = await validator.validate_and_regenerate(
                initial_patch=patch,
                target_file=target_file,
                original_code=original_code,
                issue_description=issue_desc,
                cwd=cwd,
            )
            return {
                "index": idx,
                "verdict": res.verdict,
                "tests_passed": res.tests_passed,
                "syntax_valid": res.syntax_valid,
                "final_patch": final_patch,
            }

    tasks = [_validate_one(i, p) for i, p in enumerate(patches)]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for r in results:
        if isinstance(r, Exception):
            result.apply_failed += 1
            result.details.append({"error": str(r)})
            continue
        result.details.append(r)
        if r["verdict"] == "verified":
            result.verified += 1
        elif r["verdict"] == "syntax_error":
            result.syntax_error += 1
        elif r["verdict"] == "tests_failed":
            result.tests_failed += 1
        else:
            result.apply_failed += 1

    return result
