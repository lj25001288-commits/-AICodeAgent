"""
Agent Tool Calling Toolkit
==========================

让 Agent 拥有"主动调工具"的能力，而不是一次性 prompt。
每个工具返回结构化结果，供 Agent 在下一步决策使用。

工具列表：
- grep_code       : 在代码库搜索 pattern
- read_file       : 读文件（支持行号范围）
- list_directory  : 列目录
- run_tests       : 跑测试
- read_git_log    : 看 git 历史
- search_docs     : 查库文档（在线或本地索引）
- search_similar_cases : 向量检索历史审计案例
"""
from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .schemas import ToolName


# ============================================================
# Tool 执行结果
# ============================================================

@dataclass
class ToolResult:
    tool: str
    ok: bool
    output: str           # 给 LLM 看的文本
    raw: Any = None       # 原始数据（用于程序逻辑）
    latency_ms: int = 0
    error: str = ""

    def to_llm_message(self) -> str:
        """格式化成 LLM 友好的文本"""
        status = "OK" if self.ok else "FAIL"
        header = f"=== [{status}] {self.tool} ({self.latency_ms}ms) ==="
        if not self.ok:
            return f"{header}\nError: {self.error}\n"
        body = self.output
        if len(body) > 8000:
            body = body[:8000] + f"\n... (truncated, total {len(body)} chars)"
        return f"{header}\n{body}\n"


# ============================================================
# 工具实现
# ============================================================

class GrepCodeTool:
    """ripgrep 包装（必须用 rg，不用 grep）"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    async def run(self, pattern: str, glob: str = "*", max_results: int = 50) -> ToolResult:
        import time
        t0 = time.perf_counter()
        try:
            # 用 subprocess 调 ripgrep
            cmd = ["rg", "--no-heading", "-n", "--color=never",
                   "-g", glob, "--max-count", str(max_results),
                   pattern, self.cwd]
            r = subprocess.run(
                cmd, capture_output=True, text=True, timeout=15,
            )
            latency_ms = int((time.perf_counter() - t0) * 1000)
            if r.returncode not in (0, 1):  # rg 无匹配返回 1
                return ToolResult(
                    tool="grep_code", ok=False, error=r.stderr.strip(),
                    latency_ms=latency_ms,
                )
            # rg 返回 0 表示有匹配，1 表示无匹配
            output = r.stdout.strip() if r.stdout.strip() else "(无匹配)"
            return ToolResult(
                tool="grep_code", ok=True, output=output,
                raw={"matches": r.stdout.count("\n") + (1 if r.stdout else 0)},
                latency_ms=latency_ms,
            )
        except FileNotFoundError:
            # 兜底：纯 Python 实现
            return await self._fallback_python(pattern, glob, max_results, t0)
        except Exception as e:
            return ToolResult(
                tool="grep_code", ok=False, error=str(e),
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )

    async def _fallback_python(self, pattern: str, glob: str, max_results: int, t0: float) -> ToolResult:
        """没有 rg 时用纯 Python glob + regex"""
        try:
            regex = re.compile(pattern)
        except re.error as e:
            return ToolResult(
                tool="grep_code", ok=False, error=f"正则编译失败: {e}",
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        matches = self._grep_python(regex, glob, max_results)
        output = "\n".join(matches) if matches else "(无匹配)"
        return ToolResult(
            tool="grep_code", ok=True, output=output,
            raw={"matches": len(matches)},
            latency_ms=int((time.perf_counter() - t0) * 1000),
        )

    def _grep_python(self, regex, glob: str, max_results: int) -> list[str]:
        """纯 Python 实现的 grep"""
        matches: list[str] = []
        from pathlib import Path
        for path in Path(self.cwd).rglob(glob if glob != "*" else "**/*"):
            if not self._should_search(path):
                continue
            file_matches = self._grep_in_file(regex, path)
            matches.extend(file_matches)
            if len(matches) >= max_results:
                return matches[:max_results]
        return matches

    @staticmethod
    def _should_search(path) -> bool:
        """判断路径是否应被搜索"""
        if not path.is_file():
            return False
        skip_dirs = {".git", "__pycache__", "node_modules", ".venv"}
        return not any(p in path.parts for p in skip_dirs)

    def _grep_in_file(self, regex, path) -> list[str]:
        """在单个文件中搜索 pattern"""
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return []
        rel = path.relative_to(self.cwd)
        return [
            f"{rel}:{i}:{line}"
            for i, line in enumerate(text.splitlines(), 1)
            if regex.search(line)
        ]


class ReadFileTool:
    """读文件，支持行号范围"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    async def run(self, path: str, start_line: int = 1, end_line: int = 0) -> ToolResult:
        import time
        t0 = time.perf_counter()
        full = Path(self.cwd) / path
        try:
            text = full.read_text(encoding="utf-8", errors="replace")
            lines = text.splitlines()
            total = len(lines)
            if end_line <= 0 or end_line > total:
                end_line = total
            start_line = max(1, start_line)
            selected = lines[start_line - 1:end_line]
            # 加行号
            output_lines = []
            for i, line in enumerate(selected, start_line):
                output_lines.append(f"{i:>5}│ {line}")
            output = "\n".join(output_lines)
            return ToolResult(
                tool="read_file", ok=True,
                output=f"文件: {path} (显示 L{start_line}-{end_line} / 共 {total} 行)\n{output}",
                raw={"total_lines": total, "shown_lines": len(selected)},
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except FileNotFoundError:
            return ToolResult(
                tool="read_file", ok=False, error=f"文件不存在: {path}",
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except Exception as e:
            return ToolResult(
                tool="read_file", ok=False, error=str(e),
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )


class ListDirectoryTool:
    """列目录（深度 1-2）"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    async def run(self, path: str = ".", depth: int = 1, max_items: int = 100) -> ToolResult:
        import time
        t0 = time.perf_counter()
        full = Path(self.cwd) / path
        try:
            items: list[str] = []
            if depth == 1:
                for p in sorted(full.iterdir()):
                    name = p.name + ("/" if p.is_dir() else "")
                    items.append(name)
                    if len(items) >= max_items:
                        break
            else:
                for root, dirs, files in os.walk(full):
                    rel = Path(root).relative_to(full)
                    depth_now = len(rel.parts) if str(rel) != "." else 0
                    if depth_now >= depth:
                        dirs[:] = []
                        continue
                    # 跳过无用目录
                    dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "node_modules", ".venv"}]
                    for f in files[:20]:
                        full_rel = (rel / f) if str(rel) != "." else Path(f)
                        items.append(str(full_rel))
                        if len(items) >= max_items:
                            break
                    if len(items) >= max_items:
                        break
            return ToolResult(
                tool="list_directory", ok=True,
                output=f"目录: {path} (深度 {depth}, {len(items)} 项)\n" + "\n".join(items),
                raw={"item_count": len(items)},
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except Exception as e:
            return ToolResult(
                tool="list_directory", ok=False, error=str(e),
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )


class RunTestsTool:
    """跑测试套件"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    async def run(
        self,
        test_path: str = "tests/",
        runner: str = "auto",
        timeout: int = 60,
    ) -> ToolResult:
        import time
        t0 = time.perf_counter()
        # 自动选择 runner
        if runner == "auto":
            if (Path(self.cwd) / "pytest.ini").exists() or any(
                (Path(self.cwd) / f).exists() for f in ["setup.py", "pyproject.toml"]
            ):
                runner = "pytest"
            elif (Path(self.cwd) / "package.json").exists():
                runner = "npm"
            elif (Path(self.cwd) / "go.mod").exists():
                runner = "go"
            elif (Path(self.cwd) / "Cargo.toml").exists():
                runner = "cargo"
            else:
                runner = "pytest"  # 默认尝试

        cmd_map = {
            "pytest": ["python", "-m", "pytest", test_path, "-v", "--tb=short", "-x"],
            "npm":    ["npm", "test", "--", test_path],
            "go":     ["go", "test", "./" + test_path + "/..."],
            "cargo":  ["cargo", "test", test_path],
        }
        cmd = cmd_map.get(runner, cmd_map["pytest"])
        try:
            r = subprocess.run(
                cmd, cwd=self.cwd, capture_output=True, text=True,
                timeout=timeout,
            )
            latency_ms = int((time.perf_counter() - t0) * 1000)
            output = r.stdout + ("\n--- stderr ---\n" + r.stderr if r.stderr else "")
            if len(output) > 6000:
                output = output[:6000] + "... (truncated)"
            return ToolResult(
                tool="run_tests", ok=(r.returncode == 0),
                output=f"测试命令: {' '.join(cmd)}\n返回码: {r.returncode}\n\n{output}",
                raw={"returncode": r.returncode, "runner": runner},
                latency_ms=latency_ms,
                error="" if r.returncode == 0 else f"测试失败 (exit {r.returncode})",
            )
        except FileNotFoundError as e:
            return ToolResult(
                tool="run_tests", ok=False, error=f"测试命令不存在: {e}",
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                tool="run_tests", ok=False, error=f"测试超时 ({timeout}s)",
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except Exception as e:
            return ToolResult(
                tool="run_tests", ok=False, error=str(e),
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )


class ReadGitLogTool:
    """看 git 历史"""

    def __init__(self, cwd: str = ".") -> None:
        self.cwd = cwd

    async def run(self, file_path: str = "", max_count: int = 20, stat: bool = False) -> ToolResult:
        import time
        t0 = time.perf_counter()
        cmd = ["git", "log", f"-n{max_count}", "--oneline", "--no-merges"]
        if file_path:
            cmd += ["--", file_path]
        if stat:
            cmd.insert(2, "--stat")
        try:
            r = subprocess.run(
                cmd, cwd=self.cwd, capture_output=True, text=True, timeout=15,
            )
            latency_ms = int((time.perf_counter() - t0) * 1000)
            output = r.stdout.strip() if r.stdout.strip() else "(无历史)"
            return ToolResult(
                tool="read_git_log", ok=True,
                output=f"git log {' '.join(cmd[3:])}\n{output}",
                raw={"commit_count": r.stdout.count("\n") + (1 if r.stdout else 0)},
                latency_ms=latency_ms,
            )
        except FileNotFoundError:
            return ToolResult(
                tool="read_git_log", ok=False, error="未安装 git",
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )
        except Exception as e:
            return ToolResult(
                tool="read_git_log", ok=False, error=str(e),
                latency_ms=int((time.perf_counter() - t0) * 1000),
            )


class SearchDocsTool:
    """查库文档（简化版：调 LLM 自己的知识库）"""

    async def run(self, query: str, library: str = "") -> ToolResult:
        # 这里不实际调外部 API（会拖慢 Agent）
        # 而是返回提示，让 LLM 在下一步用自身知识回答
        return ToolResult(
            tool="search_docs", ok=True,
            output=(
                f"[模拟文档查询] query={query!r} library={library!r}\n"
                "注：当前为本地模拟实现。生产环境可接入：\n"
                "  - Context7 (https://context7.com) 拿最新库文档\n"
                "  - 直接 fetch PyPI/GitHub README\n"
                "Agent 请基于自身知识回答库 API 是否合法。"
            ),
            raw={"query": query, "library": library},
            latency_ms=0,
        )


class SearchSimilarCasesTool:
    """向量检索历史审计案例（接口预留，简化实现）"""

    def __init__(self, cases_db: list[dict] | None = None) -> None:
        # cases_db: [{"code": "...", "findings": [...], "verified": bool}]
        self.cases = cases_db or []

    async def run(self, code_snippet: str, top_k: int = 3) -> ToolResult:
        # 简化：用 token 重叠度近似相似度（不引入 vector DB 依赖）
        import re as _re
        query_tokens = set(_re.findall(r"\b\w+\b", code_snippet.lower()))
        scored = []
        for i, case in enumerate(self.cases):
            case_tokens = set(_re.findall(r"\b\w+\b", case.get("code", "").lower()))
            overlap = len(query_tokens & case_tokens)
            denom = max(len(query_tokens | case_tokens), 1)
            score = overlap / denom
            scored.append((score, i, case))
        scored.sort(key=lambda x: -x[0])
        top = scored[:top_k]
        if not top:
            return ToolResult(
                tool="search_similar_cases", ok=True,
                output="(历史案例库为空)",
                raw={"count": 0},
                latency_ms=0,
            )
        lines = [f"Top {len(top)} 相似案例:"]
        for score, _, case in top:
            lines.append(f"\n[相似度 {score:.0%}] {case.get('description', '未命名')}")
            lines.append(f"  验证状态: {'已确认' if case.get('verified') else '未验证'}")
            for f in case.get("findings", [])[:3]:
                lines.append(f"  - [{f.get('severity', '?')}] {f.get('location', '?')}: {f.get('description', '')[:80]}")
        return ToolResult(
            tool="search_similar_cases", ok=True,
            output="\n".join(lines),
            raw={"count": len(top), "top_score": top[0][0] if top else 0},
            latency_ms=0,
        )


# ============================================================
# Tool Registry
# ============================================================

class ToolRegistry:
    """工具注册中心"""

    def __init__(self, cwd: str = ".", cases_db: list[dict] | None = None) -> None:
        self.cwd = cwd
        self._tools: dict[ToolName, Any] = {
            ToolName.GREP_CODE: GrepCodeTool(cwd),
            ToolName.READ_FILE: ReadFileTool(cwd),
            ToolName.LIST_DIRECTORY: ListDirectoryTool(cwd),
            ToolName.RUN_TESTS: RunTestsTool(cwd),
            ToolName.READ_GIT_LOG: ReadGitLogTool(cwd),
            ToolName.SEARCH_DOCS: SearchDocsTool(),
            ToolName.SEARCH_SIMILAR_CASES: SearchSimilarCasesTool(cases_db),
        }

    # 参数名映射表：LLM 常用的别名 → 标准参数名
    # 解决 reasoning 模型经常把 pattern 写成 path/query 的问题
    PARAM_ALIASES: dict[str, dict[str, str]] = {
        "grep_code": {"path": "pattern", "query": "pattern", "regex": "pattern", "search": "pattern"},
        "read_file": {"file": "path", "filename": "path", "filepath": "path", "line_start": "start_line", "line_end": "end_line"},
        "list_directory": {"dir": "path", "directory": "path", "folder": "path"},
        "run_tests": {"path": "test_path", "test": "test_path", "tests": "test_path"},
        "read_git_log": {"file": "file_path", "path": "file_path", "filename": "file_path", "n": "max_count", "limit": "max_count"},
        "search_docs": {"q": "query", "keyword": "query", "lib": "library"},
        "search_similar_cases": {"code": "code_snippet", "snippet": "code_snippet", "k": "top_k"},
    }

    def _normalize_args(self, tool_name: str, args: dict) -> dict:
        """把 LLM 用的参数别名转成标准参数名"""
        aliases = self.PARAM_ALIASES.get(tool_name.value if hasattr(tool_name, 'value') else tool_name, {})
        if not aliases:
            return args
        normalized = {}
        for k, v in args.items():
            normalized[aliases.get(k, k)] = v
        return normalized

    async def execute(self, tool_name: ToolName | str, **args) -> ToolResult:
        """执行工具调用（带参数名自动容错）"""
        if isinstance(tool_name, str):
            try:
                tool_name = ToolName(tool_name)
            except ValueError:
                return ToolResult(
                    tool=str(tool_name), ok=False, output="",
                    error=f"未知工具名: {tool_name}",
                )
        tool = self._tools.get(tool_name)
        if tool is None:
            return ToolResult(
                tool=str(tool_name), ok=False, output="",
                error=f"未注册的工具: {tool_name}",
            )
        # 参数名自动容错
        args = self._normalize_args(tool_name, args)
        try:
            return await tool.run(**args)
        except TypeError as e:
            return ToolResult(
                tool=str(tool_name), ok=False, output="",
                error=f"参数错误: {e}",
            )
        except Exception as e:
            return ToolResult(
                tool=str(tool_name), ok=False, output="",
                error=f"执行异常: {type(e).__name__}: {e}",
            )

    def tool_descriptions(self) -> str:
        """生成给 LLM 看的工具说明"""
        descs = [
            ("grep_code", "在代码库搜索 pattern（支持正则）。args: pattern(str), glob(str='*'), max_results(int=50)"),
            ("read_file", "读文件指定行号范围。args: path(str), start_line(int=1), end_line(int=0 表示到末尾)"),
            ("list_directory", "列目录。args: path(str='.'), depth(int=1), max_items(int=100)"),
            ("run_tests", "跑测试套件。args: test_path(str='tests/'), runner(str='auto'), timeout(int=60)"),
            ("read_git_log", "看 git 历史。args: file_path(str=''), max_count(int=20), stat(bool=False)"),
            ("search_docs", "查库文档（模拟）。args: query(str), library(str='')"),
            ("search_similar_cases", "查历史相似案例。args: code_snippet(str), top_k(int=3)"),
        ]
        return "\n".join(f"- {n}: {d}" for n, d in descs)
