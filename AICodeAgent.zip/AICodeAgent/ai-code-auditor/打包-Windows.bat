@echo off
chcp 65001 >nul
title AI Code Auditor - Windows 安装包打包工具

echo ============================================================
echo   AI Code Auditor - Windows 安装包打包工具
echo ============================================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.10+
    echo 下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/4] 检测到 Python:
python --version
echo.

echo [2/4] 安装依赖包...
pip install PySide6 pyinstaller pyyaml httpx pydantic tree-sitter tree-sitter-language-pack
if errorlevel 1 (
    echo [错误] 依赖安装失败
    pause
    exit /b 1
)
echo.

echo [3/4] 开始打包（可能需要 2-3 分钟）...
python build_exe.py
if errorlevel 1 (
    echo [错误] 打包失败
    pause
    exit /b 1
)
echo.

echo [4/4] 打包完成！
echo.
echo   可执行文件在: dist\AI-Code-Auditor\AI-Code-Auditor.exe
echo.
echo   使用方法:
echo   1. 进入 dist\AI-Code-Auditor\ 目录
echo   2. 双击 AI-Code-Auditor.exe 启动
echo   3. 首次使用点"设置" -^> "一键注册 API Key"
echo.
pause
