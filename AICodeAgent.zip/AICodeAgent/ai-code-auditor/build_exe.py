"""
PyInstaller 打包脚本

使用方法:
    python build_exe.py

生成的 exe 在 dist/ 目录下。

注意:
    - Windows 上运行此脚本生成 .exe
    - Linux 上运行生成 Linux 可执行文件
    - 需要先安装: pip install pyinstaller PySide6 pyyaml httpx pydantic tree-sitter tree-sitter-language-pack
"""
import subprocess
import sys
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent


def build():
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        "--windowed",                    # 无控制台窗口
        "--name", "AI-Code-Auditor",     # 输出名称
        "--onedir",                      # 单目录模式（启动更快）

        # 图标（如有）
        # "--icon", str(PROJECT_ROOT / "assets" / "icon.ico"),

        # 隐式 import（tree-sitter 的 grammar 是动态加载的）
        "--hidden-import", "tree_sitter",
        "--hidden-import", "tree_sitter_language_pack",
        "--hidden-import", "pydantic",
        "--hidden-import", "yaml",
        "--hidden-import", "httpx",

        # 收集数据文件
        "--collect-all", "tree_sitter_language_pack",
        "--collect-all", "pydantic",

        # 添加数据
        "--add-data", f"{PROJECT_ROOT / 'auditor'}{os.pathsep}auditor",

        # 排除不需要的模块
        "--exclude-module", "tkinter",
        "--exclude-module", "matplotlib",
        "--exclude-module", "numpy",
        "--exclude-module", "pandas",

        # 入口
        str(PROJECT_ROOT / "gui" / "__main__.py"),
    ]

    print("=" * 60)
    print("  Building AI Code Auditor executable...")
    print("=" * 60)
    print()
    print("Command:", " ".join(cmd[:5]), "...")
    print()

    result = subprocess.run(cmd, cwd=str(PROJECT_ROOT))
    if result.returncode == 0:
        print()
        print("=" * 60)
        print("  Build successful!")
        print(f"  Output: {PROJECT_ROOT / 'dist' / 'AI-Code-Auditor'}")
        print("=" * 60)
    else:
        print()
        print("Build failed!")
        sys.exit(1)


if __name__ == "__main__":
    build()
