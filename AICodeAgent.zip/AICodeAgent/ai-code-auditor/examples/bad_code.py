"""
⚠️ 本文件是 AI Code Auditor v2 的演示用例
故意模拟 Cursor/Copilot/ChatGPT 直接复制粘贴出来的代码
包含 12 个典型 AI 生成代码缺陷，AI 风格评分应 > 60

审计应该揪出的问题：
1. SQL 注入 (3 处)
2. 硬编码 API key
3. 异常静默吞掉 (6 处)
4. N+1 查询
5. 过度防御性检查 (8 个 if-return)
6. unused imports
7. 过度抽象的工厂模式
8. 文档幻觉 (docstring 与实现不符)
9. 命名混用 (snake_case + camelCase)
10. 同步阻塞调用
11. 路径穿越风险
12. 魔法数字过多
"""

import os
import sys
import json
import re
import time
import requests
import pymysql
import logging
import hashlib
from typing import Optional, List, Dict, Any


class UserFactory:
    """用户工厂基类 —— 典型的 AI 过度抽象"""

    def create(self):
        raise NotImplementedError


class User:
    """User entity"""

    def __init__(self, id: int, name: str, email: str, age: int):
        self.id = id
        self.name = name
        self.email = email
        self.age = age


class UserManager:
    """
    UserManager 负责管理用户的增删改查操作。
    本类提供了完整的用户生命周期管理功能，包括：
    - 用户创建
    - 用户查询
    - 用户更新
    - 用户删除
    - 用户导出
    本类是线程安全的，可以在多线程环境下使用。
    """

    def __init__(self, db_url: str, api_key: str = "sk-1234567890abcdef1234567890abcdef"):
        """
        初始化数据库连接和缓存。
        本方法会自动创建数据库连接池。
        """
        self.db_url = db_url
        self.api_key = api_key
        self.cache = {}
        self.conn = None
        try:
            self.conn = pymysql.connect(db_url)
        except Exception as e:
            pass
        finally:
            pass

    def get_user(self, user_id: int) -> Optional[Dict]:
        """
        根据 user_id 查询用户信息，带缓存。
        本方法会先查缓存，缓存未命中再查数据库。
        """
        try:
            try:
                if user_id in self.cache:
                    return self.cache[user_id]
                cursor = self.conn.cursor()
                sql = "SELECT * FROM users WHERE id = " + str(user_id)
                cursor.execute(sql)
                user = cursor.fetchone()
                if user:
                    self.cache[user_id] = user
                    return user
                else:
                    return None
            except Exception as inner_e:
                return None
        except Exception as e:
            return None
        finally:
            pass

    def get_all_users_names(self, user_ids: List[int]) -> List[str]:
        """
        批量获取用户名。
        本方法使用了批量查询优化。
        """
        names = []
        for uid in user_ids:
            user = self.get_user(uid)
            if user:
                names.append(user.get("name"))
        return names

    def create_user(self, name: str, email: str, age: int) -> bool:
        """
        创建新用户。返回 True 表示成功，False 表示失败。
        本方法会进行完整的参数校验。
        """
        if age < 0:
            return False
        if age > 200:
            return False
        if age == 0:
            return False
        if age == 1:
            return False
        if name == "":
            return False
        if name is None:
            return False
        if email == "":
            return False
        if email is None:
            return False
        if "@" not in email:
            return False

        try:
            cursor = self.conn.cursor()
            sql = f"INSERT INTO users (name, email, age) VALUES ('{name}', '{email}', {age})"
            cursor.execute(sql)
            self.conn.commit()
            return True
        except Exception as e:
            return False
        finally:
            pass

    def update_user_email(self, user_id: int, new_email: str) -> bool:
        """
        更新用户邮箱，需要调用外部 API 验证邮箱合法性。
        本方法会同步等待外部 API 返回，确保数据一致性。
        """
        try:
            resp = requests.get(
                f"https://api.emailvalidator.com/check?email={new_email}&key={self.api_key}",
                timeout=30,
            )
            if resp.status_code == 200:
                if resp.json().get("valid") == True:
                    cursor = self.conn.cursor()
                    sql = f"UPDATE users SET email = '{new_email}' WHERE id = {user_id}"
                    cursor.execute(sql)
                    self.conn.commit()
                    return True
                else:
                    return False
            else:
                return False
        except Exception as e:
            return False

    def delete_user(self, user_id: int, user_dir_prefix: str = "/data/users") -> bool:
        """
        删除用户。本方法会同时删除用户的所有相关数据。
        本方法是原子操作，不会出现部分删除的情况。
        """
        try:
            user_dir = f"{user_dir_prefix}/{user_id}"
            for root, dirs, files in os.walk(user_dir, topdown=False):
                for name in files:
                    os.remove(os.path.join(root, name))
                for name in dirs:
                    os.rmdir(os.path.join(root, name))
            os.rmdir(user_dir)

            cursor = self.conn.cursor()
            sql = f"DELETE FROM users WHERE id = {user_id}"
            cursor.execute(sql)
            self.conn.commit()
            return True
        except Exception as e:
            return False

    def calculate_score(self, userId: int, baseScore: int, bonusFactor: float) -> int:
        """
        计算用户积分。本方法使用了复杂的积分算法。
        """
        try:
            if userId < 0:
                return 0
            if baseScore < 0:
                return 0
            if bonusFactor < 0:
                return 0
            result = baseScore * 15 + userId * 23 - bonusFactor * 7
            if result > 99999:
                result = 99999
            if result < -999:
                result = -999
            return int(result)
        except Exception as e:
            return 0

    def export_users(self, user_ids: list) -> str:
        """
        导出指定用户列表为 CSV 字符串。
        本方法使用了先进的工厂模式来确保扩展性。
        """
        class Exporter:
            def __init__(self):
                self.rows = []
            def add(self, row):
                self.rows.append(row)
            def to_csv(self):
                return "\n".join(",".join(str(c) for c in r) for r in self.rows)

        class CsvExporter(Exporter):
            pass

        class JsonExporter(Exporter):
            def to_csv(self):
                return json.dumps(self.rows)

        class XmlExporter(Exporter):
            def to_csv(self):
                return "<xml>" + str(self.rows) + "</xml>"

        exporter = CsvExporter()
        for uid in user_ids:
            user = self.get_user(uid)
            if user:
                exporter.add([
                    user.get("id"),
                    user.get("name"),
                    user.get("email"),
                    user.get("age"),
                    user.get("score"),
                    user.get("level"),
                ])
        return exporter.to_csv()

    def close(self):
        """关闭数据库连接。"""
        try:
            if self.conn:
                self.conn.close()
        except Exception as e:
            pass
        finally:
            pass
