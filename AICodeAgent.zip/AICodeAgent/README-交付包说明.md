# AI Code Auditor — 完整交付包

## 目录结构

```
ai-code-auditor-pack/
├── ai-code-auditor/              # 项目代码（可直接推 GitHub）
│   ├── auditor/                  # 核心模块（17 个 .py 文件）
│   │   ├── __init__.py
│   │   ├── __main__.py           # CLI 入口
│   │   ├── client.py             # 多模型客户端
│   │   ├── schemas.py            # Pydantic 结构化输出
│   │   ├── tree_sitter_analyzer.py  # 多语言 AST 分析
│   │   ├── static_analyzer.py    # Python ast 分析
│   │   ├── ai_fingerprint.py     # AI 来源指纹识别
│   │   ├── tools.py              # Agent 工具集
│   │   ├── agent_loop.py         # ReAct Agent 循环
│   │   ├── adversarial_debate.py # 红蓝对抗辩论
│   │   ├── sandbox.py            # Patch 沙箱验证
│   │   ├── cache.py              # 函数级缓存
│   │   ├── git_integration.py    # git diff 解析
│   │   ├── patcher.py            # unified diff 提取
│   │   ├── evaluation.py         # 评估集（21 金标样本）
│   │   ├── prompts_v3.py         # Prompt 模板
│   │   └── pipeline.py           # 主流水线
│   ├── gui/                      # 桌面 GUI 应用
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── main_window.py
│   │   └── styles.py
│   ├── examples/bad_code.py      # 演示用例
│   ├── Dockerfile
│   ├── build_exe.py              # PyInstaller 打包脚本
│   ├── 打包-Windows.bat          # Windows 一键打包
│   ├── 打包说明.md
│   ├── config.example.yaml
│   ├── requirements.txt
│   └── README.md
│

├── playground/                   # 在线 Playground 网页
│   └── page.tsx
│
├── scripts/                      # 自审脚本
│   └── self_audit.py
│
└── 自审计报告.md
```

## 快速开始

### 方式 1：桌面 GUI

```bash
cd ai-code-auditor
pip install -r requirements.txt
pip install PySide6
python -m gui
```

### 方式 2：命令行

```bash
cd ai-code-auditor
pip install -r requirements.txt
python -m auditor examples/bad_code.py
```

### 方式 3：一键配置 API

```bash
python -m auditor --register      # 打开浏览器注册
python -m auditor --setup-key sk-xxx  # 一键生成 config.yaml
```

### 方式 4：打包 Windows exe

双击 `ai-code-auditor/打包-Windows.bat`

## GitHub

https://github.com/lj25001288-commits/-AICodeAgent
